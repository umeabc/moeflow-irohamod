"""Offline support archive. Export allowlisted metadata, never raw account/image data."""
from __future__ import annotations
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import re
import tempfile
import zipfile
import bridge_worker as worker
from batch_records import validate_item
from api_diagnostics import safe_error_details, safe_request_summary, safe_input_image, safe_api_response, safe_web_upload, safe_transfer

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / 'runtime'
STATES = {'starting', 'queued', 'initializing', 'uploading', 'resolving', 'generating', 'downloading', 'restoring',
          'running', 'done', 'partial', 'error', 'cancelled', 'imported', 'unverified', 'history', 'mapping', 'review'}
SOURCES = {'server_original', 'server_dwm3', 'server_watermarked', 'server_unspecified', 'api_url', 'api_base64'}
NOTICES = {'server_temporary_problem', 'quota_limit', 'subscription_required', 'reference_image_requested',
           'confirmation_requested', 'verification_requested', 'review_rejected', 'text_reply_present'}

def safe_name(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9]+-[0-9]+', value) is not None

def enum(value, allowed, default='unknown'):
    return value if isinstance(value, str) and value in allowed else default

def numbers(data, keys):
    return {k: data[k] for k in keys if isinstance(data.get(k), (int, float, bool)) and
            (not isinstance(data[k], float) or __import__('math').isfinite(data[k]))}

def load(path):
    if not path.is_file(): return {}
    if path.stat().st_size > 4 * 1024 * 1024: return {'unreadable': True}
    try:
        value = worker.read_json(path)
        return value if isinstance(value, dict) else {'unreadable': True}
    except (ValueError, OSError): return {'unreadable': True}

def reason(message):
    # Do not copy arbitrary error text, even from old versions or Photoshop.
    text = message if isinstance(message, str) else ''
    for phrase, label in (
        ('生成已成功', '生成已成功，但结果图片下载或本地恢复未完成；可找回已有结果，不必重新生成。'),
        ('API 参考图未被正确接收', '服务端报告参考图数量不为 1，已阻止结果下载和导入，未重复生成。'),
        ('API 生成失败', 'API 生成失败；HTTP 状态见诊断记录，请核对密钥、模型权限、额度和参数。'),
        ('API 输入图片', 'API 输入图片超过大小限制，未提交生成。'),
        ('API 参考图', 'API 输入图片尺寸或比例不符合要求，未提交生成。'),
        ('生成凭据', '本次固定生成凭据不可用或校验失败，未换用其他账号。'),
        ('671020000', '图片上传被豆包拒绝（671020000）；尚未提交生成，具体原因未明确。'),
        ('服务端暂时', '豆包服务端暂时异常，未返回图片。'),
        ('出了点问题', '豆包服务端暂时异常，未返回图片。'),
        ('额度或次数', '豆包提示额度或次数限制。'),
        ('需要订阅', '豆包提示订阅权限限制。'),
        ('需要额外验证', '豆包提示额外验证。'),
        ('只返回文本', '豆包只返回文本，没有可识别图片。'),
        ('未提供可识别的无水印', '未获得可识别的无水印原图地址。'),
        ('没有返回', '未获得可识别图片；旧版日志不足以判定具体原因。'),
        ('未发现', '未发现可识别图片。'),
        ('从原会话恢复', '已从原会话恢复既有结果，没有重新生成。'),
        ('超时', '请求或处理超时，没有自动重试。'),
        ('HTTP 连接失败', 'HTTP 连接失败。'),
        ('附件无效', '接口提示参数或附件无效。'),
        ('取消', '任务已取消。'),
        ('校验失败', '本地校验失败。'),
    ):
        if phrase in text: return label
    return '详细阶段与结构计数见诊断记录。'

def safe_status(data):
    out = {**numbers(data, ('updated_at', 'width', 'height', 'total', 'new_attempts', 'carried_count', 'attachment_resolved', 'saved_to_history', 'recovered_from_history')),
           'state': enum(data.get('state'), STATES), 'stage': enum(data.get('stage'), STATES),
           'backend': enum(data.get('backend'), {'web', 'api'}),
           'reason': reason(data.get('message'))}
    if data.get('result_source') in SOURCES: out['result_source'] = data['result_source']
    if data.get('reference_status') in ('confirmed', 'not_reported', 'rejected', 'unexpected'):
        out['reference_status'] = data['reference_status']
    if isinstance(data.get('counts'), dict): out['counts'] = numbers(data['counts'], ('done', 'error', 'cancelled'))
    for key in ('generation_succeeded', 'download_recoverable', 'download_recovery'):
        if isinstance(data.get(key), bool): out[key] = data[key]
    if isinstance(data.get('counts'), dict) and out['state'] in ('done', 'partial', 'error', 'cancelled'):
        out['reason'] = '批次已结束；成功、失败和取消数量见 counts，逐层原因见各任务。'
    version = str(data.get('worker_version', ''))
    if re.fullmatch(r'http-v\d+(?:\.\d+){0,2}', version): out['worker_version'] = version
    for key in ('generated_size', 'alpha_bounds'):
        value = data.get(key)
        if isinstance(value, list) and len(value) in (2, 4) and all(isinstance(x, (int, float)) for x in value): out[key] = value
    return out

def safe_diagnostic(data):
    if not data: return {'legacy': True, 'note': '旧版未记录事件结构；无法从旧日志确定所有接口细节。'}
    out = {**safe_status(data), **numbers(data, ('schema', 'started_at', 'elapsed_ms', 'generation_trace_missing'))}
    if data.get('origin') == 'history_recovery': out['origin'] = 'history_recovery'
    if isinstance(data.get('api_codes'), list): out['api_codes'] = [code for code in data['api_codes'] if isinstance(code, str) and re.fullmatch(r'-?\d{1,12}', code)]
    out['outcome'] = enum(data.get('outcome'), STATES)
    if isinstance(data.get('api_error'), dict): out['api_error'] = safe_error_details(data['api_error'])
    if isinstance(data.get('api_request'), dict): out['api_request'] = safe_request_summary(data['api_request'])
    if isinstance(data.get('input_image'), dict): out['input_image'] = safe_input_image(data['input_image'])
    if isinstance(data.get('api_response'), dict): out['api_response'] = safe_api_response(data['api_response'])
    if isinstance(data.get('uploads'), list): out['uploads'] = [safe_web_upload(row) for row in data['uploads'][:2] if isinstance(row, dict)]
    if isinstance(data.get('downloads'), list): out['downloads'] = [safe_transfer(row) for row in data['downloads'][:20] if isinstance(row, dict)]
    out['options'] = numbers(data.get('options', {}), ('width', 'height', 'document_id', 'source_layer_id', 'prefer_watermark_free', 'memory_type'))
    requests = data.get('requests', [])
    out['requests'] = []
    for row in requests[:100] if isinstance(requests, list) else []:
        if not isinstance(row, dict): continue
        out['requests'].append({**numbers(row, ('status', 'elapsed_ms')), 'stage': enum(row.get('stage'), STATES),
            'content_type': enum(row.get('content_type'), {'application/json', 'text/event-stream', 'text/plain', 'text/html', '', 'other'})})
    stream = data.get('stream', {})
    out['stream'] = numbers(stream, ('frames', 'image_variants', 'completed'))
    for key in ('event_types', 'content_types', 'block_types', 'event_names'):
        counts = stream.get(key, {})
        if not isinstance(counts, dict): continue
        out['stream'][key] = {k: v for k, v in counts.items() if isinstance(v, int) and
            ((key != 'event_names' and re.fullmatch(r'(?:-?\d{1,12}|未知)', k)) or
             (key == 'event_names' and k in ('', 'FULL_MSG_NOTIFY', 'STREAM_CHUNK', 'STREAM_MSG_NOTIFY', 'STREAM_ERROR', 'STREAM_END', 'SSE_ACK', 'CHUNK_DELTA', 'history', 'other')))}
    out['stream']['notice_codes'] = sorted(set(stream.get('notice_codes', [])) & NOTICES)
    exc = data.get('exception_type')
    if exc in ('UserError', 'Cancelled', 'TimeoutException', 'ReadTimeout', 'ConnectTimeout', 'ConnectError', 'ValueError', 'OSError', 'PermissionError', 'KeyError'):
        out['exception_type'] = exc
    return out

def safe_event(row):
    allowed = {'options', 'state', 'http', 'stream_summary', 'exception', 'result_selected', 'history_recovery', 'api_error', 'api_request', 'input_image', 'api_response', 'web_upload', 'result_transfer'}
    kind = row.get('kind')
    if kind not in allowed: return None
    base = {**numbers(row, ('time', 'elapsed_ms')), 'kind': kind}
    if kind == 'api_error': return {**base, **safe_error_details(row)}
    if kind == 'api_request': return {**base, **safe_request_summary(row)}
    if kind == 'input_image': return {**base, **safe_input_image(row)}
    if kind == 'api_response': return {**base, **safe_api_response(row)}
    if kind == 'web_upload': return {**base, **safe_web_upload(row)}
    if kind == 'result_transfer': return {**base, **safe_transfer(row)}
    if kind == 'options': return {**base, **numbers(row, ('width', 'height', 'document_id', 'source_layer_id', 'prefer_watermark_free', 'memory_type'))}
    if kind == 'state': return {**base, **safe_status(row)}
    if kind == 'http': return {**base, **numbers(row, ('status',)), 'stage': enum(row.get('stage'), STATES)}
    if kind == 'stream_summary': return {**base, **safe_diagnostic({'stream': row})['stream']}
    if kind == 'exception':
        diagnostic = safe_diagnostic(row)
        return {**base, 'exception_type': diagnostic.get('exception_type', 'other'), 'api_codes': diagnostic.get('api_codes', [])}
    if kind == 'result_selected': return {**base, 'source': enum(row.get('source'), SOURCES), **numbers(row, ('rank',))}
    return {**base, 'note': '仅查询和下载原会话已有图片，未提交生成。'}

def timeline(path):
    # Old worker.log contains fixed state messages; export timestamp/state only.
    if not path.is_file(): return '没有此版本的阶段日志。\n'
    rows = []
    with path.open(encoding='utf-8-sig', errors='replace') as file:
        for line in file:
            match = re.match(r'^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) ([a-z]+) ', line[:100])
            if match and match[2] in STATES: rows.append(match[1] + ' ' + match[2])
            if len(rows) >= 5000: break
    return '\n'.join(rows) + '\n'

def checked_folder(parent, name):
    if not safe_name(name): raise worker.UserError('日志任务编号无效。')
    folder = (parent / name).resolve()
    if folder.parent != parent.resolve() or not folder.is_dir(): raise worker.UserError('日志目录无效或不存在。')
    return folder

def collect(batch_name=None, job_name=None):
    files, jobs, batch = {}, [], None
    def add(name, data): files[name] = json.dumps(data, ensure_ascii=False, indent=2) + '\n'
    if batch_name:
        batch = checked_folder(RUNTIME / 'batches', batch_name)
        manifest = load(batch / 'request.json')
        items = manifest.get('items')
        if not isinstance(items, list) or not items or len(items) > 500: raise worker.UserError('批次记录无效。')
        seen = set()
        for item in items:
            if not isinstance(item, dict): raise worker.UserError('批次图层记录无效。')
            job, req = validate_item(RUNTIME, batch_name, manifest, item)
            if job.name in seen:
                raise worker.UserError('日志图层对应记录不一致。')
            jobs.append(job)
            seen.add(job.name)
        add('batch/metadata.json', {**numbers(manifest, ('schema', 'document_id', 'started_ms')), 'batch_name': batch_name,
                                  'web_upload_mode': enum(manifest.get('web_upload_mode', 'separate'), {'separate', 'merged'})})
        merged = load(batch / 'merged-map.json')
        if merged:
            add('batch/merged-summary.json', {**numbers(merged, ('returned_count', 'failed_downloads')),
                 'source_count': len(merged.get('items', [])) if isinstance(merged.get('items'), list) else 0,
                 'available_count': len(merged.get('candidates', [])) if isinstance(merged.get('candidates'), list) else 0,
                 'mapping_confirmed': (batch / 'mapping-confirmed.json').exists()})
        add('batch/status.json', safe_status(load(batch / 'status.json')))
        notice = load(batch / 'notification.json')
        add('batch/notification.json', {'state': enum(notice.get('state'), {'requested', 'opening', 'returned', 'fallback', 'error'})})
        files['batch/timeline.txt'] = timeline(batch / 'worker.log')
    elif job_name: jobs = [checked_folder(RUNTIME / 'jobs', job_name)]
    else: raise worker.UserError('请先选择已提交的批次或图层任务。')
    summary = ['豆包去字 v6.5.1 诊断日志', '导出时间：' + datetime.now().isoformat(timespec='seconds'),
               '此包仅含脱敏元数据、阶段和结构计数，不含账号、图片、提示词、原始响应或签名链接。',
               '旧版本未记录的结构无法补回；阶段日志仅保留时间和状态。', '']
    for index, job in enumerate(jobs):
        req, status, diagnostic = load(job / 'request.json'), safe_status(load(job / 'status.json')), load(job / 'diagnostic.json')
        prefix = 'jobs/' + job.name + '/'
        metadata = {'job_name': job.name, **numbers(req, ('width', 'height', 'left', 'top', 'document_id', 'source_layer_id', 'started_ms', 'prefer_watermark_free'))}
        metadata['backend'] = enum(req.get('backend', 'web'), {'web', 'api'})
        metadata['web_upload_mode'] = enum(req.get('web_upload_mode', 'separate'), {'separate', 'merged'})
        if safe_name(req.get('retry_of')): metadata['retry_of'] = req['retry_of']
        add(prefix + 'metadata.json', metadata)
        add(prefix + 'status.json', status)
        add(prefix + 'diagnostic.json', safe_diagnostic(diagnostic))
        recovery_links = load(job / 'recovery-jobs.json').get('jobs', [])
        if isinstance(recovery_links, list):
            for task_name in recovery_links[-10:]:
                if not safe_name(task_name): continue
                recovery_task = RUNTIME / 'jobs' / task_name
                recovery_request = load(recovery_task / 'request.json')
                if recovery_request.get('kind') != 'result_recovery' or recovery_request.get('source_job_name') != job.name: continue
                target = prefix + 'recoveries/' + task_name + '/'
                add(target + 'status.json', safe_status(load(recovery_task / 'status.json')))
                add(target + 'diagnostic.json', safe_diagnostic(load(recovery_task / 'diagnostic.json')))
        files[prefix + 'timeline.txt'] = timeline(job / 'worker.log')
        events = job / 'events.jsonl'
        if events.is_file():
            rows = []
            with events.open(encoding='utf-8-sig', errors='replace') as file:
                for line in file:
                    try: row = json.loads(line[:100000])
                    except ValueError: continue
                    clean = safe_event(row) if isinstance(row, dict) else None
                    if clean: rows.append(json.dumps(clean, ensure_ascii=False))
                    if len(rows) >= 5000: break
            files[prefix + 'events.jsonl'] = '\n'.join(rows) + '\n'
        ps_events = job / 'ps-events.jsonl'
        if ps_events.is_file():
            rows = []
            with ps_events.open(encoding='utf-8-sig', errors='replace') as file:
                for line in file:
                    try: row = json.loads(line[:10000])
                    except ValueError: continue
                    if isinstance(row, dict) and row.get('kind') in ('import_start', 'import_done', 'import_error', 'ui_error'):
                        rows.append(json.dumps({'kind': row['kind'], **numbers(row, ('time_ms', 'source_layer_id', 'line', 'placed'))}, ensure_ascii=False))
                    if len(rows) >= 5000: break
            files[prefix + 'ps-events.jsonl'] = '\n'.join(rows) + '\n'
        imp = load(job / 'import-error.json')
        add(prefix + 'photoshop.json', {'imported': (job / 'imported.flag').exists(),
            'import_pending': (job / 'importing.flag').exists(), 'import_failed': bool(imp), **numbers(imp, ('placed', 'line'))})
        summary.append(f"{index + 1}. 图层 ID {req.get('source_layer_id') if isinstance(req.get('source_layer_id'), int) else '?'} / 任务 {job.name}")
        summary.append(f"   {status['state']} / {status['stage']}；{status['reason']}")
        summary.append('   事件结构：' + ('已记录' if diagnostic else '旧版未记录'))
        api_detail = safe_error_details(diagnostic.get('api_error'))
        if api_detail:
            summary.append('   API 业务码：' + api_detail.get('code', '未提供可安全记录的错误码') +
                           '；参数：' + api_detail.get('param', '未明确') +
                           '；追踪号：' + api_detail.get('request_id', '未提供'))
        image_info = safe_input_image(diagnostic.get('input_image'))
        if image_info:
            summary.append('   请求参考图：' + str(image_info.get('count', '?')) + ' 张；' +
                           str(image_info.get('width', '?')) + 'x' + str(image_info.get('height', '?')) +
                           '；字节数 ' + str(image_info.get('bytes', '?')) + '；编码方式 ' + image_info.get('transport', '未记录'))
        received = safe_api_response(diagnostic.get('api_response'))
        if received:
            summary.append('   服务端参考图：' + str(received.get('input_images', '未回报数量')) +
                           '；状态 ' + received.get('reference_status', '未记录'))
        if isinstance(diagnostic.get('uploads'), list):
            for row in diagnostic['uploads'][:2]:
                clean = safe_web_upload(row)
                summary.append('   上传尝试 ' + str(clean.get('attempt', '?')) + '；业务码 ' + clean.get('code', '未知') +
                               '；分类 ' + clean.get('category', '未记录'))
    files['诊断摘要.txt'] = '\n'.join(summary) + '\n'
    return files

def export_archive(output, batch_name=None, job_name=None):
    output = Path(output).resolve()
    if output.suffix.lower() != '.zip' or not output.parent.is_dir(): raise worker.UserError('请选择已有目录中的 ZIP 文件。')
    # Protect code, credentials, images, historical logs and task manifests.
    project = ROOT.resolve()
    exports = (RUNTIME / 'exports').resolve()
    if output.is_relative_to(project) and not output.is_relative_to(exports):
        raise worker.UserError('项目目录内请仅保存到 runtime/exports，避免覆盖程序或任务文件。')
    files = collect(batch_name, job_name)
    fd, temp_name = tempfile.mkstemp(prefix='doubao-log-', suffix='.tmp', dir=output.parent)
    os.close(fd)
    temp = Path(temp_name)
    try:
        with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, content in files.items(): archive.writestr(name, content.encode('utf-8'))
        os.replace(temp, output)
    finally: temp.unlink(missing_ok=True)
    return output

def latest():
    active = load(RUNTIME / 'active-http-batch.json')
    if safe_name(active.get('batch_name')): return {'batch_name': active['batch_name']}
    active = load(RUNTIME / 'active-http-job.json')
    if safe_name(active.get('job_name')): return {'job_name': active['job_name']}
    batches = [p for p in (RUNTIME / 'batches').glob('*') if p.is_dir() and safe_name(p.name) and (p / 'request.json').is_file()]
    if batches: return {'batch_name': max(batches, key=lambda p: int(p.name.split('-')[0])).name}
    raise worker.UserError('没有已提交的任务可导出。')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path)
    parser.add_argument('--latest', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    task, title, text = None, '豆包去字 · 导出日志', ''
    try:
        if args.job:
            candidate = args.job.resolve()
            if candidate.parent != (RUNTIME / 'support_jobs').resolve() or not candidate.is_dir() or not safe_name(candidate.name): raise worker.UserError('导出任务目录无效。')
            task = candidate
            try:
                with (task / 'submitted.lock').open('x') as file: file.write('once')
            except FileExistsError: return 0
            req = worker.read_json(task / 'request.json')
            selection = {k: req[k] for k in ('batch_name', 'job_name') if req.get(k)}
            output = req.get('output', '')
        else:
            selection = latest()
            folder = RUNTIME / 'exports'
            folder.mkdir(parents=True, exist_ok=True)
            output = args.output or folder / ('豆包日志-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.zip')
        result = export_archive(output, **selection)
        text = '日志已导出：\n' + str(result) + '\n\n可将此 ZIP 提供用于排查，不需要发送账号文件或图片。'
        if task: worker.atomic_json(task / 'status.json', {'state': 'done', 'message': '日志已导出。', 'output': str(result)})
    except Exception as exc:
        text = str(exc) if isinstance(exc, worker.UserError) else '日志导出失败（' + type(exc).__name__ + '），请检查目标目录和写入权限。'
        if task: worker.atomic_json(task / 'status.json', {'state': 'error', 'message': text})
    if args.job and os.name == 'nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x40)
    elif sys_stdout(): print(text)
    return 0 if text.startswith('日志已导出') else 1

def sys_stdout():
    import sys
    return sys.stdout is not None

if __name__ == '__main__': raise SystemExit(main())
