param([string]$PythonPath = '', [switch]$APIOnly)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Run-Checked([string]$Exe, [string[]]$Arguments) {
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Command failed (exit $LASTEXITCODE): $Exe" }
}
try {
    if (-not $PythonPath) {
        $candidates = @()
        $py = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($py) {
            $found = & $py.Source -3 -c 'import sys; print(sys.executable)' 2>$null
            if ($LASTEXITCODE -eq 0) { $candidates += $found }
        }
        $python = Get-Command python.exe -ErrorAction SilentlyContinue
        if ($python -and $python.Source -notmatch 'WindowsApps') { $candidates += $python.Source }
        $candidates += (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
        foreach ($candidate in $candidates) {
            if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                & $candidate -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)' 2>$null
                if ($LASTEXITCODE -eq 0) { $PythonPath = $candidate; break }
            }
        }
    }
    if (-not $PythonPath) { throw 'Python 3.11+ required. Install Python 3.12, then run install.cmd again.' }
    $PythonPath = (Resolve-Path -LiteralPath $PythonPath).Path
    Run-Checked $PythonPath @('-c', 'import sys; assert sys.version_info >= (3,11)')
    $venv = Join-Path $root '.venv'
    $venvPython = Join-Path $venv 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $venvPython)) {
        Write-Host '[1/3] Creating private Python environment...'
        Run-Checked $PythonPath @('-m', 'venv', $venv)
    }
    Write-Host '[2/3] Installing HTTP and image dependencies (no browser)...'
    Run-Checked $venvPython @('-m', 'pip', 'install', '-r', (Join-Path $root 'requirements.lock.txt'))
    if ($APIOnly) {
        Run-Checked $venvPython @('-X', 'utf8', (Join-Path $root 'bridge_worker.py'), '--prepare-api')
        Write-Host 'API ready. Add API Key and Model ID in the Photoshop script settings.' -ForegroundColor Green
        exit 0
    }
    Write-Host '[3/3] Installing the pinned Python-only signer...'
    $signerDir = Join-Path $root 'runtime\http-signer'
    New-Item -ItemType Directory -Force -Path $signerDir | Out-Null
    $signer = Join-Path $signerDir 'pure_signer.py'
    $expected = 'BE9927D53ABE10A88101EB09AB93C528CA22A5302CD0D4C8DFE22984D1D4C434'
    if (-not (Test-Path -LiteralPath $signer) -or (Get-FileHash -LiteralPath $signer -Algorithm SHA256).Hash -ne $expected) {
        $download = Join-Path $signerDir ('download-' + [guid]::NewGuid().ToString('N') + '.tmp')
        Invoke-WebRequest -UseBasicParsing -Uri 'https://raw.githubusercontent.com/5201213/doubao-free-api/0240ee33f5156d26da72c0eb4b093389e9ca9ad4/pure_signer.py' -OutFile $download
        if ((Get-FileHash -LiteralPath $download -Algorithm SHA256).Hash -ne $expected) {
            Remove-Item -LiteralPath $download
            throw 'Signer SHA256 mismatch. Installation stopped.'
        }
        Move-Item -LiteralPath $download -Destination $signer -Force
    }
    Run-Checked $venvPython @('-X', 'utf8', (Join-Path $root 'bridge_worker.py'), '--prepare')
    Write-Host 'Ready. Run Doubao_RemoveText.jsx inside Photoshop. No service or browser is needed.' -ForegroundColor Green
} catch {
    Write-Host ('Installation failed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
