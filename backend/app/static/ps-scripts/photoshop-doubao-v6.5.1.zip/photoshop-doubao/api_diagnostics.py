"""Bounded vocabulary for API diagnostics. Never persist free-form API messages."""
import re

PARAMETERS = {'model', 'image', 'size', 'prompt', 'watermark', 'response_format', 'output_format',
              'stream', 'sequential_image_generation', 'sequential_image_generation_options',
              'background', 'optimize_prompt_options', 'api_key', 'authorization'}
PARAMETERS.update({'contents', 'generationConfig', 'imageConfig', 'responseModalities', 'imageSize', 'images', 'quality', 'n'})
CODES = {'InvalidParameter', 'InvalidParameterValue', 'InvalidParameter.UnsupportedParameter',
         'InvalidParameter.MissingParameter', 'InvalidParameter.UnsupportedValue', 'MissingParameter',
         'InvalidApiKey', 'InvalidAPIKey', 'AuthenticationError', 'AuthenticationFailed', 'Unauthorized',
         'AccessDenied', 'PermissionDenied', 'Forbidden', 'ModelNotOpen', 'ModelNotFound',
         'EndpointNotFound', 'NotFound', 'ResourceNotFound', 'InvalidEndpoint', 'InvalidModel',
         'QuotaExceeded', 'RateLimitExceeded', 'RateLimitError', 'TooManyRequests',
         'InsufficientBalance', 'InsufficientQuota', 'AccountOverdue', 'Arrearage',
         'ContentFilter', 'ContentFilterError', 'ContentPolicyViolation', 'SensitiveContent',
         'InputImageSensitiveContentDetected', 'OutputImageSensitiveContentDetected',
         'InternalError', 'InternalServerError', 'ServiceUnavailable', 'ServerOverloaded',
         'InvalidRequestError', 'InvalidRequest', 'BadRequest', 'RequestTimeout'}
CATEGORIES = {'authentication', 'permission', 'quota_limit', 'content_review', 'unsupported_parameter',
              'invalid_model', 'invalid_input_image', 'invalid_output_size', 'invalid_parameter',
              'service_unavailable', 'invalid_response'}
MODEL_FAMILIES = {'seedream5_pro', 'seedream5_flash', 'seedream5_lite', 'seedream4_5', 'seedream4_0', 'endpoint_id', 'custom'}
MODEL_FAMILIES.update({'gpt_image', 'gemini_image'})
SUMMARY_FIELDS = {'model', 'prompt', 'image', 'size', 'response_format', 'output_format', 'watermark'}
SUMMARY_FIELDS.update({'contents', 'generationConfig', 'images', 'replyType', 'aspectRatio', 'imageSize', 'quality', 'n'})


def safe_input_image(data):
    if not isinstance(data, dict): return {}
    out = {}
    for key, upper in (('width', 100_000_000), ('height', 100_000_000), ('bytes', 50 * 1024 * 1024), ('count', 1)):
        value = data.get(key)
        if isinstance(value, int) and not isinstance(value, bool) and 1 <= value <= upper: out[key] = value
    if data.get('transport') in ('multipart_png', 'data_uri_png', 'inline_data_png'): out['transport'] = data['transport']
    if isinstance(data.get('png_verified'), bool): out['png_verified'] = data['png_verified']
    if isinstance(data.get('encoding_verified'), bool): out['encoding_verified'] = data['encoding_verified']
    if data.get('edit_instruction') == 'preserve_source_v1': out['edit_instruction'] = 'preserve_source_v1'
    return out


def safe_api_response(data):
    if not isinstance(data, dict): return {}
    out = {}
    for key in ('input_images', 'generated_images'):
        value = data.get(key)
        if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 10000: out[key] = value
    if data.get('reference_status') in ('confirmed', 'not_reported', 'rejected', 'unexpected'):
        out['reference_status'] = data['reference_status']
    out.update({k: v for k, v in safe_error_details(data).items() if k == 'request_id'})
    return out


def safe_web_upload(data):
    if not isinstance(data, dict): return {}
    out = {}
    value = data.get('attempt')
    if isinstance(value, int) and not isinstance(value, bool) and value in (1, 2): out['attempt'] = value
    value = data.get('code')
    if isinstance(value, str) and re.fullmatch(r'-?\d{1,12}', value): out['code'] = value
    for key in ('initialized', 'has_ms_token', 'will_retry'):
        if isinstance(data.get(key), bool): out[key] = data[key]
    if data.get('csrf_source') in ('primary', 'default', 'missing'): out['csrf_source'] = data['csrf_source']
    if data.get('category') in ('unclassified', 'authentication', 'content_review', 'risk_control',
                               'verification', 'quota_limit', 'invalid_attachment'):
        out['category'] = data['category']
    out.update({k: v for k, v in safe_error_details(data).items() if k in ('http_status', 'request_id')})
    return out


def safe_transfer(data):
    if not isinstance(data, dict): return {}
    out = {}
    if type(data.get('attempt')) is int and data['attempt'] in (1, 2, 3): out['attempt'] = data['attempt']
    if data.get('category') in ('tls', 'dns', 'timeout', 'connection', 'http'): out['category'] = data['category']
    if data.get('exception_type') in ('UserError', 'ConnectError', 'ReadError', 'WriteError', 'CloseError',
            'RemoteProtocolError', 'LocalProtocolError', 'ConnectTimeout', 'ReadTimeout', 'WriteTimeout',
            'PoolTimeout', 'TimeoutException', 'ProxyError', 'UnsupportedProtocol', 'DecodingError'):
        out['exception_type'] = data['exception_type']
    for key in ('will_retry', 'generation_succeeded'):
        if isinstance(data.get(key), bool): out[key] = data[key]
    return out


def safe_code(value):
    if not isinstance(value, str): return ''
    if value in CODES: return value
    # Providers can add suffixes; preserve only a known root, never arbitrary suffix text.
    root = value.split('.', 1)[0]
    return root if root in CODES else ''


def safe_error_details(data):
    if not isinstance(data, dict): return {}
    out = {}
    status = data.get('http_status')
    if isinstance(status, int) and not isinstance(status, bool) and 100 <= status <= 599: out['http_status'] = status
    code = safe_code(data.get('code'))
    if code: out['code'] = code
    if isinstance(data.get('param'), str) and data['param'] in PARAMETERS: out['param'] = data['param']
    if isinstance(data.get('category'), str) and data['category'] in CATEGORIES: out['category'] = data['category']
    request_id = data.get('request_id')
    if isinstance(request_id, str) and len(request_id) <= 100 and re.fullmatch(
            r'(?:[0-9]{14}[A-Fa-f0-9]{8,64}|[A-Fa-f0-9]{32}|[A-Fa-f0-9]{8}(?:-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12})', request_id):
        out['request_id'] = request_id
    return out


def safe_request_summary(data):
    if not isinstance(data, dict): return {}
    out = {}
    if isinstance(data.get('billing_mode'), str) and data['billing_mode'] in ('standard', 'plan', 'custom'): out['billing_mode'] = data['billing_mode']
    if isinstance(data.get('model_family'), str) and data['model_family'] in MODEL_FAMILIES: out['model_family'] = data['model_family']
    if isinstance(data.get('size'), str) and data['size'] in ('auto', '1K', '1.5K', '2K', '4K', '1024x1024', '1536x1024', '1024x1536'): out['size'] = data['size']
    for name, allowed in (('protocol', ('seedream', 'openai', 'gemini', 'grsai')), ('provider', ('seedream', 'openai', 'gemini')), ('auth_mode', ('bearer', 'google'))):
        if isinstance(data.get(name), str) and data[name] in allowed: out[name] = data[name]
    if isinstance(data.get('model_normalized'), bool): out['model_normalized'] = data['model_normalized']
    if isinstance(data.get('fields'), list): out['fields'] = sorted({x for x in data['fields'] if isinstance(x, str) and x in SUMMARY_FIELDS})
    return out


def response_details(response, data, secrets=()):
    error = data.get('error') if isinstance(data, dict) else None
    if not isinstance(error, dict): error = {}
    raw_code = str(error.get('code') or '')[:300]
    message = str(error.get('message') or '')[:4000].lower()
    param = error.get('param', error.get('parameter'))
    if not isinstance(param, str) or param not in PARAMETERS:
        param = next((p for p in sorted(PARAMETERS, key=len, reverse=True)
                      if re.search(r'(?:[\x22\x27`]'+re.escape(p)+r'[\x22\x27`]|(?:parameter|param|参数)\s*[:=]?\s*'+re.escape(p)+r'(?![a-z0-9_]))', message)), '')
    status, text = response.status_code, raw_code.lower() + ' ' + message
    if status == 401 or any(w in text for w in ('invalidapikey', 'authenticationfailed', 'invalid api key', 'unauthorized')): category = 'authentication'
    elif status == 429 or any(w in text for w in ('quota', 'rate limit', 'ratelimit', 'balance', 'arrear', 'overdue')): category = 'quota_limit'
    elif any(w in text for w in ('sensitive', 'contentfilter', 'contentpolicy', 'moderation')): category = 'content_review'
    elif status == 403 or any(w in text for w in ('accessdenied', 'permission', 'modelnotopen', 'not enabled')): category = 'permission'
    elif ('unsupported' in text or 'not support' in text) and param: category = 'unsupported_parameter'
    elif param == 'model' or any(w in text for w in ('modelnotfound', 'invalidmodel', 'endpointnotfound', 'model does not exist')): category = 'invalid_model'
    elif param == 'image': category = 'invalid_input_image'
    elif param == 'size': category = 'invalid_output_size'
    elif status >= 500: category = 'service_unavailable'
    elif status in (400, 404) or 'invalid' in text: category = 'invalid_parameter'
    else: category = 'invalid_response'
    # Header/body values are revalidated and exact known secrets are removed.
    request_id = (response.headers.get('x-request-id') or response.headers.get('x-tt-logid') or
                  (data.get('request_id') if isinstance(data, dict) else None) or error.get('request_id'))
    result = safe_error_details({'http_status': status, 'code': raw_code, 'param': param,
                                 'category': category, 'request_id': request_id})
    for name, value in list(result.items()):
        if isinstance(value, str) and any(isinstance(s, str) and s and
                (value == s or len(s) >= 6 and s in value) for s in secrets): del result[name]
    return result
