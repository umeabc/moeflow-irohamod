"""Recover an existing result with GET only. Never imports a generation adapter."""
import argparse
import math
import os
from pathlib import Path
import time

import bridge_worker as worker
from batch_records import safe_name, validate_item


def original_profile(request, checkpoint=None):
    from generation_profiles import validate_api
    config = worker.read_json(worker.ROOT / 'config.json')
    matches = [x for x in config.get('apis', []) if isinstance(x, dict) and x.get('id') == request.get('profile_id')]
    if request.get('backend') != 'api' or len(matches) != 1:
        raise worker.UserError('原 API 配置已删除或无法唯一确定，请恢复原配置；不会换用当前选择的其他 API。')
    profile = validate_api(matches[0], worker.UserError)
    if profile['protocol'] != 'grsai': raise worker.UserError('完整任务 ID 找回仅适用于原 Grsai 中转配置。')
    diagnostic = worker.read_json(worker.RUNTIME / 'jobs' / request['_job_name'] / 'diagnostic.json')
    summary = diagnostic.get('api_request', {})
    if summary.get('protocol') != 'grsai' or summary.get('provider') != profile['provider']:
        raise worker.UserError('原任务的协议或服务与该 API 配置不一致，已停止查询。')
    if checkpoint and checkpoint.get('endpoint') != profile['endpoint']:
        raise worker.UserError('原 API 地址已变更，请恢复原地址；未向其他站点发送凭证。')
    return profile


def refresh_batch(batch, manifest, recovery_task=None):
    rows = []
    for item in manifest['items']:
        job = worker.RUNTIME / 'jobs' / item['job_name']
        status = worker.read_json(job / 'status.json')
        if (job / 'imported.flag').exists(): status = {'state': 'done', 'message': '已导入'}
        rows.append({**item, 'state': status['state'], 'message': status.get('message', ''), 'stage': status.get('stage', '')})
    counts = {s: sum(x['state'] == s for x in rows) for s in ('done', 'error', 'cancelled')}
    state = ('running' if recovery_task else 'done' if counts['done'] == len(rows)
             else 'partial' if counts['done'] else 'error')
    worker.atomic_json(batch / 'status.json', {'state': state, 'counts': counts, 'items': rows,
        'message': ('正在找回已生成图片；只查询或下载，不重新生成。' if recovery_task else
                    '结果找回结束：成功 ' + str(counts['done']) + ' 层，失败 ' + str(counts['error']) + ' 层。'),
        'recovery_task': recovery_task, 'worker_version': worker.WORKER_VERSION, 'updated_at': int(time.time())})


def process(task, notify=True):
    import httpx
    from result_transfer import download, load, save, lookup_grsai
    context = worker.read_json(task / 'request.json')
    if (context.get('kind') != 'result_recovery' or not safe_name(context.get('batch_name')) or
            not safe_name(context.get('source_job_name'))):
        raise worker.UserError('结果找回请求无效。')
    batch = worker.RUNTIME / 'batches' / context['batch_name']
    from batch_worker import load_manifest
    manifest = load_manifest(batch)
    matches = [x for x in manifest['items'] if x['job_name'] == context['source_job_name']]
    if len(matches) != 1: raise worker.UserError('该任务不属于所选批次。')
    source, request = validate_item(worker.RUNTIME, batch.name, manifest, matches[0], require_files=True)
    if request.get('web_upload_mode') == 'merged': raise worker.UserError('合并结果请通过核对窗口确认对应关系。')
    if (source / 'imported.flag').exists() or (source / 'importing.flag').exists():
        raise worker.UserError('该图层已有导入或待确认导入记录，不能覆盖。')
    if worker.read_json(source / 'status.json').get('state') not in ('error', 'cancelled'):
        raise worker.UserError('仅支持找回失败或取消任务，不能覆盖成功或正在生成的结果。')
    checkpoint = load(source, request) if (source / 'remote-result.json').exists() else None
    task_id = context.get('task_id')
    if not checkpoint and not task_id:
        raise worker.UserError('旧版未保存下载地址。请填写中转站详情内的完整任务 ID，或下载原结果后手工置入；截图中的省略 ID 无法找回。')
    if task_id and context.get('binding_confirmed') is not True:
        raise worker.UserError('请先确认该中转任务与所选原图层对应。')
    profile = original_profile({**request, '_job_name': source.name}, checkpoint) if task_id else None
    config = worker.read_json(worker.ROOT / 'config.json')
    timeout = float(config.get('timeout_seconds', 600))
    if not math.isfinite(timeout) or timeout <= 0: raise worker.UserError('处理超时必须为正数。')
    deadline = time.monotonic() + timeout
    check = lambda: worker.remaining(deadline, task)
    diagnostic = worker.Diagnostics(task, worker.WORKER_VERSION, worker.atomic_json)
    diagnostic.options(**{k: request[k] for k in ('width', 'height', 'source_layer_id', 'document_id')})
    def status(state, message, **extra):
        row = {'state': state, 'stage': 'downloading', 'backend': request.get('backend'), 'message': message,
               'worker_version': worker.WORKER_VERSION, 'updated_at': int(time.time()), 'download_recovery': True, **extra}
        worker.atomic_json(task / 'status.json', row)
        worker.atomic_json(source / 'status.json', row)
        with (source / 'worker.log').open('a', encoding='utf-8') as file:
            file.write(time.strftime('%Y-%m-%d %H:%M:%S ') + state + ' ' + message + '\n')
        diagnostic.state(state, 'downloading', message)
    try:
        with (source / 'recovery.lock').open('x', encoding='ascii') as file: file.write(task.name)
    except FileExistsError: raise worker.UserError('此图层已有结果找回任务，请等待结束。')
    try:
        # Revalidate after taking the lock: a prior recovery may have finished
        # between the first status read and this acquisition.
        if ((source / 'imported.flag').exists() or (source / 'importing.flag').exists() or
                worker.read_json(source / 'status.json').get('state') not in ('error', 'cancelled')):
            raise worker.UserError('任务状态已变化，未覆盖已有成功或导入结果。')
    except Exception:
        (source / 'recovery.lock').unlink(missing_ok=True)
        raise
    try:
        links = source / 'recovery-jobs.json'
        history = worker.read_json(links).get('jobs', []) if links.exists() else []
        worker.atomic_json(links, {'jobs': [x for x in history if safe_name(x)][-9:] + [task.name]})
        status('downloading', '正在找回已生成图片；不会重新提交生成或更换 API。')
        refresh_batch(batch, manifest, task.name)
        if task_id:
            # Credentials stay on the exact configured origin. CDN gets a fresh client.
            with httpx.Client(trust_env=False, follow_redirects=False) as client:
                result = lookup_grsai(client, profile, task_id, check, diagnostic)
            checkpoint = save(source, request, result)
        target = task / 'generated.download'
        if checkpoint.get('cached_bytes'):
            import shutil
            shutil.copyfile(source / 'result-cache.bin', target)
        else:
            with httpx.Client(trust_env=False, follow_redirects=True) as client:
                download(client, checkpoint['url'], target, check, diagnostic,
                         lambda message: status('downloading', message))
        check()
        metadata = worker.restore_image(source / 'source.png', target, task / 'result.png', int(request['width']), int(request['height']))
        check()
        if (source / 'imported.flag').exists() or (source / 'importing.flag').exists():
            raise worker.UserError('下载期间出现导入记录，已停止覆盖。')
        os.replace(task / 'preview.png', source / 'preview.png')
        os.replace(task / 'result.png', source / 'result.png')
        status('done', '已找回原生成结果，可预览并导入；没有重新生成。',
               result_source=checkpoint.get('source'), reference_status=checkpoint.get('reference_status'),
               generation_succeeded=True, download_recoverable=True, **metadata)
    except Exception as exc:
        diagnostic.exception(exc)
        state = 'cancelled' if isinstance(exc, worker.Cancelled) else 'error'
        message = (str(exc) if isinstance(exc, worker.UserError) else '找回已有结果失败（' + type(exc).__name__ + '）；没有重新生成，请查看日志。')
        status(state, message, generation_succeeded=checkpoint is not None, download_recoverable=checkpoint is not None)
    finally:
        (task / 'generated.download').unlink(missing_ok=True)
        (task / 'result.png').unlink(missing_ok=True)
        (task / 'preview.png').unlink(missing_ok=True)
        (source / 'recovery.lock').unlink(missing_ok=True)
        refresh_batch(batch, manifest)
    if notify:
        from completion_notifier import notify_completion
        notify_completion(batch, phase='recovery-' + task.name)
    return worker.read_json(task / 'status.json')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path, required=True)
    task = parser.parse_args().job.resolve()
    if task.parent != (worker.RUNTIME / 'jobs').resolve() or not task.is_dir() or not safe_name(task.name):
        raise worker.UserError('结果找回任务目录无效。')
    try:
        with (task / 'submitted.lock').open('x', encoding='ascii') as file: file.write('once')
    except FileExistsError: return 0
    try: process(task)
    except Exception as exc:
        message = str(exc) if isinstance(exc, worker.UserError) else '结果找回启动失败（' + type(exc).__name__ + '）；没有重新生成。'
        worker.atomic_json(task / 'status.json', {'state': 'error', 'message': message})
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message + '\n日志目录：' + str(task), '已有图片找回失败', 0x10)
    return 0


if __name__ == '__main__': raise SystemExit(main())
