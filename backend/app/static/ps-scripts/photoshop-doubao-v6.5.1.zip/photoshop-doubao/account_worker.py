"""HTTP-only QR authorization and account probe, adapted from doubao2api QR flow.
Apache-2.0 protocol reference: references/doubao2api-LICENSE / NOTICE.txt.
No browser, no image generation, no credentials printed to logs.
"""
from __future__ import annotations
import base64
from io import BytesIO
import json
from pathlib import Path
import secrets
import time
from urllib.parse import urljoin, urlsplit

import httpx
from PIL import Image

ORIGIN = 'https://www.doubao.com'
ACCOUNT_INFO_PATH = '/passport/account/info/v2/'

class AccountError(Exception): pass
class AccountCancelled(AccountError): pass


def require_https(url, auth=False):
    parts = urlsplit(url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
        raise AccountError('登录接口返回了无效地址，已停止。')
    if auth and not any(parts.hostname == d or parts.hostname.endswith('.' + d)
                        for d in ('doubao.com', 'douyin.com', 'snssdk.com', 'toutiao.com', 'bytedance.com')):
        raise AccountError('登录需要访问未识别的授权站点（' + parts.hostname + '），已停止；不会打开浏览器。')
    return url


def passport_data(response, stage):
    if response.status_code != 200:
        raise AccountError(stage + '失败（HTTP ' + str(response.status_code) + '）。请检查网络或稍后重新扫码。')
    try:
        data = response.json()
    except ValueError as exc:
        raise AccountError(stage + '返回了无法识别的内容，可能触发验证或接口已改变。') from exc
    if not isinstance(data, dict): raise AccountError(stage + '响应格式不正确。')
    result = data.get('data') or {}
    if not isinstance(result, dict): raise AccountError(stage + '响应格式不正确。')
    code = result.get('error_code', data.get('error_code', data.get('code', -1)))
    if str(code) != '0':
        desc = str(result.get('description', '')).lower()
        if 'expired' in desc or '过期' in desc:
            raise AccountError('二维码已过期，请返回主窗口重新点击“扫码登录”。')
        raise AccountError(stage + '失败（接口码 ' + str(code) + '）。可能需要额外验证；不会打开浏览器。')
    return result


def client_identity():
    # Client device identity, not login credentials. Keep it unchanged throughout authorization.
    parts = [secrets.token_hex(n) for n in (4, 2, 2, 2, 6)]
    return {'device_id': str(7_000_000_000_000_000 + secrets.randbelow(1_000_000_000_000_000)),
            'web_id': str(7_600_000_000_000_000_000 + secrets.randbelow(100_000_000_000_000_000)),
            'fp': 'verify_' + '_'.join(parts)}


class QRFlow:
    def __init__(self, client, job, publish, check, pause=time.sleep):
        self.client, self.job, self.publish, self.check, self.pause = client, job, publish, check, pause
        self.params = client_identity()
        self.csrf = ''
        client.cookies.set('s_v_web_id', self.params['fp'], domain='www.doubao.com', path='/')

    def get(self, path, **params):
        self.check()
        headers = {'x-tt-passport-csrf-token': self.csrf} if self.csrf else {}
        response = self.client.get(ORIGIN + path, params={'aid': '497858', **params}, headers=headers,
                                   timeout=min(15, self.check()))
        self.check()
        return response

    def site_cookies(self):
        return {c.name: c.value for c in self.client.cookies.jar
                if c.domain.lstrip('.') == 'doubao.com' or c.domain.endswith('.doubao.com')}

    def prepare(self):
        self.follow_authorization(ORIGIN + '/')
        cookies = self.site_cookies()
        self.csrf = cookies.get('passport_csrf_token') or cookies.get('passport_csrf_token_default', '')
        if not self.csrf:
            response = self.get('/passport/safe/csrf_token/')
            cookies = self.site_cookies()
            self.csrf = cookies.get('passport_csrf_token') or cookies.get('passport_csrf_token_default', '')
            if not self.csrf:
                self.csrf = str(passport_data(response, '初始化登录').get('passport_csrf_token', ''))
        data = passport_data(self.get('/passport/web/get_qrcode/', next=ORIGIN), '获取登录二维码')
        token = data.get('token')
        raw = data.get('qrcode') or data.get('qrcode_url')
        if not isinstance(token, str) or not token or not isinstance(raw, str) or not raw:
            raise AccountError('登录接口没有返回有效二维码。')
        if raw.startswith('https://'):
            # No account cookies accompany QR image CDN requests.
            with httpx.Client(trust_env=False, follow_redirects=False) as image_client:
                with image_client.stream('GET', require_https(raw), timeout=min(15, self.check())) as response:
                    if response.status_code != 200: raise AccountError('二维码图片下载失败。')
                    chunks, size = [], 0
                    for chunk in response.iter_bytes():
                        self.check()
                        size += len(chunk)
                        if size > 3 * 1024 * 1024: raise AccountError('二维码图片过大。')
                        chunks.append(chunk)
                    content = b''.join(chunks)
        else:
            if raw.startswith('data:'): raw = raw.partition(',')[2]
            if len(raw) > 4 * 1024 * 1024: raise AccountError('二维码图片过大。')
            try: content = base64.b64decode(raw, validate=True)
            except ValueError as exc: raise AccountError('二维码图片编码无效。') from exc
        try:
            with Image.open(BytesIO(content)) as image:
                if image.width > 2048 or image.height > 2048: raise AccountError('二维码尺寸异常。')
                image = image.convert('RGB')
                image.thumbnail((256, 256), Image.Resampling.NEAREST)
                canvas = Image.new('RGB', (256, 256), 'white')
                canvas.paste(image, ((256-image.width)//2, (256-image.height)//2))
                temp = self.job / 'qrcode.tmp'
                canvas.save(temp, format='PNG')
                temp.replace(self.job / 'qrcode.png')
        except (OSError, Image.DecompressionBombError) as exc: raise AccountError('返回内容不是有效二维码图片。') from exc
        self.publish('waiting_scan', '请打开手机豆包的扫一扫，扫描下方二维码并确认登录。扫描后点击“刷新登录状态”。')
        return token

    def follow_authorization(self, url):
        current = require_https(urljoin(ORIGIN, url), auth=True)
        for _ in range(10):
            self.check()
            response = self.client.get(current, timeout=min(15, self.check()))
            self.check()
            if response.status_code in (301, 302, 303, 307, 308):
                location = response.headers.get('location')
                if not location: raise AccountError('授权跳转缺少地址。')
                current = require_https(urljoin(current, location), auth=True)
            elif response.status_code == 200:
                return response
            else: raise AccountError('扫码授权跳转失败（HTTP ' + str(response.status_code) + '）。')
        raise AccountError('扫码授权跳转次数过多。')

    def run(self):
        token = self.prepare()
        while True:
            data = passport_data(self.get('/passport/web/check_qrconnect/', token=token, next=ORIGIN), '检查扫码状态')
            state = str(data.get('status', ''))
            if state == 'confirmed':
                if data.get('redirect_url'): self.follow_authorization(data['redirect_url'])
                self.check()
                cookies = self.site_cookies()
                if not (cookies.get('sessionid') or cookies.get('sid_tt')):
                    raise AccountError('手机已确认，但接口未返回有效登录凭据，未覆盖原账号。请重新扫码。')
                self.params['fp'] = cookies.get('s_v_web_id') or self.params['fp']
                return {'name': '扫码登录账号', 'cookies': cookies, 'params': self.params}
            if state == 'expired': raise AccountError('二维码已过期，请返回主窗口重新扫码。')
            if state == 'scanned': self.publish('scanned', '已扫码，请在手机豆包中确认登录，然后点击“刷新登录状态”。')
            elif state == 'new': pass
            else: raise AccountError('无法识别扫码状态，未保存登录信息；请重新扫码。')
            self.pause(min(1.5, self.check()))


def probe_account(client, session, check):
    for key, value in session['cookies'].items(): client.cookies.set(key, value, domain='www.doubao.com', path='/')
    check()
    # /api/user/info returned 401 even after successful QR authorization. Use
    # the Passport account endpoint used by the website, without generating images.
    response = client.get(ORIGIN + ACCOUNT_INFO_PATH, timeout=min(15, check()))
    check()
    if response.status_code in (401, 403):
        raise AccountError('豆包账号接口拒绝查询（HTTP ' + str(response.status_code) + '）。本次未确认登录状态，可能需要重新授权或额外验证；不会自动重新扫码。')
    if response.status_code != 200:
        return 'unverified', '已连接到豆包，但账号查询接口不可用（HTTP ' + str(response.status_code) + '）。账号有效性未确认；可重新扫码或尝试生成。', session['name']
    try: result = response.json()
    except ValueError:
        return 'unverified', '已连接到豆包，但查询接口未返回账号资料。不能据此判断已登录；请扫码登录。', session['name']
    if not isinstance(result, dict): raise AccountError('账号查询响应格式无法识别。')
    data = result.get('data') or {}
    if not isinstance(data, dict): data = {}
    code = data.get('error_code', result.get('code', result.get('error_code')))
    if code is not None and str(code) != '0': raise AccountError('账号查询失败（接口码 ' + str(code) + '）。请重新扫码或稍后重试。')
    user = data.get('user') or data.get('user_info') or data
    if not isinstance(user, dict): user = {}
    uid = user.get('user_id_str') or user.get('user_id') or user.get('uid')
    visitor = user.get('is_visitor_account')
    if uid and str(uid) != '0' and visitor not in (True, 1, '1', 'true') and result.get('message', 'success') == 'success':
        name = str(user.get('screen_name') or user.get('nickname') or user.get('name') or session['name'])
        return 'done', '账号连接检查通过，扫码登录有效。可返回主窗口开始生成；此检查未上传或生成图片。', name
    return 'unverified', '已连接到豆包，但未获得已登录用户信息。请扫码登录；不能仅凭本地 Cookie 判断连接成功。', session['name']


def process_account(job: Path, host):
    request = host.read_json(job / 'request.json')
    kind = request.get('kind')
    session = None
    deadline = time.monotonic() + (120 if kind == 'login' else 35)
    def publish(state, message):
        host.atomic_json(job / 'status.json', {'state': state, 'message': message, 'kind': kind, 'updated_at': int(time.time())})
        with (job / 'worker.log').open('a', encoding='utf-8') as log:
            log.write(time.strftime('%Y-%m-%d %H:%M:%S ') + state + ' ' + message + '\n')
    def check():
        if (job / 'cancel.flag').exists(): raise AccountCancelled('已取消本次登录或检查，原账号保留。')
        seconds = deadline - time.monotonic()
        if seconds <= 0: raise AccountError('二维码或连接检查已超时，请重新操作。')
        return seconds
    try:
        publish('starting', '正在通过 HTTP 获取登录二维码……' if kind == 'login' else '正在通过 HTTP 检查已保存的账号；不会生成图片……')
        headers = {'User-Agent': host.UA, 'Origin': ORIGIN, 'Referer': ORIGIN + '/chat/login'}
        with httpx.Client(headers=headers, trust_env=False, follow_redirects=False) as client:
            if kind == 'login':
                session = QRFlow(client, job, publish, check).run()
                check()
                session = host.normalize_session(session)
                info = {'name': session['name'], 'auth_state': 'authorized',
                        'message': '手机扫码授权已完成；图片生成接口尚未验证', 'checked_at': int(time.time()), 'session_marker': host.session_marker(session)}
                if request.get('managed') is True:
                    host.atomic_json(job / 'account-result.json', {'session': session, 'info': info})
                else:
                    host.atomic_json(host.RUNTIME / 'http-session.json', session)
                    host.atomic_json(host.RUNTIME / 'http-account-info.json', info)
                publish('done', '扫码登录成功，账号已保存。点击“返回主窗口”，再点“开始生成”。无需导入账号文件。')
            elif kind == 'check':
                session = (host.normalize_session(host.read_json(job / 'account-session.json'))
                           if request.get('managed') is True else host.load_session(request.get('session_file')))
                state, message, name = probe_account(client, session, check)
                info = {'name': name, 'auth_state': state, 'message': message, 'checked_at': int(time.time()), 'session_marker': host.session_marker(session)}
                if request.get('managed') is True: host.atomic_json(job / 'account-result.json', {'session': session, 'info': info})
                else: host.atomic_json(host.RUNTIME / 'http-account-info.json', info)
                publish(state, message)
            else: raise AccountError('未知的账号操作。')
    except AccountCancelled as exc: publish('cancelled', str(exc))
    except Exception as exc:
        if isinstance(exc, (AccountError, host.UserError)): message = str(exc)
        elif isinstance(exc, httpx.TimeoutException): message = '连接豆包超时，请检查网络后重试；未打开浏览器。'
        elif isinstance(exc, httpx.RequestError): message = '连接豆包失败，请检查网络后重试；未打开浏览器。'
        else: message = '账号操作失败（' + type(exc).__name__ + '）。原有账号保留，请查看本任务日志。'
        if kind == 'check' and session:
            info = {'name': session['name'], 'auth_state': 'error', 'message': message,
                    'checked_at': int(time.time()), 'session_marker': host.session_marker(session)}
            if request.get('managed') is True: host.atomic_json(job / 'account-result.json', {'session': session, 'info': info})
            else: host.atomic_json(host.RUNTIME / 'http-account-info.json', info)
        publish('error', message)
    finally:
        # Do not keep live authorization QR images after the flow ends.
        (job / 'qrcode.png').unlink(missing_ok=True)
        (job / 'qrcode.tmp').unlink(missing_ok=True)
        (job / 'account-session.json').unlink(missing_ok=True)
