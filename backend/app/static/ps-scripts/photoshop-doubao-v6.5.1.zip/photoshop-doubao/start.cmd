@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto missing
".venv\Scripts\python.exe" -X utf8 bridge_worker.py --prepare
echo Open Doubao_RemoveText.jsx in Photoshop. No background service or browser is used.
pause
exit /b
:missing
echo Run install.cmd first.
pause
