﻿# 第三方来源

1. 用户提供的参考项目：https://github.com/SeiShonagon520/doubao2api
   固定版本 a33787d5421ec8bf4b9c6cab0be24e95e4433486。
   参考其图片上传、图片编辑消息、SSE 结果结构，以及 qr_login.py 的 HTTP 扫码授权流程；新 worker 重写为独立同步 HTTP 调用，未加载其服务器、账号监控或浏览器客户端。
   原项目 Apache-2.0 许可证保留在 references/doubao2api-LICENSE。本地旧 vendor 仅保留作参考，不进入新版 ZIP、不被运行。

2. 纯 Python 签名组件来源：https://github.com/5201213/doubao-free-api
   仅安装 pure_signer.py，固定版本 0240ee33f5156d26da72c0eb4b093389e9ca9ad4。
   SHA256: be9927d53abe10a88101eb09ab93c528ca22a5302cd0d4c8dfe22984d1d4c434
   经静态检查，该文件仅使用 Python 标准库；加载时隔离原项目 config，只注入两个配置常量，不加载原应用。
   未发现该固定版本的仓库根 LICENSE，因此此文件不包含在交付 ZIP，也不宣称采用本项目 MIT 许可。安装器从原地址下载到用户本地 runtime/http-signer 并核对哈希。第三方许可状态由其作者决定。
   本项目没有复制或运行其 uploader、服务端、浏览器逻辑或其他应用模块。

3. HTTP 与图片依赖版本固定在 requirements.lock.txt，分别遵循其原许可证。旧环境中遗留的 Playwright 等包不被新版导入；新安装器不安装它们。

4. Photoshop API 与 ScriptUI 参考 Adobe 官方文档：
   https://github.com/Adobe-CEP/CEP-Resources/tree/master/Documentation/Product%20specific%20Documentation/Photoshop%20Scripting
   https://github.com/Adobe-CEP/CEP-Resources/tree/master/ExtendScript-Toolkit/Guides

本项目新增代码采用根目录 LICENSE 中的 MIT 许可；参考项目的原有权利及通知单独保留。

账号查询端点与响应字段另核对 opencli 的 doubao/auth.js：
https://github.com/jackwener/opencli/blob/main/clis/doubao/auth.js
仅核对 HTTP 端点和字段，不加载或分发该项目浏览器执行代码。


5. v6.1 无水印原图协议核对：
   https://github.com/sanshidi/doubao-web-mcp
   固定版本 9b2824778f45d55b32e9074f6e2827071ae0f0bf。
   2026-11-03 通过 GitHub 固定版本读取 doubao_client.py、README.md 和 LICENSE，核对 memory_type=0 保存历史，以及 image_ori_raw / image_raw / dwm3 与 lwm3 的说明。本项目自行实现字段选择和队列逻辑，不导入该项目应用、MCP 或浏览器组件，不启用其其他功能。
   对方 Apache-2.0 许可证保留于 references/doubao-web-mcp-LICENSE。v6.2 另核对其中命名事件及 2074 图片块结构，并以本机用户既有会话的脱敏结构作回归；仅从已生成会话下载原图，没有发起新的生成。参考仓库中的实验结论不等于本机完整验收结果。

6. v6.1 完成通知使用本机 Windows PowerShell 5.1、Windows Forms 及 Photoshop 已注册 COM 对象。只调用已打开的 PS 脚本界面，不启动浏览器或新 Photoshop 实例。无额外安装包。
