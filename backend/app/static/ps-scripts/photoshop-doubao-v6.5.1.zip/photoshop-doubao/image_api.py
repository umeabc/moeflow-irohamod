"""Explicit HTTP image-edit adapters. One POST, bounded read-only task polling."""
import base64
import binascii
import json
import re
import time
from urllib.parse import urlsplit

import ark_api
from generation_profiles import validate_api
from api_diagnostics import response_details

MAX_RESULT = ark_api.MAX_RESULT
EDIT_INSTRUCTION = ark_api.EDIT_INSTRUCTION.replace('image 字段提供的', '附件提供的')


def read_response(client, method, endpoint, check, diagnostic, error, profile, prompt, **kwargs):
    started = time.monotonic()
    with client.stream(method, endpoint, timeout=check(), **kwargs) as response:
        body = bytearray()
        for chunk in response.iter_bytes():
            check()
            body.extend(chunk)
            if len(body) > MAX_RESULT * 4 // 3 + 1024 * 1024:
                raise error('API 响应超过本机处理上限；未重复提交。')
        diagnostic.http('generating', response, (time.monotonic() - started) * 1000)
        try: data = json.loads(body)
        except (ValueError, UnicodeError): data = None
        if response.status_code != 200 or not isinstance(data, dict) or data.get('error'):
            ark_api.fail_response(response, data, error, profile, prompt, EDIT_INSTRUCTION + prompt)
        return data, response_details(response, data, (profile['api_key'], prompt, EDIT_INSTRUCTION + prompt))


def image_result(item, reference_status, error):
    if not isinstance(item, dict): raise error('API 未返回有效的图片结果，未自动重试。')
    encoded = item.get('b64_json')
    if encoded is not None:
        try:
            if not isinstance(encoded, str) or len(encoded) > MAX_RESULT * 4 // 3 + 4: raise ValueError()
            raw = base64.b64decode(encoded, validate=True)
            if not raw or len(raw) > MAX_RESULT: raise ValueError()
        except (ValueError, binascii.Error): raise error('API 返回图片编码无效或超过 50 MB。')
        return {'bytes': raw, 'source': 'api_base64', 'reference_status': reference_status}
    url = item.get('url')
    try:
        parts = urlsplit(url) if isinstance(url, str) else None
        valid = parts and parts.scheme == 'https' and parts.hostname and not parts.username and not parts.password
    except ValueError: valid = False
    if not valid: raise error('API 未返回有效的 HTTPS 图片地址，未自动重试。')
    return {'url': url, 'source': 'api_url', 'reference_status': reference_status}


def reference_status(data, detail, diagnostic, error):
    usage = data.get('usage') if isinstance(data.get('usage'), dict) else {}
    count = usage.get('input_images')
    valid = isinstance(count, int) and not isinstance(count, bool) and 0 <= count <= 10000
    state = ('confirmed' if count == 1 else 'rejected' if count == 0 else 'unexpected') if valid else 'not_reported'
    diagnostic.api_response({'input_images': count, 'generated_images': usage.get('generated_images'),
                             'reference_status': state, 'request_id': detail.get('request_id')})
    if valid and count != 1:
        raise error('API 参考图接收数量异常（输入图片 ' + str(count) + ' 张，应为 1 张），已阻止下载和导入，未自动重试。')
    return state


def generate(client, profile, upload_path, prompt, check, diagnostic, error):
    profile = validate_api(profile, error)
    protocol = profile['protocol']
    if protocol == 'seedream':
        return ark_api.generate(client, profile, upload_path, prompt, check, diagnostic, error)
    from PIL import Image
    raw = upload_path.read_bytes()
    # A shared conservative limit avoids sending a reference too large for Gemini.
    if not raw or len(raw) > 14 * 1024 * 1024:
        raise error('此图片编辑协议的上传副本上限为 14 MB，请缩小图层后重试。')
    try:
        with Image.open(upload_path) as image:
            if image.format != 'PNG': raise ValueError()
            w, h = image.size
            image.verify()
    except (OSError, ValueError): raise error('API 参考图不是有效 PNG，未提交。')
    encoded = base64.b64encode(raw).decode('ascii')
    if base64.b64decode(encoded, validate=True) != raw: raise error('API 参考图编码校验失败，未提交。')
    transport = 'multipart_png' if protocol == 'openai' else 'inline_data_png' if protocol == 'gemini' else 'data_uri_png'
    diagnostic.input_image({'width': w, 'height': h, 'bytes': len(raw), 'count': 1, 'transport': transport,
                            'png_verified': True, 'encoding_verified': True, 'edit_instruction': 'preserve_source_v1'})
    headers = {'x-goog-api-key': profile['api_key']} if profile['auth_mode'] == 'google' else {'Authorization': 'Bearer ' + profile['api_key']}
    endpoint = profile['endpoint'].replace('{model}', profile['model'])
    request_prompt = EDIT_INSTRUCTION + prompt
    fields = {'model': profile['model'], 'prompt': request_prompt}
    if protocol == 'openai':
        fields.update(n='1', size=profile['size'], quality=profile['quality'])
        # httpx owns the multipart boundary. Do not set Content-Type manually.
        kwargs = {'data': fields, 'files': {'image': ('layer.png', raw, 'image/png')}}
        summary_fields = list(fields) + ['image']
    elif protocol == 'gemini':
        config = {'responseModalities': ['TEXT', 'IMAGE']}
        if profile['size'] != 'auto': config['imageConfig'] = {'imageSize': profile['size']}
        payload = {'contents': [{'role': 'user', 'parts': [{'text': request_prompt},
                    {'inlineData': {'mimeType': 'image/png', 'data': encoded}}]}], 'generationConfig': config}
        kwargs = {'json': payload}
        summary_fields = list(payload)
    else:
        # Documented Grsai JSON protocol: references accept base64 or URLs.
        payload = {'model': profile['model'], 'prompt': request_prompt,
                   'images': ['data:image/png;base64,' + encoded], 'replyType': 'json'}
        if profile['provider'] == 'gemini':
            payload['aspectRatio'] = 'auto'
            if profile['size'] != 'auto': payload['imageSize'] = profile['size']
        else:
            if profile['size'] != 'auto': payload['aspectRatio'] = profile['size']
            payload['quality'] = profile['quality']
        kwargs = {'json': payload}
        summary_fields = list(payload)
    diagnostic.api_request({'billing_mode': profile['billing_mode'], 'protocol': protocol,
        'provider': profile['provider'], 'auth_mode': profile['auth_mode'], 'size': profile['size'],
        'model_family': 'gpt_image' if profile['provider'] == 'openai' else 'gemini_image', 'fields': summary_fields})
    data, detail = read_response(client, 'POST', endpoint, check, diagnostic, error, profile, prompt, headers=headers, **kwargs)
    if protocol == 'grsai':
        # Only GET an exact task returned by this POST, at the same origin.
        # No arbitrary URL or secondary generation route is followed.
        state, identity = data.get('status'), data.get('id')
        if state in ('queued', 'pending', 'running', 'processing'):
            if not isinstance(identity, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,150}', identity):
                raise error('中转返回的任务编号无效，未重复提交。')
            parts = urlsplit(endpoint)
            query_url = parts.scheme + '://' + parts.netloc + '/v1/api/result'
            while state in ('queued', 'pending', 'running', 'processing'):
                until = time.monotonic() + min(3, check())
                while time.monotonic() < until:
                    check()
                    time.sleep(min(0.2, max(0, until - time.monotonic())))
                data, detail = read_response(client, 'GET', query_url, check, diagnostic, error, profile, prompt,
                                            headers=headers, params={'id': identity})
                if data.get('id') != identity: raise error('中转返回了其他任务的结果，已停止，未导入。')
                state = data.get('status')
        if state != 'succeeded': raise error('中转任务未成功或返回了无法识别的任务状态，请导出日志；未重复生成。')
    ref = reference_status(data, detail, diagnostic, error)
    if protocol == 'gemini':
        candidates = data.get('candidates')
        candidate = candidates[0] if isinstance(candidates, list) and candidates and isinstance(candidates[0], dict) else {}
        if candidate.get('finishReason') not in (None, 'STOP'):
            raise error('Gemini 未完整返回图片，可能是审核、限制或生成中断；未重复提交。')
        content = candidate.get('content') if isinstance(candidate.get('content'), dict) else {}
        for part in content.get('parts', []) if isinstance(content.get('parts'), list) else []:
            if not isinstance(part, dict) or part.get('thought') is True: continue
            inline = part.get('inlineData', part.get('inline_data'))
            if isinstance(inline, dict) and inline.get('mimeType', inline.get('mime_type')) in ('image/png', 'image/jpeg', 'image/webp'):
                check()
                return image_result({'b64_json': inline.get('data')}, ref, error)
        raise error('Gemini 只返回文本或没有图片；请核对模型具备图片编辑能力，未自动重试。')
    items = data.get('results' if protocol == 'grsai' else 'data')
    first = items[0] if isinstance(items, list) and items else None
    check()
    result = image_result(first, ref, error)
    if protocol == 'grsai' and isinstance(data.get('id'), str) and re.fullmatch(r'[A-Za-z0-9_-]{1,150}', data['id']):
        parts = urlsplit(endpoint)
        result.update(task_id=data['id'], endpoint=endpoint, query_endpoint=parts.scheme + '://' + parts.netloc + '/v1/api/result')
    return result
