"""Offline tests only. No real accounts, external network or Photoshop automation."""
import ast
from io import BytesIO
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import bridge_worker as worker
import httpx
from PIL import Image

SESSION = {'name': 'fake-test', 'cookies': {'sessionid': 'fake-secret', 's_v_web_id': 'verify_test'},
           'params': {'device_id': '123', 'web_id': '456', 'fp': 'verify_test'}}

def event(url='https://cdn.example/image.png'):
    message = {'content_type': 2010, 'content': json.dumps({'data': [{'key': 'first-image', 'image_ori_raw': {'url': url}}]})}
    return {'event_type': 2001, 'event_data': json.dumps({'message': json.dumps(message)})}

class OfflineHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.job = self.root / 'runtime/jobs/1-1'
        self.job.mkdir(parents=True)
        self.patches = [patch.object(worker, 'ROOT', self.root), patch.object(worker, 'RUNTIME', self.root / 'runtime')]
        for item in self.patches: item.start()
        worker.atomic_json(self.root / 'config.json', {'timeout_seconds': 600})
        worker.atomic_json(self.root / 'runtime/http-session.json', SESSION)
        worker.atomic_json(self.job / 'request.json', {'width': 8, 'height': 10, 'prompt': '移除文字'})
        source = Image.new('RGBA', (8, 10), (0, 0, 0, 0))
        for x in range(2, 7):
            for y in range(1, 9): source.putpixel((x, y), (55, 66, 77, 128 if x == 2 else 255))
        source.save(self.job / 'source.png')
        self.original_client = httpx.Client
        self.calls = []
    def tearDown(self):
        for item in reversed(self.patches): item.stop()
        self.temp.cleanup()
    def handler(self, request):
        self.calls.append(request)
        if request.method == 'GET' and request.url.path == '/chat/':
            return httpx.Response(200, text='mock initial session', headers={'content-type': 'text/html'})
        if request.url.path == '/samantha/pages/upload_image':
            self.assertIn('fake-secret', request.headers.get('cookie', ''))
            self.assertIn(b'name="data"', request.content)
            return httpx.Response(200, json={'code': 0, 'data': {'uri': 'test-uri'}})
        if request.url.path == '/alice/message/get_file_url':
            self.assertIn('fake-secret', request.headers.get('cookie', ''))
            self.assertEqual(json.loads(request.content), {'uris': ['test-uri'], 'type': 'image', 'format': 'png', 'expire_second': 3600})
            return httpx.Response(200, json={'code': 0, 'data': {'file_urls': [
                {'uri': 'tos-test/canonical-image', 'main_url': 'https://cdn.example/source.png'}]}})
        if request.url.path == '/samantha/chat/completion':
            payload = json.loads(request.content)
            self.assertEqual(payload['messages'][0]['attachments'][0]['key'], 'tos-test/canonical-image')
            self.assertEqual(json.loads(payload['messages'][0]['content'])['text'], '移除文字')
            self.assertEqual(payload['completion_option']['memory_type'], 0)
            data = json.dumps(event())
            return httpx.Response(200, headers={'content-type': 'text/event-stream'},
                                  text='data: ' + data + '\n\ndata: ' + data + '\n\ndata: [DONE]\n\n')
        if request.url.host == 'cdn.example':
            self.assertNotIn('cookie', request.headers)
            self.assertNotIn('authorization', request.headers)
            image = BytesIO()
            Image.new('RGB', (30, 2), 'red').save(image, format='PNG')
            return httpx.Response(200, content=image.getvalue())
        self.fail('Unexpected request: ' + request.url.path)
    def run_job(self, handler=None):
        transport = httpx.MockTransport(handler or self.handler)
        def client(**kwargs): return self.original_client(transport=transport, **kwargs)
        # Protocol tests never call a signer/network with real login data.
        with patch.object(worker, 'load_signer', return_value=lambda p: {'signed_url': p['url'] + '&a_bogus=fake'}), patch('httpx.Client', side_effect=client):
            worker.process_job(self.job)
        return worker.read_json(self.job / 'status.json')
    def test_upload_671020000_explains_no_generation_and_keeps_error_code(self):
        def handler(request):
            if request.url.path == '/chat/': return self.handler(request)
            self.calls.append(request)
            self.assertEqual(request.url.path, '/samantha/pages/upload_image')
            return httpx.Response(200, json={'code': 671020000, 'message': 'unclassified upstream private-message'})
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'error')
        self.assertEqual(status['stage'], 'uploading')
        self.assertFalse(status['attachment_resolved'])
        self.assertIn('尚未提交生成', status['message'])
        self.assertIn('可选择本层重试', status['message'])
        self.assertNotIn('private-message', status['message'])
        self.assertEqual(worker.read_json(self.job / 'diagnostic.json')['api_codes'], ['671020000'])
        self.assertEqual(len(self.calls), 3)
        uploads = worker.read_json(self.job / 'diagnostic.json')['uploads']
        self.assertEqual([row['attempt'] for row in uploads], [1, 2])
        self.assertTrue(uploads[0]['will_retry'])
        self.assertFalse(uploads[1]['will_retry'])
    def test_complete_job_size_alpha_cdn_cookie_isolation_and_single_submission(self):
        status = self.run_job()
        self.assertEqual(status['state'], 'done', status)
        self.assertEqual(status['generated_size'], [30, 2])
        self.assertEqual(status['alpha_bounds'], [2, 1, 7, 9])
        with Image.open(self.job / 'result.png') as result, Image.open(self.job / 'source.png') as source:
            self.assertEqual(result.size, (8, 10))
            self.assertEqual(result.getchannel('A').tobytes(), source.getchannel('A').tobytes())
        self.assertEqual(sum(r.url.path == '/samantha/chat/completion' for r in self.calls), 1)
        self.assertEqual([r.url.path for r in self.calls[:4]], [
            '/chat/', '/samantha/pages/upload_image', '/alice/message/get_file_url', '/samantha/chat/completion'])
        self.assertTrue(status['attachment_resolved'])
        self.assertEqual(status['worker_version'], 'http-v6.5.1')
        self.assertEqual(status['result_source'], 'server_original')
        self.assertTrue(status['saved_to_history'])
        self.assertTrue((self.job / 'preview.png').exists())
        self.assertFalse((self.job / 'generated.download').exists())
        self.assertNotIn('fake-secret', (self.job / 'worker.log').read_text(encoding='utf-8'))
    def test_auth_failure_does_not_retry_or_produce_image(self):
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                return httpx.Response(403, text='private upstream error')
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'error')
        self.assertIn('HTTP 403', status['message'])
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
        self.assertFalse((self.job / 'result.png').exists())
    def test_resolver_invalid_or_missing_attachment_stops_before_generation(self):
        for data in ({}, {'file_urls': []}, {'file_urls': [{}]}, {'file_urls': ['bad']},
                     {'file_urls': [{'uri': 123}]}, {'file_urls': [{'uri': ' '}]},
                     {'file_urls': [{'uri': 'https://cdn.example/not-an-attachment'}]}, ['bad']):
            with self.subTest(data=data):
                self.calls.clear()
                def handler(request):
                    if request.url.path == '/alice/message/get_file_url':
                        self.calls.append(request)
                        return httpx.Response(200, json={'code': 0, 'data': data})
                    return self.handler(request)
                status = self.run_job(handler)
                self.assertEqual(status['state'], 'error')
                self.assertEqual(status['stage'], 'resolving')
                self.assertIn('附件解析', status['message'])
                self.assertFalse(status['attachment_resolved'])
                self.assertFalse(any(r.url.path.endswith('/completion') for r in self.calls))
                self.assertFalse((self.job / 'result.png').exists())
    def test_resolver_api_failure_never_falls_back_to_short_uri(self):
        def handler(request):
            if request.url.path == '/alice/message/get_file_url':
                self.calls.append(request)
                return httpx.Response(200, json={'code': 701, 'message': 'invalid attachment'})
            return self.handler(request)
        status = self.run_job(handler)
        self.assertIn('接口码 701', status['message'])
        self.assertIn('参数或附件无效', status['message'])
        self.assertFalse(any(r.url.path.endswith('/completion') for r in self.calls))
    def test_cancellation_after_upload_stops_before_resolver_and_generation(self):
        def handler(request):
            response = self.handler(request)
            if request.url.path.endswith('/upload_image'): (self.job / 'cancel.flag').touch()
            return response
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'cancelled')
        self.assertEqual(len(self.calls), 2)

    def test_first_rejected_upload_refreshes_csrf_and_retries_identical_bytes_once(self):
        from email import policy
        from email.parser import BytesParser
        worker.atomic_json(self.root/'runtime/http-session.json', {**SESSION,
            'cookies':{**SESSION['cookies'],'passport_csrf_token':'stale-host-csrf'}})
        files, tokens = [], []
        def handler(request):
            if request.url.path == '/chat/':
                self.calls.append(request)
                return httpx.Response(200, headers={'set-cookie': 'passport_csrf_token=initial-csrf; Domain=.doubao.com; Path=/'})
            if request.url.path.endswith('/upload_image'):
                self.calls.append(request)
                parts = BytesParser(policy=policy.default).parsebytes(
                    ('Content-Type: '+request.headers['content-type']+'\r\n\r\n').encode()+request.content)
                files.append(next(p.get_payload(decode=True) for p in parts.iter_parts() if p.get_param('name', header='content-disposition') == 'data'))
                tokens.append(request.headers['x-tt-passport-csrf-token'])
                self.assertEqual(request.headers['cookie'].count('passport_csrf_token='),1)
                if len(files) == 1:
                    return httpx.Response(200, json={'code':671020000},
                        headers={'set-cookie':'passport_csrf_token=refreshed-csrf; Domain=.doubao.com; Path=/'})
                return httpx.Response(200, json={'code':0,'data':{'uri':'test-uri'}})
            return self.handler(request)
        with patch.object(worker.time, 'sleep'):
            result = self.run_job(handler)
        self.assertEqual(result['state'], 'done', result)
        self.assertEqual(tokens, ['initial-csrf', 'refreshed-csrf'])
        self.assertEqual(files[0], files[1])
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
        d = worker.read_json(self.job/'diagnostic.json')
        self.assertEqual(d['input_image']['transport'], 'multipart_png')
        self.assertEqual([u['code'] for u in d['uploads']], ['671020000','0'])
        self.assertNotIn('refreshed-csrf', json.dumps(d))

    def test_default_csrf_and_initialized_ms_token_are_used_on_first_upload(self):
        worker.atomic_json(self.root/'runtime/http-session.json', {**SESSION,
            'cookies':{**SESSION['cookies'],'passport_csrf_token_default':'fallback-csrf'}})
        def handler(request):
            if request.url.path == '/chat/':
                self.calls.append(request)
                return httpx.Response(200, headers={'set-cookie':'msToken=fresh-test-token; Domain=.doubao.com; Path=/'})
            if request.url.path.endswith('/upload_image'):
                self.assertEqual(request.headers['x-tt-passport-csrf-token'], 'fallback-csrf')
                self.assertEqual(request.url.params['msToken'], 'fresh-test-token')
            return self.handler(request)
        self.assertEqual(self.run_job(handler)['state'], 'done')
        row=worker.read_json(self.job/'diagnostic.json')['uploads'][0]
        self.assertTrue(row['initialized'])
        self.assertTrue(row['has_ms_token'])
        self.assertEqual(row['csrf_source'], 'default')

    def test_classified_upload_rejections_are_never_retried(self):
        for message in ('content moderation rejected', 'risk control', 'captcha required', 'not logged in', 'quota exceeded', 'invalid attachment'):
            with self.subTest(message=message):
                self.calls.clear()
                def handler(request):
                    if request.url.path.endswith('/upload_image'):
                        self.calls.append(request)
                        return httpx.Response(200,json={'code':671020000,'message':message+' fake-secret'})
                    return self.handler(request)
                self.assertEqual(self.run_job(handler)['state'], 'error')
                self.assertEqual(sum(r.url.path.endswith('/upload_image') for r in self.calls), 1)
                self.assertFalse(any(r.url.path.endswith('/completion') for r in self.calls))

    def test_initialization_refusal_stops_before_upload_and_generation(self):
        def handler(request):
            self.calls.append(request)
            self.assertEqual(request.url.path, '/chat/')
            return httpx.Response(403,text='private challenge')
        result=self.run_job(handler)
        self.assertEqual(result['state'], 'error')
        self.assertEqual(result['stage'], 'initializing')
        self.assertEqual(len(self.calls), 1)

    def test_cancel_after_rejected_upload_prevents_second_upload(self):
        def handler(request):
            if request.url.path.endswith('/upload_image'):
                self.calls.append(request)
                (self.job/'cancel.flag').touch()
                return httpx.Response(200,json={'code':671020000})
            return self.handler(request)
        self.assertEqual(self.run_job(handler)['state'], 'cancelled')
        self.assertEqual(sum(r.url.path.endswith('/upload_image') for r in self.calls), 1)

    def test_uncertain_upload_transport_failure_is_not_retried(self):
        def handler(request):
            if request.url.path.endswith('/upload_image'):
                self.calls.append(request)
                raise httpx.ReadTimeout('private signed-url',request=request)
            return self.handler(request)
        self.assertEqual(self.run_job(handler)['state'], 'error')
        self.assertEqual(sum(r.url.path.endswith('/upload_image') for r in self.calls), 1)
    def test_generation_error_keeps_verified_account_and_does_not_retry(self):
        session = worker.load_session()
        info = {'name': 'fake-test', 'message': '账号连接检查通过', 'session_marker': worker.session_marker(session)}
        worker.atomic_json(self.root / 'runtime/http-account-info.json', info)
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                detail = {'code': 710020702, 'message': 'invalid parameter fake-secret https://private.example/?token=secret 移除文字'}
                frame = {'event_type': 2005, 'event_data': json.dumps(detail)}
                return httpx.Response(200, text='data: ' + json.dumps(frame) + '\n\n')
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'error')
        self.assertEqual(status['stage'], 'generating')
        self.assertTrue(status['attachment_resolved'])
        self.assertIn('710020702', status['message'])
        diagnostic = worker.read_json(self.job / 'diagnostic.json')
        self.assertEqual(diagnostic['api_codes'], ['2005', '710020702'])
        self.assertIn('参数或附件无效', status['message'])
        self.assertNotIn('请更新会话', status['message'])
        self.assertEqual(worker.read_json(self.root / 'runtime/http-account-info.json'), info)
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
        self.assertFalse((self.job / 'result.png').exists())
        logged = (self.job / 'worker.log').read_text(encoding='utf-8') + json.dumps(status, ensure_ascii=False)
        for secret in ('fake-secret', 'private.example', 'token=secret', '移除文字'):
            self.assertNotIn(secret, logged)
    def test_upstream_arbitrary_error_code_and_message_are_not_logged(self):
        detail = {'code': 'https://private.example/?sessionid=secret', 'message': 'echo private prompt fake-secret'}
        error = worker.api_error('豆包生成', '接口码 ' + worker.response_code(detail), detail)
        self.assertIn('接口码 未知', str(error))
        for secret in ('private.example', 'fake-secret', 'private prompt'):
            self.assertNotIn(secret, str(error))
    def stream_response(self, items):
        message = {'content_type': 2010, 'content': json.dumps({'data': items})}
        frame = {'event_type': 2001, 'event_data': json.dumps({'message': message})}
        return httpx.Response(200, text='data: ' + json.dumps(frame) + '\n\ndata: [DONE]\n\n')
    def test_original_is_preferred_without_modifying_signed_cdn_url(self):
        clean = 'https://cdn.example/asset~tplv-test-image_raw.png?signature=keep-exact'
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                self.assertEqual(json.loads(request.content)['completion_option']['memory_type'], 0)
                return self.stream_response([{'key': 'same', 'image_ori': {'url': 'https://cdn.example/asset~tplv-test-cgen_lwm3.png'},
                    'image_ori_raw': {'url': clean}, 'image_raw': {'url': 'https://cdn.example/asset~tplv-test-cthumb_dwm3.png'}}])
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'done', status)
        self.assertEqual(str(self.calls[-1].url), clean)
        self.assertEqual(status['result_source'], 'server_original')
    def test_dwm3_is_accepted_when_original_absent(self):
        clean = 'https://cdn.example/asset~tplv-test-cgen_dwm3.png'
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                return self.stream_response([{'image_ori': {'url': clean}}])
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'done', status)
        self.assertEqual(status['result_source'], 'server_dwm3')
    def test_watermarked_or_unknown_results_are_not_silently_imported(self):
        for filename in ('asset~tplv-test-cgen_lwm3.png', 'image_dld_watermark.png', 'unknown.png'):
            with self.subTest(filename=filename):
                self.calls.clear()
                def handler(request):
                    if request.url.path.endswith('/completion'):
                        self.calls.append(request)
                        return self.stream_response([{'image_ori': {'url': 'https://cdn.example/' + filename}}])
                    return self.handler(request)
                status = self.run_job(handler)
                self.assertEqual(status['state'], 'error')
                self.assertIn('未提供可识别的无水印', status['message'])
                self.assertFalse(any(r.url.host == 'cdn.example' for r in self.calls))
                self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
    def test_does_not_replace_first_image_with_clean_variant_of_other_image(self):
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                return self.stream_response([
                    {'key': 'first', 'image_ori': {'url': 'https://cdn.example/lwm3.png'}},
                    {'key': 'second', 'image_ori_raw': {'url': 'https://cdn.example/clean.png'}}])
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'error')
        self.assertFalse(any(r.url.host == 'cdn.example' for r in self.calls))
    def test_late_original_of_first_image_replaces_earlier_preview(self):
        clean = 'https://cdn.example/final.png'
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                first = self.stream_response([{'key': 'same', 'image_ori': {'url': 'https://cdn.example/lwm3.png'}}]).text
                second = self.stream_response([{'key': 'same', 'image_ori_raw': {'url': clean}}]).text
                return httpx.Response(200, text=first.replace('data: [DONE]\n\n', '') + second)
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'done', status)
        self.assertEqual(str(self.calls[-1].url), clean)
    def test_cancellation_before_submission_uses_no_network(self):
        (self.job / 'cancel.flag').touch()
        status = self.run_job()
        self.assertEqual(status['state'], 'cancelled')
        self.assertEqual(self.calls, [])
    def test_cancellation_during_sse_stops_before_download(self):
        def handler(request):
            response = self.handler(request)
            if request.url.path.endswith('/completion'): (self.job / 'cancel.flag').touch()
            return response
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'cancelled')
        self.assertFalse(any(r.url.host == 'cdn.example' for r in self.calls))
    def test_no_image_and_invalid_download_fail_without_result(self):
        for mode in ('empty', 'invalid-image'):
            self.calls.clear()
            def handler(request):
                if mode == 'empty' and request.url.path.endswith('/completion'):
                    self.calls.append(request)
                    return httpx.Response(200, text='data: [DONE]\n\n')
                if mode == 'invalid-image' and request.url.host == 'cdn.example':
                    self.calls.append(request)
                    return httpx.Response(200, content=b'not an image')
                return self.handler(request)
            status = self.run_job(handler)
            self.assertEqual(status['state'], 'error')
            self.assertFalse((self.job / 'result.png').exists())
            self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
    def test_sse_multiline_and_error_event(self):
        data = event()
        raw = json.dumps(data)
        comma = raw.index(',') + 1
        frames = list(worker.sse_events([': keepalive', 'data: ' + raw[:comma], 'data: ' + raw[comma:], ''], lambda: None))
        self.assertEqual(worker.image_urls(frames[0]), ['https://cdn.example/image.png'])
        with self.assertRaises(worker.UserError): worker.image_urls({'event_type': 2005, 'event_data': '{"code": 701}'})
        with self.assertRaises(worker.UserError): list(worker.sse_events(['{"code": 401}'], lambda: None))
    def test_saved_reference_account_and_cookie_export(self):
        ref = {'active_account_id': 'b', 'accounts': [{'id': 'a', 'cookies': {}}, {'id': 'b', **SESSION}]}
        self.assertEqual(worker.normalize_session(ref)['cookies']['sessionid'], 'fake-secret')
        export = {**SESSION, 'cookies': [{'name': k, 'value': v} for k, v in SESSION['cookies'].items()]}
        self.assertEqual(worker.normalize_session(export)['cookies']['sessionid'], 'fake-secret')
        with self.assertRaises(worker.UserError): worker.normalize_session({'cookies': {}})
    def test_duplicate_job_launcher_is_inert(self):
        args = ['bridge_worker.py', '--job', str(self.job)]
        with patch.object(sys, 'argv', args), patch.object(worker, 'process_job') as process:
            worker.main()
            worker.main()
            self.assertEqual(process.call_count, 1)
    def test_expired_deadline_and_plain_gateway_json(self):
        with self.assertRaises(worker.UserError): worker.remaining(time.monotonic() - 1, self.job)
        with self.assertRaises(worker.UserError): list(worker.sse_events(['{"code": 701}'], lambda: None))

class DependencyTests(unittest.TestCase):
    def test_worker_has_no_browser_launch_imports(self):
        source = Path(worker.__file__).read_text(encoding='utf-8-sig')
        tree = ast.parse(source)
        imports = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import): imports.update(a.name.split('.')[0] for a in node.names)
            if isinstance(node, ast.ImportFrom): imports.add((node.module or '').split('.')[0])
        self.assertFalse(imports & {'playwright', 'selenium', 'webbrowser', 'subprocess', 'doubao2api'})
    def test_installed_signer_offline_smoke_and_hash_check(self):
        signer = worker.load_signer()
        signed = signer({'url': 'https://www.doubao.com/samantha/chat/completion?aid=497858', 'body': '{}', 'signOptions': {'userAgent': worker.UA}})
        self.assertIn('a_bogus=', signed['signed_url'])
        self.assertGreater(len(signed['a_bogus']), 100)

if __name__ == '__main__': unittest.main()
