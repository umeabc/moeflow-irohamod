// Offline tests of the actual JSX queue functions; no Photoshop host or documents.
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const assert = require('assert');
const native = process.binding('natives')['internal/deps/acorn/acorn/dist/acorn'];
const mod = {exports:{}};
vm.runInNewContext(native, {module:mod,exports:mod.exports});
const file = path.join(process.argv[2] || __dirname, '..', 'Doubao_RemoveText.jsx');
const source = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').replace(/^#target photoshop\r?\n/, '');
const tree = mod.exports.parse(source, {ecmaVersion:3});
const functions = {};
function visit(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'FunctionDeclaration') functions[node.id.name] = source.slice(node.start,node.end);
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) value.forEach(visit);
    else if (value && typeof value === 'object') visit(value);
  }
}
visit(tree);
function setup() {
  const disk = new Map(), placements = [], alerts = [];
  const context = vm.createContext({console});
  context.root = {fsName:'C:/test'};
  context.Folder = function(name) { this.fsName = name; this.name = name.split('/').pop(); this.parent={fsName:name.split('/').slice(0,-1).join('/')}; };
  context.child = (folder,name) => ({path:folder.fsName+'/'+name,
    get exists(){return disk.has(this.path);},remove(){disk.delete(this.path);return true;}});
  context.writeText = (file,text) => disk.set(file.path,text);
  context.alert = text => alerts.push(text);
  context.recordPS = () => {};
  context.LayerKind = {NORMAL:1,SMARTOBJECT:2};
  context.originalDoc = {id:42,layers:[
    {id:11,name:'同名',typename:'ArtLayer',kind:1},
    {id:99,typename:'LayerSet',layers:[{id:22,name:'同名',typename:'ArtLayer',kind:2}]}
  ]};
  context.config={accounts:[{id:'account-a',name:'账号 A',session:{cookies:{sessionid:'private-a'},params:{device_id:'1',web_id:'2',fp:'3'}}}],apis:[]};
  context.backend='web';context.accountID='account-a';context.apiID='';context.webUploadMode='separate';
  context.currentIndex = 0;
  context.batchFolder = null;
  context.bounds = layer => vm.runInContext(layer.id === 11 ? '[-10,5,30,25]' : '[100,200,110,230]',context);
  context.statusNow = () => context.child(context.job,'imported.flag').exists ? {state:'imported'} : {state:'done'};
  context.importResult = (status,rect) => {
    if (!context.originalLayer) throw Error('original missing');
    placements.push({id:context.originalLayer.id,box:Array.from(rect),job:context.job.name});
    context.imported = {id:context.originalLayer.id+1000};
  };
  const names = ['fail','quote','encodeJSON','parseJSON','sameBox','findLayer','validateLayer','collectSelected','bindEntry','importReadyResults','profileList','findProfile','generationChoice','validEndpoint','apiEndpointMode','normalizeAPIProfile','validateMergedSelections'];
  vm.runInContext(names.map(name=>functions[name]).join('\n'),context);
  vm.runInContext('entries=collectSelected([11,22]);entries[0].job_name="100-1";entries[1].job_name="100-2";bindEntry(0);',context);
  return {context,disk,placements,alerts};
}
let checks=0;
function test(name, fn) { fn(); checks++; console.log('PASS '+name); }
test('same-name nested layers import using distinct IDs and recorded rectangles',()=>{
  const {context,placements}=setup();
  context.importReadyResults();
  assert.deepStrictEqual(placements,[{id:11,box:[-10,5,30,25],job:'100-1'},{id:22,box:[100,200,110,230],job:'100-2'}]);
});
test('second import does not duplicate already imported layers',()=>{
  const {context,placements}=setup();
  context.importReadyResults(); context.importReadyResults();
  assert.strictEqual(placements.length,2);
});
test('failed layer import leaves other layer correctly mapped and recoverable',()=>{
  const {context,disk,placements}=setup();
  const original = context.importResult;
  context.importResult = (status,rect)=>{if(context.originalLayer.id===11)throw Error('geometry changed');original(status,rect);};
  context.importReadyResults();
  assert.deepStrictEqual(placements.map(p=>p.id),[22]);
  assert(!disk.has('C:/test/runtime/jobs/100-1/importing.flag'));
  assert(disk.has('C:/test/runtime/jobs/100-1/import-error.json'));
  assert(disk.has('C:/test/runtime/jobs/100-2/imported.flag'));
});
test('deleted source cannot send its result into another selected layer',()=>{
  const {context,placements}=setup();
  context.originalDoc.layers.shift();
  context.importReadyResults();
  assert.deepStrictEqual(placements.map(p=>p.id),[22]);
});
test('uncertain disk recording after placement prevents repeat import',()=>{
  const {context,disk,placements}=setup();
  const save = context.writeText;
  context.writeText = (file,text)=>{if(file.path.endsWith('/100-1/imported.flag'))throw Error('disk full');save(file,text);};
  context.importReadyResults(); context.importReadyResults();
  assert.deepStrictEqual(placements.map(p=>p.id),[11,22]);
  assert(disk.has('C:/test/runtime/jobs/100-1/importing.flag'));
});
test('unsupported selection is rejected before any task is exported',()=>{
  const {context,placements}=setup();
  assert.throws(()=>context.collectSelected([11,99]),/像素图层/);
  assert.strictEqual(placements.length,0);
});
test('manifest JSON safely preserves Unicode names and negative positions',()=>{
  const {context}=setup();
  const encoded = vm.runInContext('encodeJSON({name:"中文\\n\\\"引号",items:[{left:-10,width:40}],notify:true})',context);
  assert.deepStrictEqual(JSON.parse(encoded),{name:'中文\n"引号',items:[{left:-10,width:40}],notify:true});
});
test('Photoshop selection uses reference identifiers for multiple layers',()=>{
  const {context}=setup();
  context.stringIDToTypeID = x=>x;
  context.ActionReference = function(){this.putProperty=()=>{};this.putEnumerated=()=>{};};
  context.executeActionGet = ()=>({hasKey:()=>true,getList:()=>({count:2,getReference:i=>({getIdentifier:()=>[22,11][i]})})});
  vm.runInContext(functions.selectedLayerIDs,context);
  assert.deepStrictEqual(Array.from(context.selectedLayerIDs()),[22,11]);
});
test('batch isolates each export and launches only after all exports succeed',()=>{
  const {context,disk}=setup();
  const exports=[], sequence=[];
  let counter=0, selection=[];
  context.prompt='移除文字';context.sessionFile='';context.config.prefer_watermark_free=true;
  context.originalDoc.name='Test.psd';
  context.app={version:'24.0',path:{fsName:'C:/Photoshop'}};
  context.pythonw={fsName:'C:/pythonw.exe'};
  context.selectedIDsAtOpen=[11,22];
  context.makeName=()=> '300-'+(++counter);
  context.ensureFolder=()=>{};
  context.selectIDs=ids=>{selection=Array.from(ids);};
  context.exportSource=()=>{
    assert.deepStrictEqual(selection,[context.originalLayer.id]);
    exports.push(context.originalLayer.id);sequence.push('export');
  };
  context.launchWorker=()=>{sequence.push('launch');};
  vm.runInContext(functions.startBatch,context);
  context.startBatch();
  assert.deepStrictEqual(exports,[11,22]);
  assert.deepStrictEqual(sequence,['export','export','launch']);
  assert.deepStrictEqual(selection,[11,22]);
  const manifest=JSON.parse(disk.get('C:/test/runtime/batches/300-1/request.json'));
  assert.deepStrictEqual(manifest.items.map(x=>x.source_layer_id),[11,22]);
  assert.strictEqual(JSON.parse(disk.get('C:/test/runtime/jobs/300-2/request.json')).source_layer_id,11);
  assert.strictEqual(JSON.parse(disk.get('C:/test/runtime/jobs/300-3/request.json')).source_layer_id,22);
});
test('log export targets the entire current batch without launching generation',()=>{
  const {context,disk}=setup();
  let launches=[];
  context.batchFolder={name:'300-1'};
  context.makeName=()=> '400-1';
  context.ensureFolder=()=>{};
  context.pythonw={fsName:'C:/pythonw.exe'};
  context.File=function(){this.saveDlg=()=>({fsName:'C:/logs.zip',name:'logs.zip'});};
  context.launchWorker=(python,script,task)=>launches.push({script:script.path,task:task.fsName});
  vm.runInContext(functions.exportLogs,context);
  context.exportLogs();
  assert.deepStrictEqual(launches,[{script:'C:/test/support_logs.py',task:'C:/test/runtime/support_jobs/400-1'}]);
  assert.deepStrictEqual(JSON.parse(disk.get('C:/test/runtime/support_jobs/400-1/request.json')),{output:'C:/logs.zip',batch_name:'300-1'});
});
test('cancelling log save dialog creates no task and launches no worker',()=>{
  const {context,disk}=setup();
  context.batchFolder=null;
  context.ensureFolder=()=>{};
  context.File=function(){this.saveDlg=()=>null;};
  context.launchWorker=()=>{throw Error('should not launch');};
  vm.runInContext(functions.exportLogs,context);
  context.exportLogs();
  assert.strictEqual(disk.size,0);
});
function retrySetup(states=['error','done']) {
  const h=setup(), {context:c,disk}=h;
  let counter=0;
  h.exports=[];h.launches=[];
  c.batchFolder=new c.Folder('C:/test/runtime/batches/90-1');
  c.prompt='移除文字';c.sessionFile='';c.config.prefer_watermark_free=true;
  c.originalDoc.name='Test.psd';c.app={version:'24.0',path:{fsName:'C:/Photoshop'}};
  c.pythonw={fsName:'C:/pythonw.exe'};c.selectedIDsAtOpen=[11,22];
  c.makeName=()=> '500-'+(++counter);c.ensureFolder=()=>{};c.selectIDs=()=>{};
  c.exportSource=()=>h.exports.push(c.originalLayer.id);
  c.launchWorker=(python,script,task)=>h.launches.push(task.name);
  c.readText=file=>{if(!disk.has(file.path))throw Error('missing '+file.path);return disk.get(file.path);};
  c.batchIsRunning=()=>false;
  c.statusNow=()=>{
    if(!c.job)return null;
    if(c.child(c.job,'imported.flag').exists)return {state:'imported'};
    return disk.has(c.child(c.job,'status.json').path)?JSON.parse(disk.get(c.child(c.job,'status.json').path)):null;
  };
  c.entries.forEach((entry,i)=>{
    disk.set('C:/test/runtime/jobs/'+entry.job_name+'/request.json',JSON.stringify({...entry,document_id:42,batch_name:'90-1'}));
    disk.set('C:/test/runtime/jobs/'+entry.job_name+'/status.json',JSON.stringify({state:states[i],message:'测试状态'}));
    disk.set('C:/test/runtime/jobs/'+entry.job_name+'/source.png','source-image');
    if(states[i]==='done')disk.set('C:/test/runtime/jobs/'+entry.job_name+'/result.png','result-image');
  });
  disk.set('C:/test/runtime/batches/90-1/request.json',JSON.stringify({schema:1,document_id:42,items:c.entries}));
  disk.set('C:/test/runtime/batches/90-1/status.json',JSON.stringify({state:'partial',message:'测试批次'}));
  disk.set('C:/test/runtime/active-http-batch.json',JSON.stringify({batch_name:'90-1'}));
  vm.runInContext(['startBatch','retryFailed','clearCurrentBatch','readBatch','listIndices'].map(name=>functions[name]).join('\n'),c);
  return h;
}
test('retry re-exports only failed source with current geometry and preserves successful job',()=>{
  const {context:c,disk,exports,launches}=retrySetup();
  const originalRequest=disk.get('C:/test/runtime/jobs/100-1/request.json');
  c.bounds=layer=>vm.runInContext(layer.id===11?'[-20,10,40,30]':'[100,200,110,230]',c);
  c.retryFailed([0,1]);
  assert.deepStrictEqual(exports,[11]);
  assert.deepStrictEqual(launches,['500-1']);
  const batch=JSON.parse(disk.get('C:/test/runtime/batches/500-1/request.json'));
  assert.strictEqual(batch.items[1].job_name,'100-2');assert.strictEqual(batch.items[1].carried,true);
  assert.strictEqual(batch.items[1].carried_from_batch,'90-1');
  const req=JSON.parse(disk.get('C:/test/runtime/jobs/500-2/request.json'));
  assert.strictEqual(req.retry_of,'100-1');assert.strictEqual(req.left,-20);assert.strictEqual(req.width,60);
  assert.strictEqual(disk.get('C:/test/runtime/jobs/100-1/request.json'),originalRequest);
});
test('retry selected failure keeps an unselected failed row visible without exporting it',()=>{
  const {context:c,disk,exports}=retrySetup(['error','error']);
  c.retryFailed([1]);
  assert.deepStrictEqual(exports,[22]);
  const batch=JSON.parse(disk.get('C:/test/runtime/batches/500-1/request.json'));
  assert.strictEqual(batch.items[0].job_name,'100-1');assert.strictEqual(batch.items[0].carried,true);
  assert.strictEqual(batch.items[1].retry_of,'100-2');
});
test('selecting only a successful row cannot trigger regeneration',()=>{
  const {context:c,exports,launches}=retrySetup();
  assert.throws(()=>c.retryFailed([1]),/没有失败图层/);
  assert.deepStrictEqual(exports,[]);assert.deepStrictEqual(launches,[]);
});
test('export failure restores previous list and active pointer without submitting a retry',()=>{
  const {context:c,disk,launches}=retrySetup();
  const originalEntries=c.entries;
  c.exportSource=()=>{throw Error('export failed');};
  assert.throws(()=>c.retryFailed([0]),/export failed/);
  assert.strictEqual(c.entries,originalEntries);assert.strictEqual(c.batchFolder.name,'90-1');
  assert.strictEqual(JSON.parse(disk.get('C:/test/runtime/active-http-batch.json')).batch_name,'90-1');
  assert.deepStrictEqual(launches,[]);
});
test('deleted failed source is rejected before creating a retry or exporting other rows',()=>{
  const {context:c,disk,exports,launches}=retrySetup();
  c.originalDoc.layers.shift();
  assert.throws(()=>c.retryFailed([0]),/像素图层/);
  assert.deepStrictEqual(exports,[]);assert.deepStrictEqual(launches,[]);
  assert(!disk.has('C:/test/runtime/batches/500-1/request.json'));
});
test('clear detaches batch persistently and retains source, result, logs and import records',()=>{
  const {context:c,disk}=retrySetup();
  disk.set('C:/test/runtime/jobs/100-2/imported.flag','imported');
  disk.set('C:/test/runtime/batches/90-1/worker.log','old-log');
  c.clearCurrentBatch();
  assert.strictEqual(c.entries.length,0);assert.strictEqual(c.job,null);assert.strictEqual(c.batchFolder,null);
  assert(!disk.has('C:/test/runtime/active-http-batch.json'));
  assert(disk.has('C:/test/runtime/ui-cleared-42.json'));
  assert(disk.has('C:/test/runtime/batches/90-1/dismissed.flag'));
  assert.strictEqual(disk.get('C:/test/runtime/batches/90-1/worker.log'),'old-log');
  assert.strictEqual(disk.get('C:/test/runtime/jobs/100-2/result.png'),'result-image');
  assert.strictEqual(disk.get('C:/test/runtime/jobs/100-2/imported.flag'),'imported');
});
test('running batch cannot be cleared or retried',()=>{
  const {context:c,disk,launches}=retrySetup();c.batchIsRunning=()=>true;
  const before=Array.from(disk.entries());
  assert.throws(()=>c.clearCurrentBatch(),/等待任务结束/);
  assert.throws(()=>c.retryFailed([0]),/等待当前批次结束/);
  assert.deepStrictEqual(Array.from(disk.entries()),before);assert.deepStrictEqual(launches,[]);
});
test('retry batch can be reopened with carried rows and rejects changed layer mapping',()=>{
  const {context:c,disk}=retrySetup();c.retryFailed([0]);
  c.readBatch(new c.Folder('C:/test/runtime/batches/500-1'));
  assert.strictEqual(c.entries[1].job_name,'100-2');
  const req=JSON.parse(disk.get('C:/test/runtime/jobs/100-2/request.json'));req.source_layer_id=999;
  disk.set('C:/test/runtime/jobs/100-2/request.json',JSON.stringify(req));
  assert.throws(()=>c.readBatch(new c.Folder('C:/test/runtime/batches/500-1')),/不一致/);
});
test('changed position is blocked before any native Photoshop import action',()=>{
  const {context:c,disk}=setup();
  disk.set('C:/test/runtime/jobs/100-1/result.png','result');
  c.bounds=()=>[-9,5,31,25];
  vm.runInContext(functions.importResult,c);
  assert.throws(()=>c.importResult({width:40,height:20,alpha_bounds:[0,0,40,20]},c.box),/位置或尺寸已变化/);
});
function mockUI(c) {
  const controls=[];
  class Control {
    constructor(type,text,props){this.type=type;this.text=text;this.props=props;this.children=[];this.items=[];this.subItems=[{},{},{}];controls.push(this);if(type==='dropdownlist'&&Array.isArray(text)){text.forEach(v=>this.add('item',undefined,v));}}
    add(type,rect,text,props){const x=new Control(type,text,props);x.index=this.children.length;this.children.push(x);if(type==='item'){x.index=this.items.length;this.items.push(x);}return x;}
    set selection(value){if(this.type==='listbox'){this._selection=Array.isArray(value)?value.map(i=>this.items[i]):this.items[value];}else if(this.type==='dropdownlist')this._selection=typeof value==='number'?this.items[value]:value;else this._selection=value;}
    get selection(){return this._selection;}
    show(){} close(){}
  }
  c.Window=function(type,title){return new Control(type,title);};
  c.notice='';c.uiTab=0;c.selectedRowIndices=[];
  c.batchStatus=()=>({message:'测试批次'});
  vm.runInContext(functions.showUI,c);
  return controls;
}
test('UI separates work, account and history tabs and enables only valid task actions',()=>{
  const {context:c}=retrySetup();const controls=mockUI(c);c.showUI({state:'error'});
  assert.deepStrictEqual(controls.filter(x=>x.type==='tab').map(x=>x.text),['图层与结果','生成与账号','日志与历史']);
  const button=text=>controls.find(x=>x.type==='button'&&x.text===text);
  assert.strictEqual(button('开始生成').enabled,false);assert.strictEqual(button('重试所选失败').enabled,true);
  assert.strictEqual(button('清空当前批次').enabled,true);assert.strictEqual(button('导入全部成功结果').enabled,true);
});
test('empty list UI remains usable and cannot generate, import or retry',()=>{
  const {context:c}=retrySetup();c.clearCurrentBatch();const controls=mockUI(c);c.showUI(null);
  for(const name of ['开始生成','重试所选失败','重试全部失败','导入全部成功结果','清空当前批次']){
    assert.strictEqual(controls.find(x=>x.type==='button'&&x.text===name).enabled,false,name);
  }
  assert.strictEqual(controls.find(x=>x.type==='button'&&x.text==='读取 PS 所选图层').enabled,true);
});

test('fixed batch credentials stay separate from public per-layer request metadata',()=>{
  const {context:c,disk}=retrySetup();c.retryFailed([0]);
  const snapshot=JSON.parse(disk.get('C:/test/runtime/batches/500-1/credentials.json'));
  assert.strictEqual(snapshot.profile.cookies.sessionid,'private-a');
  const req=disk.get('C:/test/runtime/jobs/500-2/request.json');
  assert(!req.includes('private-a'));assert(!req.includes('cookies'));
  assert.strictEqual(JSON.parse(req).credential_ref,'500-1');
  c.config.accounts=[];c.accountID='deleted';
  assert.strictEqual(JSON.parse(disk.get('C:/test/runtime/batches/500-1/credentials.json')).profile_id,'account-a');
});
test('API choice fixes endpoint model and key before new task exports',()=>{
  const {context:c,disk}=retrySetup();
  c.backend='api';c.apiID='api-a';c.config.apis=[{id:'api-a',name:'方舟',api_key:'private-key',model:'model-id',endpoint:'https://ark.cn-beijing.volces.com/api/v3/images/generations',size:'2K'}];
  c.retryFailed([0]);
  const req=JSON.parse(disk.get('C:/test/runtime/jobs/500-2/request.json'));
  assert.strictEqual(req.backend,'api');assert.strictEqual(req.profile_id,'api-a');
  assert(!JSON.stringify(req).includes('private-key'));
  assert.strictEqual(JSON.parse(disk.get('C:/test/runtime/batches/500-1/credentials.json')).profile.api_key,'private-key');
});
test('missing selected profile fails before exporting and cannot fall back to first account',()=>{
  const {context:c,exports,launches}=retrySetup();c.accountID='deleted-id';
  assert.throws(()=>c.retryFailed([0]),/新增并选择豆包账号/);
  assert.deepStrictEqual(exports,[]);assert.deepStrictEqual(launches,[]);
});
test('API mode does not silently use saved web account when no API is selected',()=>{
  const {context:c,exports}=retrySetup();c.backend='api';c.apiID='';
  assert.throws(()=>c.retryFailed([0]),/新增并选择 API/);assert.deepStrictEqual(exports,[]);
});
test('settings UI captures prompt and generation choice on window close',()=>{
  const {context:c}=retrySetup();c.config.apis=[{id:'api-a',name:'我的 API'}];c.apiID='api-a';
  const controls=mockUI(c), Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    controls.find(x=>x.type==='dropdownlist'&&x.items[0]&&x.items[0].text==='豆包网页账号').selection=1;
    controls.find(x=>x.type==='edittext'&&x.text==='移除文字').text='持久提示词';
  };return w;};
  assert.strictEqual(c.showUI(null),'close');assert.strictEqual(c.backend,'api');assert.strictEqual(c.prompt,'持久提示词');
  assert.strictEqual(c.apiID,'api-a');
});
function settingsDisk(h) {
  const {context:c,disk}=h;let id=0;
  c.makeName=()=> '800-'+(++id);
  c.child=(folder,name)=>({path:folder.fsName+'/'+name,
    get exists(){return disk.has(this.path);},get fsName(){return this.path;},
    remove(){disk.delete(this.path);return true;},
    rename(name){const dest=this.path.split('/').slice(0,-1).join('/')+'/'+name;
      if(!disk.has(this.path)||disk.has(dest))return false;
      disk.set(dest,disk.get(this.path));disk.delete(this.path);this.path=dest;return true;},
    copy(dest){disk.set(dest,disk.get(this.path));return true;}});
  c.readText=file=>disk.get(file.path);c.writeText=(file,text)=>disk.set(file.path,text);
  vm.runInContext(['savePreferences','initProfiles','applyAccountResult','manageProfiles','editAPI','askName'].map(n=>functions[n]).join('\n'),c);
  return h;
}
test('local config persists prompt selected backend and private profiles without discarding options',()=>{
  const {context:c,disk}=settingsDisk(setup());
  c.prompt='保留背景';c.backend='api';c.accountID='account-a';c.apiID='api-b';
  vm.runInContext('config={timeout_seconds:600,accounts:[{id:"account-a",session:{cookies:{sessionid:"cookie-a"}}}],apis:[{id:"api-b",api_key:"key-b"}]};',c);
  disk.set('C:/test/config.json','old');c.savePreferences();
  const saved=JSON.parse(disk.get('C:/test/config.json'));
  assert.strictEqual(saved.prompt,'保留背景');assert.strictEqual(saved.backend,'api');
  assert.strictEqual(saved.selected_api_id,'api-b');assert.strictEqual(saved.timeout_seconds,600);
  assert.strictEqual(saved.accounts[0].session.cookies.sessionid,'cookie-a');
  assert.strictEqual(saved.apis[0].api_key,'key-b');assert(!disk.has('C:/test/config.previous.json'));
});
test('interrupted config replacement restores original file and reports the failure',()=>{
  const {context:c,disk}=settingsDisk(setup());c.prompt='new';
  disk.set('C:/test/config.json','original-config');
  const child=c.child;c.child=(folder,name)=>{const f=child(folder,name);if(name.startsWith('config.pending-'))f.rename=()=>false;return f;};
  assert.throws(()=>c.savePreferences(),/配置保存失败/);
  assert.strictEqual(disk.get('C:/test/config.json'),'original-config');
});
test('legacy account migrates once and a deleted profile cannot reappear on restart',()=>{
  const {context:c,disk}=settingsDisk(setup());c.prompt='原提示词';
  vm.runInContext('config={timeout_seconds:600};',c);
  disk.set('C:/test/runtime/http-session.json',JSON.stringify({name:'原账号',cookies:{sessionid:'legacy-secret'},params:{device_id:'1',web_id:'2',fp:'3'}}));
  c.initProfiles();assert.strictEqual(c.config.accounts.length,1);assert.strictEqual(c.config.accounts[0].name,'原账号');
  vm.runInContext('config.accounts=[];accountID="";',c);c.savePreferences();c.initProfiles();
  assert.strictEqual(c.config.accounts.length,0);assert.strictEqual(c.config.profiles_migrated,true);
  assert(disk.has('C:/test/runtime/http-session.json'));
});
test('reauthorizing one account preserves other accounts keys and custom names',()=>{
  const {context:c,disk}=settingsDisk(setup());c.prompt='去字';
  vm.runInContext('config={accounts:[{id:"a",name:"我的 A",session:{cookies:{sessionid:"old-a"}}},{id:"b",name:"我的 B",session:{cookies:{sessionid:"cookie-b"}}}],apis:[{id:"api",api_key:"key-private"}]};',c);
  const task={fsName:'C:/test/runtime/jobs/900-1'};
  disk.set(task.fsName+'/account-result.json',JSON.stringify({session:{cookies:{sessionid:'new-a'}},info:{name:'云端昵称',message:'已登录'}}));
  c.applyAccountResult(task,'a','ignored');
  const saved=JSON.parse(disk.get('C:/test/config.json'));
  assert.strictEqual(saved.accounts.length,2);assert.strictEqual(saved.accounts[0].name,'我的 A');
  assert.strictEqual(saved.accounts[0].session.cookies.sessionid,'new-a');
  assert.strictEqual(saved.accounts[1].session.cookies.sessionid,'cookie-b');assert.strictEqual(saved.apis[0].api_key,'key-private');
  assert(!disk.has(task.fsName+'/account-result.json'));
});
test('deleting one managed account keeps the remaining account and API configuration',()=>{
  const {context:c,disk}=settingsDisk(setup());c.prompt='去字';
  vm.runInContext('config={accounts:[{id:"a",name:"A"},{id:"b",name:"B"}],apis:[{id:"api",api_key:"key"}]};accountID="a";',c);
  const controls=mockUI(c), Base=c.Window;let shown=0;
  c.confirm=()=>true;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    const buttons=w.children.filter(x=>x.type==='group').flatMap(g=>g.children);
    const label=shown++===0?'删除':'返回';buttons.find(x=>x.text===label).onClick();
  };return w;};
  c.manageProfiles('web');
  const saved=JSON.parse(disk.get('C:/test/config.json'));
  assert.deepStrictEqual(saved.accounts.map(x=>x.id),['b']);assert.strictEqual(saved.selected_account_id,'b');assert.strictEqual(saved.apis[0].api_key,'key');
});
test('editing API without entering a new key preserves the stored key',()=>{
  const {context:c}=settingsDisk(setup());const controls=mockUI(c),Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    const inputs=controls.filter(x=>x.type==='edittext');inputs[0].text='修改名称';
    controls.find(x=>x.type==='button'&&x.text==='保存').onClick();
  };return w;};
  const edited=c.editAPI({id:'api-a',name:'原配置',endpoint:'https://ark.cn-beijing.volces.com/api/v3/images/generations',model:'model-id',api_key:'stored-private',size:'1.5K'});
  assert.strictEqual(edited.api_key,'stored-private');assert.strictEqual(edited.name,'修改名称');assert.strictEqual(edited.size,'1.5K');
  const password=controls.find(x=>x.props&&x.props.noecho);assert(password);assert.strictEqual(password.text,'');
});
test('Plan profile normalization preserves the Plan endpoint key id and original object',()=>{
  const {context:c}=setup();
  const p={id:'plan-one',endpoint:'https://ark.cn-beijing.volces.com/api/plan/v3/images/generations',model:'doubao-seedream-5-0-pro-260628',api_key:'private-plan-key'};
  const fixed=c.normalizeAPIProfile(p);
  assert.strictEqual(fixed.billing_mode,'plan');assert.strictEqual(fixed.model,'doubao-seedream-5-0-pro');
  assert.strictEqual(fixed.endpoint,p.endpoint);assert.strictEqual(fixed.api_key,p.api_key);assert.strictEqual(fixed.id,p.id);
  assert.strictEqual(p.model,'doubao-seedream-5-0-pro-260628');
});
test('billing mismatch or unrecognized dated Plan model blocks generation before exports',()=>{
  const {context:c,exports,launches}=retrySetup();c.backend='api';c.apiID='api-a';
  c.config.apis=[{id:'api-a',endpoint:'https://ark.cn-beijing.volces.com/api/plan/v3/images/generations',model:'doubao-seedream-5-0-pro',api_key:'private-key',billing_mode:'standard'}];
  assert.throws(()=>c.retryFailed([0]),/类型与地址不匹配/);
  c.config.apis[0].billing_mode='plan';c.config.apis[0].model='doubao-seedream-future-991231';
  assert.throws(()=>c.retryFailed([0]),/套餐支持的模型名/);
  assert.deepStrictEqual(exports,[]);assert.deepStrictEqual(launches,[]);
});
test('startup migration fixes only known aliases and retains accounts prompt endpoint and key',()=>{
  const {context:c,disk}=settingsDisk(setup());c.prompt='保存提示词';
  vm.runInContext('config={profiles_migrated:true,accounts:[{id:"a",name:"A",session:{cookies:{sessionid:"private-cookie"}}}],apis:[{id:"plan",model:"doubao-seedream-5-0-pro-260628",endpoint:"https://ark.cn-beijing.volces.com/api/plan/v3/images/generations",api_key:"private-key",size:"2K"}],selected_api_id:"plan",backend:"api"};',c);
  c.initProfiles();
  const cfg=JSON.parse(disk.get('C:/test/config.json'));
  assert.strictEqual(cfg.apis[0].model,'doubao-seedream-5-0-pro');assert.strictEqual(cfg.apis[0].billing_mode,'plan');
  assert.strictEqual(cfg.apis[0].endpoint,'https://ark.cn-beijing.volces.com/api/plan/v3/images/generations');
  assert.strictEqual(cfg.apis[0].api_key,'private-key');assert.strictEqual(cfg.accounts[0].session.cookies.sessionid,'private-cookie');
  assert.strictEqual(cfg.prompt,'保存提示词');assert.strictEqual(cfg.backend,'api');assert.strictEqual(cfg.selected_api_id,'plan');
});
test('custom compatible profile keeps user model names without official alias rewrites',()=>{
  const {context:c}=setup();
  const fixed=c.normalizeAPIProfile({endpoint:'https://custom.example/images/generations',model:'doubao-seedream-5-0-pro-260628',api_key:'private'});
  assert.strictEqual(fixed.billing_mode,'custom');assert.strictEqual(fixed.model,'doubao-seedream-5-0-pro-260628');
});
test('switching to Plan in API editor supplies the Plan address and model without submitting',()=>{
  const {context:c}=settingsDisk(setup());const controls=mockUI(c),Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    const mode=controls.find(x=>x.type==='dropdownlist'&&x.items[1]&&x.items[1].text==='Agent Plan（套餐）');
    mode.selection=1;mode.onChange();
    controls.find(x=>x.props&&x.props.noecho).text='new-plan-key';
    controls.find(x=>x.type==='button'&&x.text==='保存').onClick();
  };return w;};
  const p=c.editAPI(null);
  assert.strictEqual(p.billing_mode,'plan');assert.strictEqual(p.model,'doubao-seedream-5-0-pro');
  assert.strictEqual(p.endpoint,'https://ark.cn-beijing.volces.com/api/plan/v3/images/generations');
  assert.strictEqual(p.api_key,'new-plan-key');
});
test('billing-type change cannot silently reuse a key from the other billing route',()=>{
  const {context:c}=settingsDisk(setup());const controls=mockUI(c),Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    const mode=controls.find(x=>x.type==='dropdownlist'&&x.items[1]&&x.items[1].text==='Agent Plan（套餐）');
    mode.selection=1;mode.onChange();controls.find(x=>x.type==='button'&&x.text==='保存').onClick();
  };return w;};
  const original={id:'one',name:'普通 API',endpoint:'https://ark.cn-beijing.volces.com/api/v3/images/generations',model:'doubao-seedream-5-0-pro-260628',api_key:'old-key',size:'2K'};
  assert.throws(()=>c.editAPI(original),/重新填写目标类型/);
  assert.strictEqual(original.api_key,'old-key');assert.strictEqual(original.model,'doubao-seedream-5-0-pro-260628');
});
test('web merged mode persists into every new job and immutable batch manifest',()=>{
  const {context:c,disk}=retrySetup(); c.webUploadMode='merged'; c.retryFailed([0]);
  const req=JSON.parse(disk.get('C:/test/runtime/jobs/500-2/request.json'));
  const manifest=JSON.parse(disk.get('C:/test/runtime/batches/500-1/request.json'));
  assert.strictEqual(req.web_upload_mode,'merged');assert.strictEqual(manifest.web_upload_mode,'merged');
});
test('API batch remains separate when saved web choice is merged',()=>{
  const {context:c,disk}=retrySetup(); c.webUploadMode='merged'; c.backend='api'; c.apiID='api-a';
  c.config.apis=[{id:'api-a',protocol:'openai',provider:'openai',billing_mode:'standard',size:'auto',endpoint:'https://api.openai.com/v1/images/edits',api_key:'fake-key',model:'gpt-image-2'}];
  c.retryFailed([0]);
  const req=JSON.parse(disk.get('C:/test/runtime/jobs/500-2/request.json'));
  assert.strictEqual(req.web_upload_mode,'separate');assert.strictEqual(req.backend,'api');
});
test('mapping preserves explicit reversed layer associations and permits missing result',()=>{
  const {context:c}=setup();
  const rows=c.validateMergedSelections({schema:1,items:[{job_name:'1-1',source_layer_id:10},{job_name:'1-2',source_layer_id:20}],candidates:[{id:'1'},{id:'2'}]},['2',null]);
  assert.strictEqual(rows[0].candidate_id,'2');assert.strictEqual(rows[0].source_layer_id,10);assert.strictEqual(rows[1].candidate_id,null);
});
test('mapping rejects duplicate unknown and all-empty assignments',()=>{
  const {context:c}=setup();const map={schema:1,items:[{job_name:'1-1',source_layer_id:10},{job_name:'1-2',source_layer_id:20}],candidates:[{id:'1'},{id:'2'}]};
  assert.throws(()=>c.validateMergedSelections(map,['1','1']),/多个图层/);
  assert.throws(()=>c.validateMergedSelections(map,['999',null]),/多个图层/);
  assert.throws(()=>c.validateMergedSelections(map,[null,null]),/至少为一个图层/);
});
test('image protocols validate official and relay models without silently changing names',()=>{
  const {context:c}=setup();
  const g=c.normalizeAPIProfile({protocol:'gemini',provider:'gemini',endpoint:'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',model:'gemini-3.1-flash-image',size:'auto'});
  assert.strictEqual(g.auth_mode,'google');assert.strictEqual(g.billing_mode,'standard');assert.strictEqual(g.model,'gemini-3.1-flash-image');
  assert.throws(()=>c.normalizeAPIProfile({protocol:'openai',provider:'openai',endpoint:'https://api.openai.com/v1/images/generations',model:'gpt-image-2',size:'auto'}),/协议不匹配/);
  assert.throws(()=>c.normalizeAPIProfile({protocol:'openai',provider:'openai',endpoint:'https://generativelanguage.googleapis.com/v1/images/edits',model:'gpt-image-2',size:'auto'}),/官方地址/);
});
test('configuration persists web upload logic without changing credentials',()=>{
  const {context:c,disk}=settingsDisk(setup());c.prompt='去字';c.webUploadMode='merged';
  c.savePreferences();const saved=JSON.parse(disk.get('C:/test/config.json'));
  assert.strictEqual(saved.web_upload_mode,'merged');assert.strictEqual(saved.accounts[0].session.cookies.sessionid,'private-a');
});
test('invalid old API profile remains editable and can be repaired',()=>{
  const {context:c}=settingsDisk(setup());const controls=mockUI(c),Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    controls.find(x=>x.type==='edittext'&&x.text==='https://api.openai.com/v1/images/generations').text='https://api.openai.com/v1/images/edits';
    controls.find(x=>x.props&&x.props.noecho).text='new-private-key';
    controls.find(x=>x.type==='button'&&x.text==='保存').onClick();
  };return w;};
  const p=c.editAPI({id:'one',name:'需修复',protocol:'openai',provider:'openai',endpoint:'https://api.openai.com/v1/images/generations',model:'gpt-image-2',api_key:'old-key',size:'auto'});
  assert.strictEqual(p.endpoint,'https://api.openai.com/v1/images/edits');assert.strictEqual(p.api_key,'new-private-key');
});
test('changing relay host requires a fresh key even when billing route is unchanged',()=>{
  const {context:c}=settingsDisk(setup());const controls=mockUI(c),Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    controls.find(x=>x.type==='edittext'&&x.text==='https://first.example/v1/images/edits').text='https://second.example/v1/images/edits';
    controls.find(x=>x.type==='button'&&x.text==='保存').onClick();
  };return w;};
  assert.throws(()=>c.editAPI({id:'one',name:'中转',protocol:'openai',provider:'openai',endpoint:'https://first.example/v1/images/edits',model:'gpt-image-2',api_key:'old-key',size:'auto',billing_mode:'custom'}),/重新填写目标类型/);
});
function autoImportSetup() {
  const h=setup(),c=h.context;
  c.batchFolder=new c.Folder('C:/test/runtime/batches/500-1');
  c.readText=file=>h.disk.get(file.path);
  vm.runInContext(functions.importConfirmedMergedResults,c);
  h.confirm=(selections,auto=true)=>h.disk.set(c.batchFolder.fsName+'/mapping-confirmed.json',JSON.stringify({auto_import:auto,selections}));
  h.rows=[{job_name:'100-1',source_layer_id:11,candidate_id:'2'},{job_name:'100-2',source_layer_id:22,candidate_id:'1'}];
  return h;
}
test('unconfirmed and legacy merged batches never auto import',()=>{
  const h=autoImportSetup();assert.strictEqual(h.context.importConfirmedMergedResults(),false);
  h.confirm(h.rows,false);assert.strictEqual(h.context.importConfirmedMergedResults(),false);
  assert.deepStrictEqual(h.placements,[]);
});
test('confirmed merged assignments auto import once and restore full list selection',()=>{
  const h=autoImportSetup();h.confirm(h.rows);const c=h.context;
  c.bindEntry(1);assert.strictEqual(c.importConfirmedMergedResults(),true);
  assert.deepStrictEqual(h.placements.map(x=>x.id),[11,22]);
  assert.strictEqual(c.currentIndex,1);assert.strictEqual(c.entries.length,2);
  assert(h.disk.has(c.batchFolder.fsName+'/auto-import-finished.flag'));
  c.importConfirmedMergedResults();assert.strictEqual(h.placements.length,2);
});
test('missing merged result does not import an unassigned layer or carried result',()=>{
  const h=autoImportSetup();h.confirm([h.rows[0],{...h.rows[1],candidate_id:null}]);
  h.context.importConfirmedMergedResults();assert.deepStrictEqual(h.placements.map(x=>x.id),[11]);
});
test('mismatching confirmed layer ID rejects auto import before any placement',()=>{
  const h=autoImportSetup();h.confirm([{...h.rows[0],source_layer_id:999},h.rows[1]]);
  assert.throws(()=>h.context.importConfirmedMergedResults(),/不一致/);
  assert.deepStrictEqual(h.placements,[]);assert(!h.disk.has(h.context.batchFolder.fsName+'/auto-import-started.flag'));
});
test('duplicate confirmed job cannot import twice',()=>{
  const h=autoImportSetup();h.confirm([h.rows[0],h.rows[0]]);
  assert.throws(()=>h.context.importConfirmedMergedResults(),/不一致/);assert.deepStrictEqual(h.placements,[]);
});
test('auto import retains pending marker protection and imports remaining result',()=>{
  const h=autoImportSetup();h.confirm(h.rows);
  h.disk.set('C:/test/runtime/jobs/100-1/importing.flag','pending');
  h.context.importConfirmedMergedResults();assert.deepStrictEqual(h.placements.map(x=>x.id),[22]);
});
test('deleted original layer cannot receive auto import in another layer',()=>{
  const h=autoImportSetup();h.confirm(h.rows);h.context.originalDoc.layers.shift();
  h.context.importConfirmedMergedResults();assert.deepStrictEqual(h.placements.map(x=>x.id),[22]);
});
test('merged confirmation launches local finalize with automatic import then immediately closes',()=>{
  const h=autoImportSetup(),c=h.context;
  c.batchIsRunning=()=>false;c.makeName=()=>'900-1';c.ensureFolder=()=>{};
  c.pythonw={fsName:'pythonw'};let launched;
  c.launchWorker=(python,script,task)=>{launched=task;};
  vm.runInContext(functions.reviewMergedResults,c);
  h.disk.set(c.batchFolder.fsName+'/merged-map.json',JSON.stringify({schema:1,batch_name:c.batchFolder.name,
    items:[{job_name:'100-1',source_layer_id:11}],candidates:[{id:'1',width:40,height:20}]}));
  const controls=mockUI(c),Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    controls.filter(x=>x.type==='dropdownlist')[1].selection=1;
    controls.find(x=>x.type==='button'&&x.text==='确认对应并导入').onClick();
  };return w;};
  assert.strictEqual(c.reviewMergedResults(),true);assert(launched);
  const request=JSON.parse(h.disk.get(launched.fsName+'/request.json'));
  assert.strictEqual(request.kind,'merged_finalize');assert.strictEqual(request.auto_import,true);
  assert.strictEqual(request.selections[0].source_layer_id,11);assert.strictEqual(request.selections[0].candidate_id,'1');
  assert.deepStrictEqual(h.alerts,[]);
});
test('recovered cancelled source exposes its completed result without removing cancellation history',()=>{
  const h=setup(),c=h.context;c.batchFolder={fsName:'batch'};
  c.readText=file=>h.disk.get(file.path);vm.runInContext(functions.statusNow,c);
  h.disk.set('C:/test/runtime/jobs/100-1/cancel.flag','cancelled');
  h.disk.set('C:/test/runtime/jobs/100-1/status.json',JSON.stringify({state:'done',download_recovery:true}));
  assert.strictEqual(c.statusNow().state,'done');
  h.disk.set('C:/test/runtime/jobs/100-1/status.json',JSON.stringify({state:'done'}));
  assert.strictEqual(c.statusNow().state,'cancelled');
});
test('explicitly reopening cleared history enables completion without generating or importing',()=>{
  const h=setup(),c=h.context;
  const batch=new c.Folder('C:/test/runtime/batches/500-1');
  c.Folder.prototype.getFiles=()=>[batch];c.readText=file=>h.disk.get(file.path);
  let opened;c.readBatch=folder=>{opened=folder;c.batchFolder=folder;};
  h.disk.set(batch.fsName+'/request.json',JSON.stringify({document_id:42,started_ms:100,items:[{}]}));
  h.disk.set(batch.fsName+'/dismissed.flag','cleared');h.disk.set('C:/test/runtime/ui-cleared-42.json','cleared');
  vm.runInContext(functions.openHistory,c);
  const controls=mockUI(c),Base=c.Window;
  c.Window=function(type,title){const w=Base(type,title);w.show=function(){
    controls.find(x=>x.type==='button'&&x.text==='打开').onClick();
  };return w;};
  c.openHistory();assert.strictEqual(opened,batch);
  assert(!h.disk.has(batch.fsName+'/dismissed.flag'));assert(!h.disk.has('C:/test/runtime/ui-cleared-42.json'));
  assert.deepStrictEqual(h.placements,[]);
});
console.log(checks+' JSX queue behavior tests passed. No Photoshop operations executed.');

