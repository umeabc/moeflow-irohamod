const fs = require('fs');
const vm = require('vm');
const path = require('path');
const native = process.binding('natives')['internal/deps/acorn/acorn/dist/acorn'];
const mod = {exports:{}};
vm.runInNewContext(native, {module:mod,exports:mod.exports});
const file = path.join(process.argv[2] || __dirname, '..', 'Doubao_RemoveText.jsx');
const source = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').replace(/^#target photoshop\r?\n/, '');
new vm.Script(source, {filename:file});
const tree = mod.exports.parse(source, {ecmaVersion:3});
function visit(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'MemberExpression') {
    const prop = node.property.name || node.property.value;
    if (['onActivate','onShow','suspendHistory','update','sleep'].includes(prop)) {
      throw Error('Old reentrant UI/history pattern remains: ' + prop);
    }
  }
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) value.forEach(visit);
    else if (value && typeof value === 'object') visit(value);
  }
}
visit(tree);
console.log('ExtendScript ES3 syntax and old-pattern AST checks passed.');
