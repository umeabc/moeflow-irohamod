"""Result transport and legacy-task recovery with mock HTTP only."""
from contextlib import ExitStack
from io import BytesIO
import itertools
import json
from pathlib import Path
import socket
import ssl
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import httpx
from PIL import Image
import bridge_worker as worker
import batch_worker
import result_recovery
import result_transfer
import support_logs


class ResultTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.runtime = self.root / 'runtime'
        self.job = self.runtime / 'jobs/200-1'
        self.batch = self.runtime / 'batches/100-1'
        self.job.mkdir(parents=True)
        self.batch.mkdir(parents=True)
        self.request = {'backend': 'api', 'web_upload_mode': 'separate', 'document_id': 42,
            'source_layer_id': 81, 'width': 20, 'height': 12, 'left': -10, 'top': 4,
            'raw_bounds': [-10, 4, 10, 16], 'batch_name': '100-1', 'credential_ref': '100-1',
            'profile_id': 'original-api', 'prompt': 'private-example-prompt'}
        self.profile = {'id': 'original-api', 'protocol': 'grsai', 'provider': 'openai',
            'endpoint': 'https://relay.example/v1/api/generate', 'billing_mode': 'custom',
            'api_key': 'private-example-key', 'model': 'test-image', 'size': 'auto'}
        self.manifest = {'schema': 1, 'document_id': 42, 'notify': False,
            'items': [{'job_name': '200-1', 'source_layer_id': 81, 'width': 20, 'height': 12,
                       'left': -10, 'top': 4, 'raw_bounds': [-10, 4, 10, 16]}]}
        worker.atomic_json(self.job / 'request.json', self.request)
        worker.atomic_json(self.job / 'status.json', {'state': 'error', 'message': 'legacy download failure'})
        worker.atomic_json(self.job / 'diagnostic.json', {'api_request': {'protocol': 'grsai', 'provider': 'openai'},
            'exception_type': 'ConnectError', 'stage': 'downloading'})
        worker.atomic_json(self.batch / 'request.json', self.manifest)
        worker.atomic_json(self.batch / 'credentials.json', {'backend': 'api', 'profile_id': 'original-api', 'profile': self.profile})
        worker.atomic_json(self.root / 'config.json', {'timeout_seconds': 60, 'apis': [self.profile]})
        image = Image.new('RGBA', (20, 12), (200, 20, 50, 128))
        image.putpixel((0, 0), (0, 0, 0, 0))
        image.save(self.job / 'source.png')
        output = BytesIO()
        Image.new('RGB', (13, 17), 'blue').save(output, format='PNG')
        self.png = output.getvalue()
        self.calls = []
        self.get_failures = 0
        self.get_status = 200
        self.post_status = 200
        self.identity = '14-full-example-task-000001'
        self.returned_identity = self.identity
        self.url = 'https://cdn.example/result.png?signature=private-signed-example'
        self.client_class = httpx.Client
        self.stack = ExitStack()
        for module in (worker, batch_worker, support_logs):
            self.stack.enter_context(patch.object(module, 'ROOT', self.root))
            self.stack.enter_context(patch.object(module, 'RUNTIME', self.runtime))
        self.stack.enter_context(patch('httpx.Client', side_effect=lambda **kwargs:
            self.client_class(transport=httpx.MockTransport(self.handler), **kwargs)))
        self.stack.enter_context(patch.object(result_transfer, 'time', SimpleNamespace(
            monotonic=itertools.count().__next__, sleep=lambda seconds: None)))

    def tearDown(self):
        self.stack.close()
        self.temp.cleanup()

    def handler(self, request):
        self.calls.append(request)
        if request.url.host == 'relay.example':
            self.assertEqual(request.headers['authorization'], 'Bearer private-example-key')
            if request.method == 'GET':
                self.assertEqual(request.url.path, '/v1/api/result')
                self.assertEqual(request.url.params['id'], self.identity)
            else:
                self.assertEqual(request.method, 'POST')
                if self.post_status != 200: return httpx.Response(self.post_status, json={'error': {'code': 'InvalidParameter'}})
            return httpx.Response(200, json={'status': 'succeeded', 'id': self.returned_identity,
                'results': [{'url': self.url}]})
        self.assertEqual(request.url.host, 'cdn.example')
        self.assertEqual(request.method, 'GET')
        self.assertNotIn('authorization', request.headers)
        self.assertNotIn('cookie', request.headers)
        if self.get_failures:
            self.get_failures -= 1
            raise httpx.ConnectError('private upstream signed URL must never be logged', request=request)
        return httpx.Response(self.get_status, content=self.png)

    def task(self, task_id=None, confirmed=True):
        task = self.runtime / 'jobs/300-1'
        task.mkdir(exist_ok=True)
        worker.atomic_json(task / 'request.json', {'kind': 'result_recovery', 'batch_name': self.batch.name,
            'source_job_name': self.job.name, 'task_id': task_id, 'binding_confirmed': confirmed})
        return task

    def checkpoint(self):
        return result_transfer.save(self.job, self.request, {'url': self.url, 'source': 'api_url',
            'task_id': self.identity, 'endpoint': self.profile['endpoint']})

    def assert_geometry(self):
        self.assertTrue((self.job / 'preview.png').is_file())
        with Image.open(self.job / 'result.png') as result, Image.open(self.job / 'source.png') as source:
            self.assertEqual(result.size, source.size)
            self.assertEqual(result.getchannel('A').tobytes(), source.getchannel('A').tobytes())

    def test_generation_once_first_download_connection_error_then_get_success(self):
        self.get_failures = 1
        worker.process_job(self.job)
        self.assertEqual(worker.read_json(self.job / 'status.json')['state'], 'done')
        self.assertEqual([x.method for x in self.calls], ['POST', 'GET', 'GET'])
        self.assertEqual(result_transfer.load(self.job, self.request)['task_id'], self.identity)
        self.assert_geometry()
        row = worker.read_json(self.job / 'diagnostic.json')['downloads'][0]
        self.assertEqual(row['category'], 'connection')
        self.assertTrue(row['will_retry'])

    def test_exhausted_downloads_preserve_checkpoint_and_do_not_regenerate(self):
        self.get_failures = 10
        worker.process_job(self.job)
        status = worker.read_json(self.job / 'status.json')
        self.assertEqual(status['state'], 'error')
        self.assertTrue(status['generation_succeeded'])
        self.assertTrue(status['download_recoverable'])
        self.assertIn('生成已成功', status['message'])
        self.assertEqual([x.method for x in self.calls], ['POST', 'GET', 'GET', 'GET'])
        self.assertTrue((self.job / 'remote-result.json').exists())
        self.assertFalse((self.job / 'generated.download').exists())
        self.assertFalse((self.job / 'result.png').exists())

    def test_generation_400_is_never_retried_or_saved_as_success(self):
        self.post_status = 400
        worker.process_job(self.job)
        self.assertEqual([x.method for x in self.calls], ['POST'])
        self.assertFalse((self.job / 'remote-result.json').exists())
        self.assertFalse(worker.read_json(self.job / 'status.json')['generation_succeeded'])

    def test_nonretryable_download_403_stops_after_one_get(self):
        self.get_status = 403
        worker.process_job(self.job)
        self.assertEqual([x.method for x in self.calls], ['POST', 'GET'])
        self.assertTrue(worker.read_json(self.job / 'status.json')['download_recoverable'])

    def test_retryable_download_503_makes_only_three_gets(self):
        self.get_status = 503
        worker.process_job(self.job)
        self.assertEqual([x.method for x in self.calls], ['POST', 'GET', 'GET', 'GET'])

    def test_cancel_during_download_is_not_rewritten_as_failure(self):
        def cancelled(client, url, target, check, diagnostic):
            target.write_bytes(b'partial')
            raise worker.Cancelled('cancelled')
        with patch.object(worker, 'download_image', side_effect=cancelled): worker.process_job(self.job)
        self.assertEqual(worker.read_json(self.job / 'status.json')['state'], 'cancelled')
        self.assertFalse((self.job / 'generated.download').exists())
        self.assertEqual([x.method for x in self.calls], ['POST'])

    def test_partial_file_is_replaced_before_download_retry(self):
        original = worker.download_image
        first = True
        def interrupted(client, url, target, check, diagnostic):
            nonlocal first
            if first:
                first = False
                target.write_bytes(b'corrupt-partial')
                raise httpx.ReadError('interrupted')
            self.assertFalse(target.exists())
            return original(client, url, target, check, diagnostic)
        with patch.object(worker, 'download_image', side_effect=interrupted): worker.process_job(self.job)
        self.assert_geometry()

    def test_cached_recovery_does_not_need_credentials_or_original_profile(self):
        self.checkpoint()
        (self.batch / 'credentials.json').unlink()
        worker.atomic_json(self.root / 'config.json', {'timeout_seconds': 60, 'apis': []})
        original_diagnostic = (self.job / 'diagnostic.json').read_bytes()
        handler = self.handler
        def checked_handler(request):
            self.assertEqual(worker.read_json(self.batch / 'status.json')['state'], 'running')
            return handler(request)
        with patch.object(self, 'handler', side_effect=checked_handler):
            state = result_recovery.process(self.task(), notify=False)
        self.assertEqual(state['state'], 'done')
        self.assertEqual([x.method for x in self.calls], ['GET'])
        self.assert_geometry()
        self.assertEqual((self.job / 'diagnostic.json').read_bytes(), original_diagnostic)
        self.assertEqual(worker.read_json(self.batch / 'status.json')['counts']['done'], 1)
        self.assertFalse((self.job / 'recovery.lock').exists())

    def test_cached_inline_result_restores_without_any_http_request(self):
        result_transfer.save(self.job, self.request, {'bytes': self.png, 'source': 'api_base64'})
        (self.batch / 'credentials.json').unlink()
        state = result_recovery.process(self.task(), notify=False)
        self.assertEqual(state['state'], 'done')
        self.assertEqual(self.calls, [])
        self.assert_geometry()

    def test_legacy_recovery_exact_id_get_then_credential_free_cdn_get(self):
        (self.batch / 'credentials.json').unlink()
        state = result_recovery.process(self.task(self.identity), notify=False)
        self.assertEqual(state['state'], 'done')
        self.assertEqual([x.method for x in self.calls], ['GET', 'GET'])
        self.assert_geometry()
        self.assertEqual(result_transfer.load(self.job, self.request)['task_id'], self.identity)

    def test_legacy_query_rejects_other_returned_task(self):
        self.returned_identity = 'different-task'
        state = result_recovery.process(self.task(self.identity), notify=False)
        self.assertEqual(state['state'], 'error')
        self.assertIn('其他任务', state['message'])
        self.assertEqual(len(self.calls), 1)
        self.assertFalse((self.job / 'result.png').exists())

    def test_legacy_recovery_requires_explicit_layer_binding(self):
        with self.assertRaisesRegex(worker.UserError, '先确认'):
            result_recovery.process(self.task(self.identity, confirmed=False), notify=False)
        self.assertEqual(self.calls, [])

    def test_missing_original_api_never_uses_different_selected_api(self):
        worker.atomic_json(self.root / 'config.json', {'timeout_seconds': 60, 'selected_api_id': 'new',
            'apis': [{**self.profile, 'id': 'new'}]})
        with self.assertRaisesRegex(worker.UserError, '原 API 配置'):
            result_recovery.process(self.task(self.identity), notify=False)
        self.assertEqual(self.calls, [])

    def test_saved_endpoint_change_blocks_authenticated_query(self):
        self.checkpoint()
        worker.atomic_json(self.root / 'config.json', {'timeout_seconds': 60,
            'apis': [{**self.profile, 'endpoint': 'https://other.example/v1/api/generate'}]})
        with self.assertRaisesRegex(worker.UserError, '地址已变更'):
            result_recovery.process(self.task(self.identity), notify=False)
        self.assertEqual(self.calls, [])

    def test_checkpoint_cannot_be_reused_for_another_layer(self):
        self.checkpoint()
        changed = {**self.request, 'source_layer_id': 83}
        worker.atomic_json(self.job / 'request.json', changed)
        with self.assertRaisesRegex(worker.UserError, '原图层不一致'):
            result_transfer.load(self.job, changed)

    def test_imported_or_successful_result_cannot_be_overwritten(self):
        self.checkpoint()
        (self.job / 'imported.flag').touch()
        with self.assertRaisesRegex(worker.UserError, '导入'):
            result_recovery.process(self.task(), notify=False)
        (self.job / 'imported.flag').unlink()
        worker.atomic_json(self.job / 'status.json', {'state': 'done'})
        with self.assertRaisesRegex(worker.UserError, '仅支持找回'):
            result_recovery.process(self.task(), notify=False)
        self.assertEqual(self.calls, [])

    def test_cancelled_legacy_job_can_recover_without_removing_old_cancellation_evidence(self):
        self.checkpoint()
        (self.job / 'cancel.flag').touch()
        worker.atomic_json(self.job / 'status.json', {'state': 'cancelled'})
        state = result_recovery.process(self.task(), notify=False)
        self.assertEqual(state['state'], 'done')
        self.assertTrue(state['download_recovery'])
        self.assertTrue((self.job / 'cancel.flag').exists())

    def test_recovery_cancellation_does_not_make_cdn_request(self):
        self.checkpoint()
        task = self.task()
        (task / 'cancel.flag').touch()
        state = result_recovery.process(task, notify=False)
        self.assertEqual(state['state'], 'cancelled')
        self.assertEqual(self.calls, [])

    def test_log_export_includes_safe_download_and_recovery_evidence_only(self):
        self.checkpoint()
        self.get_failures = 1
        result_recovery.process(self.task(self.identity), notify=False)
        files = support_logs.collect(batch_name=self.batch.name)
        text = '\n'.join(files.values())
        for secret in (self.identity, self.url, 'private-signed-example', 'private-example-key', 'private-example-prompt', 'private upstream'):
            self.assertNotIn(secret, text)
        recovery = json.loads(files['jobs/200-1/recoveries/300-1/diagnostic.json'])
        self.assertEqual(recovery['downloads'][0]['category'], 'connection')
        self.assertTrue(recovery['downloads'][0]['generation_succeeded'])

    def test_network_cause_uses_bounded_categories(self):
        for cause, expected in ((socket.gaierror('private DNS host'), 'dns'), (ssl.SSLError('private host'), 'tls')):
            exc = httpx.ConnectError('private-url')
            exc.__cause__ = cause
            self.assertEqual(result_transfer.network_kind(exc), expected)
        self.assertEqual(result_transfer.network_kind(httpx.ReadTimeout('private-url')), 'timeout')

    def test_batch_cancel_zero_is_not_reported_as_cancelled_reason(self):
        status = support_logs.safe_status({'state': 'partial', 'counts': {'done': 1, 'error': 1, 'cancelled': 0},
            'message': '成功 1，失败 1，取消 0。'})
        self.assertNotEqual(status['reason'], '任务已取消。')


if __name__ == '__main__': unittest.main()
