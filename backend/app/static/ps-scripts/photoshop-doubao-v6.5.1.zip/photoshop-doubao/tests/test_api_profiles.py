"""Offline API and immutable profile isolation. Mock transports only, no paid calls."""
import base64
from io import BytesIO
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import httpx
from PIL import Image
import bridge_worker as host
from generation_profiles import load_snapshot, validate_api, DEFAULT_ENDPOINT, DEFAULT_MODEL, PLAN_ENDPOINT, PLAN_MODEL
from support_logs import safe_status, safe_diagnostic


class APIProfileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.runtime = self.root / 'runtime'
        self.job = self.runtime / 'jobs/10-1'
        self.batch = self.runtime / 'batches/10-0'
        self.job.mkdir(parents=True)
        self.batch.mkdir(parents=True)
        self.profile = {'name': 'API 私密名称', 'api_key': 'private-api-key', 'endpoint': DEFAULT_ENDPOINT,
                        'model': DEFAULT_MODEL, 'size': '2K'}
        self.request = {'backend': 'api', 'profile_id': 'api-one', 'credential_ref': '10-0', 'batch_name': '10-0',
                        'width': 40, 'height': 30, 'prompt': 'private-prompt', 'document_id': 1, 'source_layer_id': 2}
        self.patches = [patch.object(host, 'ROOT', self.root), patch.object(host, 'RUNTIME', self.runtime)]
        for p in self.patches: p.start()
        self.calls = []
        self.real_client = httpx.Client
        image = Image.new('RGBA', (40, 30), (10, 20, 30, 0))
        for x in range(3, 36):
            for y in range(2, 28): image.putpixel((x, y), (10, 20, 30, 128))
        image.save(self.job / 'source.png')
        buffer = BytesIO()
        Image.new('RGB', (80, 10), 'blue').save(buffer, format='PNG')
        self.png = buffer.getvalue()
        self.snapshot()

    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()

    def snapshot(self):
        host.atomic_json(self.batch / 'credentials.json', {'backend': self.request['backend'],
                         'profile_id': self.request['profile_id'], 'profile': self.profile})

    def run_job(self, response=None, status=200, handler=None, headers=None):
        host.atomic_json(self.root / 'config.json', {'timeout_seconds': 20, 'backend': 'web',
                         'selected_api_id': 'changed-id', 'apis': []})
        host.atomic_json(self.job / 'request.json', self.request)
        if response is None: response = {'data': [{'url': 'https://cdn.example/result?private-signature'}]}
        def default_handler(request):
            self.calls.append(request)
            if request.url.host == 'cdn.example': return httpx.Response(200, content=self.png, headers={'content-type': 'image/png'})
            return httpx.Response(status, json=response, headers=headers)
        def client(**kwargs): return self.real_client(transport=httpx.MockTransport(handler or default_handler), **kwargs)
        with patch('httpx.Client', side_effect=client), patch.object(host, 'load_signer', side_effect=AssertionError('API must not load signer')), patch.object(host, 'load_session', side_effect=AssertionError('API must not load cookies')):
            host.process_job(self.job)
        return host.read_json(self.job / 'status.json')

    def test_api_edit_payload_single_post_alpha_alignment_and_no_cdn_credentials(self):
        result = self.run_job()
        self.assertEqual(result['state'], 'done', result)
        self.assertFalse(result['saved_to_history'])
        self.assertEqual(result['result_source'], 'api_url')
        posts = [r for r in self.calls if r.method == 'POST']
        self.assertEqual(len(posts), 1)
        self.assertEqual(str(posts[0].url), DEFAULT_ENDPOINT)
        self.assertEqual(posts[0].headers['authorization'], 'Bearer private-api-key')
        payload = json.loads(posts[0].content)
        self.assertEqual(payload['model'], DEFAULT_MODEL)
        self.assertFalse(payload['watermark'])
        self.assertNotIn('sequential_image_generation', payload)
        self.assertNotIn('stream', payload)
        self.assertTrue(payload['prompt'].endswith('private-prompt'))
        self.assertIn('仅编辑 image 字段', payload['prompt'])
        self.assertIn('而不是重新创作', payload['prompt'])
        self.assertTrue(payload['image'].startswith('data:image/png;base64,'))
        with Image.open(BytesIO(base64.b64decode(payload['image'].split(',')[1]))) as uploaded:
            self.assertEqual(uploaded.size, (40, 30))
            self.assertEqual(uploaded.getpixel((0, 0)), (255, 255, 255))
        cdn = self.calls[-1]
        self.assertNotIn('authorization', cdn.headers)
        self.assertNotIn('cookie', cdn.headers)
        with Image.open(self.job / 'result.png') as image, Image.open(self.job / 'source.png') as original:
            self.assertEqual(image.size, (40, 30))
            self.assertEqual(image.getchannel('A').tobytes(), original.getchannel('A').tobytes())
        text = ''.join(p.read_text('utf8') for p in self.job.iterdir() if p.name in ('status.json', 'diagnostic.json', 'events.jsonl', 'worker.log'))
        for secret in ('private-api-key', 'private-signature', 'private-prompt', 'API 私密名称'): self.assertNotIn(secret, text)

    def test_base64_result_needs_no_download(self):
        result = self.run_job({'data': [{'b64_json': base64.b64encode(self.png).decode('ascii')}]})
        self.assertEqual(result['state'], 'done', result)
        self.assertEqual(result['result_source'], 'api_base64')
        self.assertEqual(len(self.calls), 1)

    def test_server_reporting_zero_references_blocks_download_and_importable_result(self):
        response={'data':[{'url':'https://cdn.example/unrelated'}],
                  'usage':{'input_images':0,'generated_images':1}}
        result=self.run_job(response)
        self.assertEqual(result['state'],'error')
        self.assertIn('输入图片 0 张',result['message'])
        self.assertEqual(len(self.calls),1)
        self.assertFalse((self.job/'result.png').exists())
        d=host.read_json(self.job/'diagnostic.json')
        self.assertEqual(d['api_response']['reference_status'],'rejected')
        self.assertEqual(d['api_response']['input_images'],0)
        self.assertTrue(d['input_image']['encoding_verified'])

    def test_one_reference_is_confirmed_and_wire_image_matches_exact_upload_file(self):
        def provider(request):
            self.calls.append(request)
            if request.url.host=='cdn.example': return httpx.Response(200,content=self.png)
            payload=json.loads(request.content)
            wire=base64.b64decode(payload['image'].split(',',1)[1],validate=True)
            self.assertEqual(wire,(self.job/'upload.png').read_bytes())
            with Image.open(self.job/'source.png') as source:
                rgba=source.convert('RGBA')
            expected=Image.new('RGB',rgba.size,'white')
            expected.paste(rgba,mask=rgba.getchannel('A'))
            with Image.open(BytesIO(wire)) as uploaded:
                self.assertEqual(uploaded.tobytes(),expected.tobytes())
            return httpx.Response(200,json={'data':[{'url':'https://cdn.example/result'}],
                'usage':{'input_images':1,'generated_images':1}},
                headers={'x-request-id':'20261103223000AABBCCDDEEFF0011'})
        result=self.run_job(handler=provider)
        self.assertEqual(result['state'],'done',result)
        self.assertEqual(result['reference_status'],'confirmed')
        self.assertIn('接收 1 张参考图',result['message'])
        d=host.read_json(self.job/'diagnostic.json')
        self.assertEqual(d['input_image']['count'],1)
        self.assertEqual(d['api_response']['input_images'],1)
        self.assertIn('request_id',d['api_response'])

    def test_missing_reference_usage_is_explicitly_unconfirmed(self):
        result=self.run_job()
        self.assertEqual(result['state'],'done')
        self.assertEqual(result['reference_status'],'not_reported')
        self.assertIn('未回报参考图接收数量',result['message'])
        self.assertNotIn('确认接收',result['message'])

    def test_unexpected_reference_count_is_not_accepted_as_one(self):
        result=self.run_job({'data':[{'url':'https://cdn.example/wrong'}],
                             'usage':{'input_images':2}})
        self.assertEqual(result['state'],'error')
        self.assertEqual(len(self.calls),1)
        self.assertEqual(host.read_json(self.job/'diagnostic.json')['api_response']['reference_status'],'unexpected')

    def test_invalid_usage_values_cannot_leak_or_confirm_reference(self):
        for usage in ({'input_images':True},{'input_images':'private-api-key'},['private-prompt']):
            with self.subTest(usage=usage):
                result=self.run_job({'data':[{'url':'https://cdn.example/result'}],'usage':usage})
                self.assertEqual(result['state'],'done')
                self.assertEqual(result['reference_status'],'not_reported')
                d=host.read_json(self.job/'diagnostic.json')['api_response']
                self.assertNotIn('input_images',d)
                self.assertNotIn('private',json.dumps(d))

    def test_error_codes_classified_without_echo_or_retry(self):
        for status, code, phrase in ((401, 'InvalidApiKey', '认证'), (429, 'QuotaExceeded', '额度'),
                                    (400, 'InvalidParameter', '参数'), (500, 'InternalError', '服务端')):
            with self.subTest(status=status):
                self.calls.clear()
                result = self.run_job({'error': {'code': code, 'message': 'private-api-key private-prompt'}}, status)
                self.assertEqual(result['state'], 'error')
                self.assertIn(phrase, result['message'])
                self.assertEqual(len(self.calls), 1)
                self.assertNotIn('private', result['message'])
                self.assertFalse((self.job / 'result.png').exists())

    def test_empty_bad_base64_item_error_or_http_url_fail_without_retry(self):
        for response in ({'data': []}, {'data': [{'b64_json': 'invalid'}]}, {'data': [{'url': 'http://cdn.example/unsafe'}]},
                         {'data': [{'error': {'code': 'ContentFilter', 'message': 'secret'}}]}):
            with self.subTest(response=response):
                self.calls.clear()
                result = self.run_job(response)
                self.assertEqual(result['state'], 'error')
                self.assertEqual(len(self.calls), 1)

    def test_invalid_input_rejected_before_submission(self):
        Image.new('RGB', (10, 30), 'white').save(self.job / 'source.png')
        self.request.update(width=10)
        result = self.run_job()
        self.assertEqual(result['state'], 'error')
        self.assertIn('API 参考图', result['message'])
        self.assertEqual(self.calls, [])

    def test_cancel_before_request_is_offline(self):
        (self.job / 'cancel.flag').touch()
        self.assertEqual(self.run_job()['state'], 'cancelled')
        self.assertEqual(self.calls, [])

    def test_snapshot_survives_live_profile_deletion_and_cannot_switch_profiles(self):
        self.assertEqual(load_snapshot(host, self.request)['api_key'], 'private-api-key')
        for key, value in (('profile_id', 'api-two'), ('backend', 'web'), ('batch_name', '10-2'), ('credential_ref', '../escape')):
            with self.subTest(key=key), self.assertRaises(host.UserError):
                load_snapshot(host, {**self.request, key: value})

    def test_missing_snapshot_cannot_fall_back_to_current_account(self):
        (self.batch / 'credentials.json').unlink()
        result = self.run_job()
        self.assertEqual(result['state'], 'error')
        self.assertEqual(self.calls, [])

    def test_account_snapshots_remain_isolated_and_do_not_overwrite_legacy(self):
        old = self.runtime / 'http-session.json'
        host.atomic_json(old, {'cookies': {'sessionid': 'legacy-secret'}})
        self.profile = {'name': 'A', 'cookies': {'sessionid': 'account-a'}, 'params': {'device_id': '1', 'web_id': '2', 'fp': '3'}}
        self.request.update(backend='web', profile_id='account-a')
        self.snapshot()
        a = load_snapshot(host, self.request)
        self.profile = {**self.profile, 'cookies': {'sessionid': 'account-b'}}
        self.request.update(profile_id='account-b')
        self.snapshot()
        b = load_snapshot(host, self.request)
        self.assertEqual(a['cookies']['sessionid'], 'account-a')
        self.assertEqual(b['cookies']['sessionid'], 'account-b')
        self.assertEqual(host.read_json(old)['cookies']['sessionid'], 'legacy-secret')

    def test_api_endpoint_validation_does_not_send_keys_to_redirect_or_query(self):
        for endpoint in ('http://example.com/images/generations', 'https://user:pass@example.com/images/generations',
                         'https://example.com/images/generations?key=secret', 'https://example.com/images/generations#frag',
                         'https://example.com/models', 'https://example.com:8443/images/generations'):
            with self.subTest(endpoint=endpoint), self.assertRaises(host.UserError):
                validate_api({**self.profile, 'endpoint': endpoint}, host.UserError)

    def test_api_logs_keep_known_source_and_fixed_error_category(self):
        self.assertEqual(safe_status({'result_source': 'api_url'})['result_source'], 'api_url')
        result = self.run_job({'error': {'code': 'InvalidApiKey'}}, 401)
        clean = safe_diagnostic(host.read_json(self.job / 'diagnostic.json'))
        self.assertEqual(clean['requests'][0]['status'], 401)
        self.assertIn('401', clean['api_codes'])
        self.assertNotIn('private-api-key', json.dumps(clean))

    def test_export_ignores_local_config_and_private_credential_snapshot(self):
        import support_logs
        self.assertEqual(self.run_job()['state'], 'done')
        with patch.object(support_logs, 'ROOT', self.root), patch.object(support_logs, 'RUNTIME', self.runtime):
            files = support_logs.collect(job_name='10-1')
        text = json.dumps(files, ensure_ascii=False)
        for secret in ('private-api-key', 'private-prompt', 'private-signature', 'API 私密名称'):
            self.assertNotIn(secret, text)
        self.assertNotIn('credentials.json', text)
        self.assertIn('api_url', text)

    def test_pro_request_passes_provider_that_rejects_unsupported_options(self):
        def provider(request):
            self.calls.append(request)
            if request.url.host == 'cdn.example': return httpx.Response(200, content=self.png)
            payload = json.loads(request.content)
            for forbidden in ('sequential_image_generation', 'sequential_image_generation_options', 'stream'):
                if forbidden in payload:
                    return httpx.Response(400, json={'error': {'code': 'InvalidParameter', 'param': forbidden,
                            'message': 'Unsupported parameter'}})
            self.assertEqual(payload['output_format'], 'png')
            return httpx.Response(200, json={'data': [{'url': 'https://cdn.example/result'}]})
        self.assertEqual(self.run_job(handler=provider)['state'], 'done')
        self.assertEqual(sum(r.method == 'POST' for r in self.calls), 1)

    def test_plan_alias_uses_original_plan_endpoint_and_same_key_without_fallback(self):
        self.profile.update(endpoint=PLAN_ENDPOINT, billing_mode='plan', model=DEFAULT_MODEL)
        self.snapshot()
        def provider(request):
            self.calls.append(request)
            if request.url.host == 'cdn.example': return httpx.Response(200, content=self.png)
            payload = json.loads(request.content)
            self.assertEqual(str(request.url), PLAN_ENDPOINT)
            self.assertEqual(request.headers['authorization'], 'Bearer private-api-key')
            if payload['model'] != PLAN_MODEL:
                return httpx.Response(400, json={'error': {'code': 'InvalidModel', 'param': 'model'}})
            return httpx.Response(200, json={'data': [{'url': 'https://cdn.example/result'}]})
        self.assertEqual(self.run_job(handler=provider)['state'], 'done')
        self.assertEqual(sum(r.method == 'POST' for r in self.calls), 1)
        diag = host.read_json(self.job / 'diagnostic.json')['api_request']
        self.assertEqual(diag['billing_mode'], 'plan')
        self.assertTrue(diag['model_normalized'])
        self.assertEqual(self.profile['model'], DEFAULT_MODEL)  # snapshots are read-only

    def test_invalid_key_on_plan_has_no_paid_standard_fallback(self):
        self.profile.update(endpoint=PLAN_ENDPOINT, billing_mode='plan', model=PLAN_MODEL)
        self.snapshot()
        result = self.run_job({'error': {'code': 'InvalidApiKey'}}, 401)
        self.assertEqual(result['state'], 'error')
        self.assertIn('套餐专属 Key', result['message'])
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(str(self.calls[0].url), PLAN_ENDPOINT)

    def test_mismatched_billing_label_is_rejected_before_upload_or_post(self):
        self.profile.update(endpoint=PLAN_ENDPOINT, billing_mode='standard')
        self.snapshot()
        result = self.run_job()
        self.assertEqual(result['state'], 'error')
        self.assertIn('类型与接口地址不匹配', result['message'])
        self.assertEqual(self.calls, [])

    def test_custom_endpoint_does_not_get_automatic_official_model_rewrite(self):
        p = validate_api({**self.profile, 'endpoint': 'https://provider.example/v3/images/generations',
                          'model': PLAN_MODEL}, host.UserError)
        self.assertEqual(p['model'], PLAN_MODEL)
        self.assertEqual(p['billing_mode'], 'custom')
        self.assertFalse(p['model_normalized'])

    def test_standard_alias_resolves_without_changing_endpoint_or_key(self):
        p = validate_api({**self.profile, 'model': PLAN_MODEL}, host.UserError)
        self.assertEqual(p['model'], DEFAULT_MODEL)
        self.assertEqual(p['endpoint'], DEFAULT_ENDPOINT)
        self.assertEqual(p['api_key'], 'private-api-key')

    def test_unrecognized_dated_plan_model_is_blocked_without_guessing(self):
        self.profile.update(endpoint=PLAN_ENDPOINT, model='doubao-seedream-future-991231')
        self.snapshot()
        result = self.run_job()
        self.assertEqual(result['state'], 'error')
        self.assertIn('带日期模型 ID', result['message'])
        self.assertEqual(self.calls, [])

    def test_old_model_or_endpoint_id_omits_unsupported_output_format(self):
        for model in ('doubao-seedream-4-5-251128', 'ep-12345678901234-abcd'):
            self.profile.update(model=model)
            self.snapshot()
            self.calls.clear()
            self.assertEqual(self.run_job()['state'], 'done')
            payload = json.loads(self.calls[0].content)
            self.assertNotIn('output_format', payload)
            self.assertNotIn('stream', payload)
            self.assertNotIn('sequential_image_generation', payload)

    def test_incompatible_known_output_grade_is_rejected_before_post(self):
        self.profile.update(model='doubao-seedream-4-5-251128', size='1.5K')
        self.snapshot()
        result = self.run_job()
        self.assertEqual(result['state'], 'error')
        self.assertIn('输出档位', result['message'])
        self.assertEqual(self.calls, [])

    def test_business_code_parameter_request_id_and_options_survive_redacted_export(self):
        request_id = '20261103203000AABBCCDDEEFF0011'
        result = self.run_job({'error': {'code': 'InvalidParameter.UnsupportedParameter',
                               'param': 'sequential_image_generation',
                               'message': 'not supported private-api-key private-prompt https://private.example'}}, 400,
                               headers={'x-request-id': request_id})
        self.assertEqual(result['state'], 'error')
        self.assertIn('InvalidParameter.UnsupportedParameter', result['message'])
        self.assertIn('sequential_image_generation', result['message'])
        d = host.read_json(self.job/'diagnostic.json')
        self.assertEqual(d['api_error']['request_id'], request_id)
        self.assertEqual(d['api_error']['category'], 'unsupported_parameter')
        self.assertEqual(d['api_request']['billing_mode'], 'standard')
        import support_logs
        with patch.object(support_logs, 'ROOT', self.root), patch.object(support_logs, 'RUNTIME', self.runtime):
            text = '\n'.join(support_logs.collect(job_name='10-1').values())
        for value in ('InvalidParameter.UnsupportedParameter', 'sequential_image_generation', request_id): self.assertIn(value, text)
        for secret in ('private-api-key', 'private-prompt', 'private.example', 'API 私密名称'): self.assertNotIn(secret, text)

    def test_echoed_keys_urls_and_unknown_codes_are_not_persisted(self):
        self.profile['api_key'] = 'a' * 32
        self.snapshot()
        self.run_job({'error': {'code': 'InvalidParameter.private-secret', 'param': 'private-secret',
                     'request_id': 'https://private.example/?key=private-secret',
                     'message': 'Unsupported private-secret'}}, 400,
                     headers={'x-request-id': self.profile['api_key']})
        diag = host.read_json(self.job/'diagnostic.json')
        self.assertEqual(diag['api_error']['code'], 'InvalidParameter')
        self.assertNotIn('param', diag['api_error'])
        self.assertNotIn('request_id', diag['api_error'])
        text = ''.join((self.job/n).read_text('utf8') for n in ('status.json','worker.log','diagnostic.json','events.jsonl'))
        for secret in ('a'*32, 'private-secret', 'private.example'): self.assertNotIn(secret, text)

    def test_malformed_error_fields_do_not_break_safe_classification(self):
        result = self.run_job({'error': {'code': {'secret': 'private-api-key'},
                                        'param': ['private-prompt'], 'request_id': {'secret': 'private'}}}, 400)
        self.assertEqual(result['state'], 'error')
        self.assertIn('HTTP 400', result['message'])
        self.assertEqual(host.read_json(self.job/'diagnostic.json')['exception_type'], 'UserError')


if __name__ == '__main__': unittest.main()
