"""Full merged workflow on HTTP mock transport. No accounts or Photoshop."""
from io import BytesIO
import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import httpx
from PIL import Image
import bridge_worker as worker
import batch_worker
import merged_worker
from test_http_worker import SESSION


class MergedTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.runtime = self.root / 'runtime'
        self.batch = self.runtime / 'batches/100-1'
        self.batch.mkdir(parents=True)
        self.items = []
        self.jobs = []
        for i in range(2):
            job = self.runtime / ('jobs/200-' + str(i + 1))
            job.mkdir(parents=True)
            width, height = 40 + i * 5, 30 + i * 10
            image = Image.new('RGBA', (width, height), (255 if i == 0 else 0, 0, 255 if i else 0, 128))
            image.putpixel((0, 0), (0, 0, 0, 0))
            image.save(job / 'source.png')
            worker.atomic_json(job / 'request.json', {'backend': 'web', 'web_upload_mode': 'merged', 'document_id': 1,
                'source_layer_id': 7 + i, 'width': width, 'height': height, 'batch_name': self.batch.name,
                'profile_id': 'a', 'credential_ref': self.batch.name, 'prompt': 'private-merged-prompt', 'prefer_watermark_free': True})
            self.items.append({'job_name': job.name, 'source_layer_id': 7 + i, 'source_layer_name': '同名'})
            self.jobs.append(job)
        self.manifest = {'schema': 1, 'document_id': 1, 'web_upload_mode': 'merged', 'items': self.items, 'notify': False}
        worker.atomic_json(self.batch / 'request.json', self.manifest)
        worker.atomic_json(self.batch / 'credentials.json', {'backend': 'web', 'profile_id': 'a', 'profile': SESSION})
        worker.atomic_json(self.root / 'config.json', {'timeout_seconds': 60})
        self.patches = [patch.object(worker, 'ROOT', self.root), patch.object(worker, 'RUNTIME', self.runtime),
            patch.object(batch_worker, 'ROOT', self.root), patch.object(batch_worker, 'RUNTIME', self.runtime)]
        for p in self.patches: p.start()
        self.client = httpx.Client
        self.calls = []
        self.uploads = 0
        self.results = []
        for i, color in enumerate(('red', 'blue')):
            output = BytesIO()
            Image.new('RGB', (16 + i * 2, 24), color).save(output, format='PNG')
            self.results.append(output.getvalue())
        self.reverse = True
        self.output_count = 2
        self.download_failure = False
        self.reject_upload = False
        self.cancel_generation = False

    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()

    def handler(self, r):
        self.calls.append(r)
        if r.url.path == '/chat/': return httpx.Response(200, text='mock init')
        if r.url.path.endswith('/upload_image'):
            self.uploads += 1
            if self.reject_upload: return httpx.Response(403, json={'code': 403})
            return httpx.Response(200, json={'code': 0, 'data': {'uri': 'short-' + str(self.uploads)}})
        if r.url.path.endswith('/get_file_url'):
            uri = json.loads(r.content)['uris'][0]
            return httpx.Response(200, json={'code': 0, 'data': {'file_urls': [{'uri': 'canonical-' + uri}]}})
        if r.url.path.endswith('/completion'):
            self.assertEqual(self.uploads, 2, 'all uploads must precede completion')
            payload = json.loads(r.content)
            self.assertEqual([x['key'] for x in payload['messages'][0]['attachments']], ['canonical-short-1', 'canonical-short-2'])
            self.assertTrue(payload['completion_option']['need_create_conversation'])
            text = json.loads(payload['messages'][0]['content'])['text']
            self.assertIn('分别输出 2 张', text)
            self.assertIn('private-merged-prompt', text)
            if self.cancel_generation: (self.batch / 'cancel.flag').touch()
            values = [{'key': 'out-' + str(i), 'image_ori_raw': {'url': 'https://cdn.example/' + str(i)}} for i in range(self.output_count)]
            if self.reverse: values.reverse()
            # Duplicated final frames must not duplicate candidate downloads.
            event = {'message': {'content_type': 2010, 'content': json.dumps({'data': values})}}
            # Reference echo is never an output.
            echo = {'message': {'user_type': 1, 'reply_id': '0', 'content_type': 2010,
                'content': json.dumps({'data': [{'key': 'reference', 'image_ori_raw': {'url': 'https://cdn.example/reference'}}]})}}
            stream = ''.join('data: ' + json.dumps(x) + '\n\n' for x in (echo, event, event)) + 'data: [DONE]\n\n'
            return httpx.Response(200, text=stream, headers={'content-type': 'text/event-stream'})
        if r.url.host == 'cdn.example':
            self.assertNotIn('cookie', r.headers)
            self.assertNotIn('authorization', r.headers)
            if self.download_failure and r.url.path == '/0': return httpx.Response(503)
            return httpx.Response(200, content=self.results[int(r.url.path.strip('/'))])
        raise AssertionError('unexpected offline path ' + r.url.path)

    def run_batch(self):
        def client(**kwargs): return self.client(transport=httpx.MockTransport(self.handler), **kwargs)
        with patch('httpx.Client', side_effect=client), patch.object(worker, 'load_signer', return_value=lambda p: {'signed_url': p['url'] + '&a_bogus=mock'}):
            return batch_worker.process_batch(self.batch, poll_seconds=0.01)

    def finalize(self, ids, auto_import=False, notify=False):
        task = self.runtime / 'jobs/300-1'
        task.mkdir(exist_ok=True)
        worker.atomic_json(task / 'request.json', {'kind': 'merged_finalize', 'batch_name': self.batch.name, 'auto_import': auto_import,
            'selections': [{'job_name': x.name, 'source_layer_id': 7 + i, 'candidate_id': cid} for i, (x, cid) in enumerate(zip(self.jobs, ids))]})
        # finalize must be entirely offline, even if a result is missing.
        with patch('httpx.Client', side_effect=AssertionError('finalize must never access network')):
            merged_worker.finalize(task, notify=notify)
        return worker.read_json(self.batch / 'status.json')

    def test_all_attachments_one_conversation_one_post_downloads_last(self):
        state = self.run_batch()
        self.assertEqual(state['state'], 'review', state)
        self.assertEqual([worker.read_json(j / 'status.json')['state'] for j in self.jobs], ['mapping', 'mapping'])
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
        self.assertEqual(sum(r.url.host == 'cdn.example' for r in self.calls), 2)
        self.assertFalse((self.batch / 'credentials.json').exists())
        self.assertFalse(any((j / 'result.png').exists() for j in self.jobs))
        self.assertEqual(len(worker.read_json(self.batch / 'merged-map.json')['candidates']), 2)
        self.assertTrue(all((j / 'source-preview.png').exists() for j in self.jobs))

    def test_explicit_reversed_mapping_restores_each_source_size_and_alpha(self):
        self.run_batch()
        state = self.finalize(['2', '1'])
        self.assertEqual(state['state'], 'done', state)
        for i, job in enumerate(self.jobs):
            with Image.open(job / 'result.png') as result, Image.open(job / 'source.png') as source:
                self.assertEqual(result.size, source.size)
                self.assertEqual(result.getchannel('A').tobytes(), source.getchannel('A').tobytes())
                self.assertEqual(result.convert('RGB').getpixel((5, 5)), (255, 0, 0) if i == 0 else (0, 0, 255))
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)

    def test_confirmed_auto_import_persists_exact_selection_and_notifies_mapping_phase_once(self):
        self.run_batch()
        with patch('completion_notifier.notify_completion') as notify, patch('merged_worker.time.sleep') as settle:
            state = self.finalize(['2', '1'], auto_import=True, notify=True)
        self.assertEqual(state['state'], 'done')
        confirmed = worker.read_json(self.batch / 'mapping-confirmed.json')
        self.assertTrue(confirmed['auto_import'])
        self.assertEqual([x['candidate_id'] for x in confirmed['selections']], ['2', '1'])
        self.assertTrue(all(worker.read_json(job / 'status.json')['mapping_confirmed'] for job in self.jobs))
        settle.assert_called_once_with(1)
        notify.assert_called_once_with(self.batch, phase='mapping')

    def test_same_result_cannot_be_assigned_to_two_layers(self):
        self.run_batch()
        with self.assertRaisesRegex(worker.UserError, '不能分配给多个'): self.finalize(['1', '1'])
        self.assertFalse(any((j / 'result.png').exists() for j in self.jobs))
        self.assertFalse((self.batch / 'mapping.lock').exists())

    def test_incomplete_return_is_reviewed_and_unassigned_layer_can_retry(self):
        self.output_count = 1
        self.assertEqual(self.run_batch()['state'], 'review')
        state = self.finalize(['1', None])
        self.assertEqual(state['state'], 'partial')
        self.assertEqual([x['state'] for x in state['items']], ['done', 'error'])
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)

    def test_missing_candidate_file_stops_before_any_partial_restoration(self):
        self.run_batch()
        (self.batch / 'merged-results/2.png').unlink()
        with self.assertRaisesRegex(worker.UserError, '文件缺失'): self.finalize(['1', '2'])
        self.assertFalse(any((j / 'result.png').exists() for j in self.jobs))

    def test_second_finalize_does_not_overwrite_first_mapping(self):
        self.run_batch()
        self.finalize(['2', '1'])
        before = (self.jobs[0] / 'result.png').read_bytes()
        with self.assertRaisesRegex(worker.UserError, '不能再次覆盖'): self.finalize(['1', '2'])
        self.assertEqual(before, (self.jobs[0] / 'result.png').read_bytes())

    def test_upload_rejection_prevents_combined_completion(self):
        self.reject_upload = True
        state = self.run_batch()
        self.assertEqual(state['state'], 'error')
        self.assertFalse(any(r.url.path.endswith('/completion') for r in self.calls))
        self.assertFalse(any((j / 'result.png').exists() for j in self.jobs))

    def test_cancellation_during_combined_generation_prevents_download_or_import(self):
        self.cancel_generation = True
        state = self.run_batch()
        self.assertEqual(state['state'], 'cancelled', state)
        self.assertFalse(any(r.url.host == 'cdn.example' for r in self.calls))
        self.assertFalse(any((j / 'result.png').exists() for j in self.jobs))

    def test_one_download_failure_keeps_other_candidate_for_review(self):
        self.download_failure = True
        self.assertEqual(self.run_batch()['state'], 'review')
        mapping = worker.read_json(self.batch / 'merged-map.json')
        self.assertEqual(mapping['failed_downloads'], 1)
        self.assertEqual(len(mapping['candidates']), 1)

    def test_existing_submission_lock_never_resends_any_layer(self):
        (self.jobs[1] / 'submitted.lock').touch()
        self.assertEqual(self.run_batch()['state'], 'error')
        self.assertEqual(self.calls, [])

    def test_immutable_layer_mapping_change_rejected(self):
        self.run_batch()
        mapping = worker.read_json(self.batch / 'merged-map.json')
        mapping['items'][0]['source_layer_id'] = 999
        worker.atomic_json(self.batch / 'merged-map.json', mapping)
        with self.assertRaisesRegex(worker.UserError, '与原图层不一致'): self.finalize(['2', '1'])
        self.assertFalse(any((j / 'result.png').exists() for j in self.jobs))

    def test_logs_and_candidate_map_never_persist_signed_links_keys_or_prompts(self):
        self.run_batch()
        paths = [self.batch / 'merged-map.json']
        for job in self.jobs: paths += [job / name for name in ('status.json', 'worker.log', 'diagnostic.json', 'events.jsonl')]
        text = ''.join(p.read_text(encoding='utf-8') for p in paths)
        for secret in ('fake-secret', 'private-merged-prompt', 'https://cdn.example', 'a_bogus=mock'): self.assertNotIn(secret, text)

    def test_exported_log_contains_merge_counts_and_excludes_candidate_images_and_mapping_files(self):
        import support_logs
        self.run_batch()
        path = self.root / 'support.zip'
        with patch.object(support_logs, 'RUNTIME', self.runtime):
            support_logs.export_archive(path, batch_name=self.batch.name)
        with zipfile.ZipFile(path) as archive:
            self.assertFalse(any(name.endswith('.png') or 'merged-map' in name for name in archive.namelist()))
            summary = json.loads(archive.read('batch/merged-summary.json'))
            self.assertEqual(summary['source_count'], 2)
            self.assertEqual(summary['available_count'], 2)
            self.assertFalse(summary['mapping_confirmed'])
            meta = json.loads(archive.read('batch/metadata.json'))
            self.assertEqual(meta['web_upload_mode'], 'merged')
            text = ''.join(archive.read(name).decode('utf-8-sig') for name in archive.namelist())
            for secret in ('fake-secret', 'private-merged-prompt', 'https://cdn.example', 'a_bogus=mock'): self.assertNotIn(secret, text)


if __name__ == '__main__': unittest.main()
