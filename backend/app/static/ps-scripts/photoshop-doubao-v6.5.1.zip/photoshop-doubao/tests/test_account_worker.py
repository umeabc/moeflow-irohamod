﻿"""Offline QR-login/account tests; no real authorizations or external network."""
import base64
from io import BytesIO
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import account_worker as account
import bridge_worker as host
import httpx
from PIL import Image

class AccountTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.job = self.root / 'runtime/jobs/1-2'
        self.job.mkdir(parents=True)
        self.calls = []
        self.original_client = httpx.Client
        self.patches = [patch.object(host, 'ROOT', self.root), patch.object(host, 'RUNTIME', self.root / 'runtime')]
        for p in self.patches: p.start()
        buffer = BytesIO()
        Image.new('RGB', (128,128), 'white').save(buffer, format='PNG')
        self.qr = base64.b64encode(buffer.getvalue()).decode('ascii')
        self.poll_states = ['new', 'scanned', 'confirmed']
        self.session = {'name':'old', 'cookies':{'sessionid':'old-private', 's_v_web_id':'verify_old'},
                        'params':{'device_id':'1','web_id':'2','fp':'verify_old'}}
        host.atomic_json(self.root / 'runtime/http-session.json', self.session)
    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()
    def handler(self, request):
        self.calls.append(request)
        path = request.url.path
        if path == '/': return httpx.Response(302, headers={'location':'/chat/'})
        if path == '/chat/': return httpx.Response(200, headers={'set-cookie':'passport_csrf_token=csrf-fake; Domain=.doubao.com; Path=/'}, text='<html/>')
        if path == '/passport/web/get_qrcode/':
            self.assertNotIn('old-private', request.headers.get('cookie',''))
            self.assertEqual(request.headers['x-tt-passport-csrf-token'],'csrf-fake')
            return httpx.Response(200,json={'message':'success','data':{'error_code':0,'token':'qr-private','qrcode':self.qr}})
        if path == '/passport/web/check_qrconnect/':
            self.assertEqual(request.url.params['token'],'qr-private')
            state = self.poll_states.pop(0)
            return httpx.Response(200,json={'message':'success','data':{'error_code':0,'status':state,'redirect_url':'/passport/callback/' if state=='confirmed' else ''}})
        if path == '/passport/callback/':
            return httpx.Response(302,headers={'location':'/chat/','set-cookie':'sessionid=new-private; Domain=.doubao.com; Path=/; HttpOnly; Secure'})
        if path == '/passport/account/info/v2/': return httpx.Response(200,json={'message':'success','data':{'user_id_str':'123','screen_name':'test-user','is_visitor_account':False}})
        self.fail('Unexpected request ' + path)
    def run_task(self, kind, handler=None):
        host.atomic_json(self.job / 'request.json', {'kind':kind, **getattr(self, 'request_extra', {})})
        transport = httpx.MockTransport(handler or self.handler)
        def client(**kwargs): return self.original_client(transport=transport, **kwargs)
        with patch('httpx.Client',side_effect=client), patch.object(account.time,'sleep',return_value=None):
            # Inject pause explicitly; default function object was captured when QRFlow was defined.
            original = account.QRFlow.__init__
            def init(flow,*args,**kwargs): original(flow,*args,pause=lambda _:None,**kwargs)
            with patch.object(account.QRFlow,'__init__',init): account.process_account(self.job,host)
        return host.read_json(self.job/'status.json')
    def test_qr_full_flow_saves_new_account_and_removes_live_qr(self):
        status = self.run_task('login')
        self.assertEqual(status['state'],'done',status)
        saved = host.read_json(self.root/'runtime/http-session.json')
        self.assertEqual(saved['cookies']['sessionid'],'new-private')
        self.assertTrue(saved['params']['fp'].startswith('verify_'))
        self.assertEqual(len([r for r in self.calls if r.url.path.endswith('get_qrcode/')]),1)
        self.assertFalse((self.job/'qrcode.png').exists())
        log = (self.job/'worker.log').read_text(encoding='utf-8')
        self.assertNotIn('qr-private',log)
        self.assertNotIn('new-private',log)
        self.assertNotIn('old-private',log)
    def test_expired_qr_preserves_old_account_without_retry(self):
        self.poll_states=['expired']
        status = self.run_task('login')
        self.assertEqual(status['state'],'error')
        self.assertIn('过期',status['message'])
        self.assertEqual(host.read_json(self.root/'runtime/http-session.json')['cookies']['sessionid'],'old-private')
        self.assertEqual(len([r for r in self.calls if r.url.path.endswith('get_qrcode/')]),1)
    def test_cancel_after_scan_never_overwrites_session(self):
        def handler(request):
            response=self.handler(request)
            if request.url.path.endswith('check_qrconnect/'): (self.job/'cancel.flag').touch()
            return response
        status=self.run_task('login',handler)
        self.assertEqual(status['state'],'cancelled')
        self.assertEqual(host.read_json(self.root/'runtime/http-session.json')['cookies']['sessionid'],'old-private')
    def test_confirmed_without_credentials_does_not_claim_success(self):
        self.poll_states=['confirmed']
        def handler(request):
            if request.url.path=='/passport/callback/': return httpx.Response(200,text='no session')
            return self.handler(request)
        status=self.run_task('login',handler)
        self.assertEqual(status['state'],'error')
        self.assertEqual(host.read_json(self.root/'runtime/http-session.json')['cookies']['sessionid'],'old-private')
    def test_unknown_redirect_is_rejected_before_contact(self):
        self.poll_states=['confirmed']
        def handler(request):
            if request.url.path.endswith('check_qrconnect/'):
                self.calls.append(request)
                return httpx.Response(200,json={'data':{'error_code':0,'status':'confirmed','redirect_url':'https://attacker.example/callback'}})
            return self.handler(request)
        status=self.run_task('login',handler)
        self.assertEqual(status['state'],'error')
        self.assertFalse(any(r.url.host=='attacker.example' for r in self.calls))
    def test_qr_image_invalid_encoding_fails_safely(self):
        self.qr='not_base64'
        status=self.run_task('login')
        self.assertEqual(status['state'],'error')
        self.assertFalse((self.job/'qrcode.png').exists())
    def test_connection_probe_verifies_user_without_generation(self):
        status=self.run_task('check')
        self.assertEqual(status['state'],'done',status)
        self.assertEqual([r.url.path for r in self.calls],['/passport/account/info/v2/'])
    def test_old_route_401_is_not_used_after_qr_login(self):
        self.run_task('login')
        self.calls.clear()
        def handler(request):
            if request.url.path == '/api/user/info':
                self.calls.append(request)
                return httpx.Response(401)
            return self.handler(request)
        status = self.run_task('check',handler)
        self.assertEqual(status['state'],'done',status)
        self.assertEqual([r.url.path for r in self.calls],['/passport/account/info/v2/'])
    def test_visitor_uid_or_nested_passport_error_is_not_success(self):
        for data in ({'user_id_str':'123','is_visitor_account':True},
                     {'error_code':8,'description':'invalid session'},
                     {'id':'123'}, {'user_id_str':'0'}):
            def handler(request): return httpx.Response(200,json={'message':'success','data':data})
            status=self.run_task('check',handler)
            self.assertNotEqual(status['state'],'done',status)
    def test_stored_cookie_or_html_is_not_proof_of_login(self):
        for mode in ('html','empty','missing'):
            def handler(request):
                self.calls.append(request)
                if mode=='html': return httpx.Response(200,text='<html>login</html>')
                if mode=='empty': return httpx.Response(200,json={'code':0,'data':{}})
                return httpx.Response(404)
            status=self.run_task('check',handler)
            self.assertEqual(status['state'],'unverified',status)
    def test_connection_rejection_has_no_retries(self):
        def handler(request):
            self.calls.append(request)
            return httpx.Response(403)
        status=self.run_task('check',handler)
        self.assertEqual(status['state'],'error')
        self.assertEqual(len(self.calls),1)
        self.assertIn('403',status['message'])
    def test_no_account_invites_qr_without_network(self):
        (self.root/'runtime/http-session.json').unlink()
        status=self.run_task('check')
        self.assertEqual(status['state'],'error')
        self.assertIn('扫码登录',status['message'])
        self.assertEqual(self.calls,[])

    def test_managed_login_returns_independent_account_without_overwriting_legacy(self):
        self.request_extra = {'managed': True}
        status = self.run_task('login')
        self.assertEqual(status['state'], 'done')
        self.assertEqual(host.read_json(self.root/'runtime/http-session.json')['cookies']['sessionid'], 'old-private')
        result = host.read_json(self.job/'account-result.json')
        self.assertEqual(result['session']['cookies']['sessionid'], 'new-private')
        self.assertFalse((self.root/'config.json').exists())

    def test_managed_check_uses_selected_account_and_cleans_temporary_session(self):
        self.request_extra = {'managed': True}
        selected = {**self.session, 'cookies': {'sessionid': 'selected-account-private'}}
        host.atomic_json(self.job/'account-session.json', selected)
        status = self.run_task('check')
        self.assertEqual(status['state'], 'done')
        self.assertIn('selected-account-private', self.calls[0].headers['cookie'])
        self.assertNotIn('old-private', self.calls[0].headers['cookie'])
        self.assertFalse((self.job/'account-session.json').exists())
        self.assertEqual(host.read_json(self.root/'runtime/http-session.json')['cookies']['sessionid'], 'old-private')
        self.assertEqual(host.read_json(self.job/'account-result.json')['session']['cookies']['sessionid'], 'selected-account-private')

if __name__=='__main__': unittest.main()
