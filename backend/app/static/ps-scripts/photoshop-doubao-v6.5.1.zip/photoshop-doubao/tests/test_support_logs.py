import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import bridge_worker as w
import support_logs as support

class ExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / 'project'
        self.runtime = self.root / 'runtime'
        self.batch = self.runtime / 'batches/100-1'
        self.job = self.runtime / 'jobs/101-1'
        self.batch.mkdir(parents=True)
        self.job.mkdir(parents=True)
        self.patches = [patch.object(support, 'ROOT', self.root), patch.object(support, 'RUNTIME', self.runtime)]
        for p in self.patches: p.start()
        self.request = {'batch_name': '100-1', 'document_id': 12, 'source_layer_id': 23, 'width': 40, 'height': 50,
            'left': -10, 'top': 20, 'prompt': 'private-prompt', 'source_layer_name': 'private-layer', 'session_file': 'C:\\private\\account.json'}
        w.atomic_json(self.job / 'request.json', self.request)
        w.atomic_json(self.batch / 'request.json', {'document_id': 12, 'document_name': 'private-document',
            'items': [{'job_name': self.job.name, 'source_layer_id': 23}]})
        w.atomic_json(self.job / 'status.json', {'state': 'error', 'stage': 'generating', 'message': '没有返回图片 private-prompt https://private.example/?sessionid=secret',
            'log_path': 'C:\\private\\worker.log', 'worker_version': 'http-v6.1'})
        (self.job / 'worker.log').write_text('2026-11-03 12:00:00 error private-prompt C:\\private\\file https://private.example/\n', encoding='utf-8')
        w.atomic_json(self.runtime / 'http-session.json', {'cookie': 'private-cookie'})
        (self.job / 'source.png').write_bytes(b'private-image')
        self.output = Path(self.temp.name) / 'logs.zip'
    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()
    def test_legacy_batch_export_is_offline_minimal_and_redacted(self):
        with patch('httpx.Client', side_effect=AssertionError('export must stay offline')):
            support.export_archive(self.output, batch_name=self.batch.name)
        with zipfile.ZipFile(self.output) as archive:
            text = '\n'.join(archive.read(n).decode('utf-8') for n in archive.namelist())
            meta = json.loads(archive.read('jobs/101-1/metadata.json'))
            diag = json.loads(archive.read('jobs/101-1/diagnostic.json'))
            self.assertTrue(diag['legacy'])
            self.assertEqual(meta['source_layer_id'], 23)
            self.assertEqual(meta['left'], -10)
            for secret in ('private-prompt', 'private-layer', 'private-document', 'private-cookie', 'private-image',
                           'private.example', 'sessionid', 'C:\\private', str(self.root), 'source.png'):
                self.assertNotIn(secret, text)
                self.assertFalse(any(secret in n for n in archive.namelist()))
    def test_new_structured_events_and_ps_import_logs_are_allowlisted(self):
        w.atomic_json(self.job / 'diagnostic.json', {'worker_version': 'http-v6.2', 'outcome': 'error',
            'options': {'width': 40, 'prompt': 'private-prompt'}, 'stream': {'frames': 2, 'content_types': {'9999': 1},
            'block_types': {'2074': 1}, 'notice_codes': ['server_temporary_problem']}, 'raw': 'private-cookie'})
        (self.job / 'events.jsonl').write_text(json.dumps({'kind': 'http', 'stage': 'generating', 'status': 200,
            'url': 'https://private.example/', 'headers': {'cookie': 'private-cookie'}}) + '\n', encoding='utf-8')
        (self.job / 'ps-events.jsonl').write_text(json.dumps({'kind': 'import_error', 'line': 321, 'source_layer_id': 23, 'placed': False, 'message': 'private-layer'}) + '\n', encoding='utf-8')
        support.export_archive(self.output, batch_name='100-1')
        with zipfile.ZipFile(self.output) as archive:
            text = '\n'.join(archive.read(n).decode('utf-8') for n in archive.namelist())
            self.assertIn('server_temporary_problem', text)
            self.assertIn('2074', text)
            self.assertIn('321', text)
            for secret in ('private-prompt', 'private-cookie', 'private-layer', 'private.example'):
                self.assertNotIn(secret, text)
    def test_path_traversal_and_mismatched_layer_are_rejected(self):
        for name in ('../100-1', '100-1/../../', 'C:\\private', None):
            with self.assertRaises(w.UserError): support.collect(batch_name=name)
        req = dict(self.request, source_layer_id=999)
        w.atomic_json(self.job / 'request.json', req)
        with self.assertRaisesRegex(w.UserError, '对应'): support.collect(batch_name='100-1')
    def test_failed_export_preserves_existing_zip_and_leaves_no_temp(self):
        self.output.write_bytes(b'previous-archive')
        with patch.object(zipfile.ZipFile, 'writestr', side_effect=OSError('disk full')):
            with self.assertRaises(OSError): support.export_archive(self.output, job_name='101-1')
        self.assertEqual(self.output.read_bytes(), b'previous-archive')
        self.assertEqual(list(self.output.parent.glob('doubao-log-*.tmp')), [])
    def test_output_cannot_overwrite_project_or_use_nonzip(self):
        for output in (self.root / 'code.zip', self.job / 'result.zip', self.output.with_suffix('.png')):
            with self.assertRaises(w.UserError): support.export_archive(output, job_name='101-1')
    def test_latest_batch_and_single_job_export(self):
        w.atomic_json(self.runtime / 'active-http-batch.json', {'batch_name': '100-1'})
        self.assertEqual(support.latest(), {'batch_name': '100-1'})
        support.export_archive(self.output, job_name='101-1')
        with zipfile.ZipFile(self.output) as archive: self.assertNotIn('batch/status.json', archive.namelist())

    def test_api_diagnostics_use_fixed_vocabulary_for_details_and_options(self):
        from api_diagnostics import safe_error_details, safe_request_summary
        raw = {'http_status':400,'code':'InvalidParameter.private-cookie','param':'image',
               'category':'invalid_input_image','message':'private-prompt','url':'https://private.example',
               'request_id':'https://private.example/?key=private-cookie'}
        safe = safe_error_details(raw)
        self.assertEqual(safe, {'http_status':400,'code':'InvalidParameter','param':'image','category':'invalid_input_image'})
        summary = safe_request_summary({'billing_mode':'plan','model_family':'seedream5_pro','size':'2K',
            'fields':['image','prompt','private-cookie','https://private.example'], 'api_key':'private-cookie'})
        self.assertEqual(summary['fields'], ['image','prompt'])
        text = json.dumps({'error':safe,'request':summary})
        for secret in ('private-cookie','private-prompt','private.example'): self.assertNotIn(secret,text)

    def test_api_events_export_business_code_param_and_trace_id_without_raw_response(self):
        trace = '20261103203000AABBCCDDEEFF0011'
        detail = {'http_status':400,'code':'InvalidParameter','param':'model','request_id':trace,
                  'category':'invalid_model','message':'private-cookie','response':'private-prompt'}
        options = {'billing_mode':'plan','model_family':'seedream5_pro','size':'2K',
                   'model_normalized':True,'fields':['model','image','prompt','size'],'api_key':'private-cookie'}
        w.atomic_json(self.job/'diagnostic.json',{'api_error':detail,'api_request':options,'outcome':'error'})
        (self.job/'events.jsonl').write_text(json.dumps({'kind':'api_error',**detail})+'\n'+
            json.dumps({'kind':'api_request',**options})+'\n',encoding='utf8')
        support.export_archive(self.output,job_name=self.job.name)
        with zipfile.ZipFile(self.output) as z:
            text='\n'.join(z.read(n).decode('utf8') for n in z.namelist())
        for value in ('InvalidParameter','model',trace,'seedream5_pro'): self.assertIn(value,text)
        for secret in ('private-cookie','private-prompt','private.example'): self.assertNotIn(secret,text)

    def test_reference_and_upload_proof_survives_export_without_images_or_credentials(self):
        image={'width':40,'height':50,'bytes':12345,'count':1,'transport':'data_uri_png',
               'png_verified':True,'encoding_verified':True,'edit_instruction':'preserve_source_v1','image':'private-image'}
        response={'input_images':0,'generated_images':1,'reference_status':'rejected','raw':'private-prompt'}
        upload={'attempt':1,'code':'671020000','category':'unclassified','will_retry':True,
                'initialized':True,'csrf_source':'primary','has_ms_token':True,'token':'private-cookie'}
        w.atomic_json(self.job/'diagnostic.json',{'outcome':'error','input_image':image,
            'api_response':response,'uploads':[upload]})
        rows=[{'kind':kind,**value} for kind,value in [('input_image',image),('api_response',response),('web_upload',upload)]]
        (self.job/'events.jsonl').write_text('\n'.join(json.dumps(r) for r in rows),encoding='utf8')
        support.export_archive(self.output,job_name=self.job.name)
        with zipfile.ZipFile(self.output) as z:
            text='\n'.join(z.read(n).decode('utf8') for n in z.namelist())
            d=json.loads(z.read('jobs/101-1/diagnostic.json'))
        self.assertEqual(d['api_response']['input_images'],0)
        self.assertEqual(d['input_image']['bytes'],12345)
        self.assertTrue(d['uploads'][0]['will_retry'])
        for secret in ('private-cookie','private-prompt','private-image','private.example'): self.assertNotIn(secret,text)

    def test_reference_and_upload_details_reject_arbitrary_fields_and_wrong_types(self):
        from api_diagnostics import safe_input_image,safe_api_response,safe_web_upload
        self.assertEqual(safe_input_image({'width':True,'height':-1,'bytes':'private-cookie','transport':{},'png_verified':'secret'}),{})
        self.assertEqual(safe_api_response({'input_images':True,'reference_status':{},'raw':'private-cookie'}),{})
        self.assertEqual(safe_web_upload({'attempt':True,'code':'private-cookie','category':{},'csrf_source':[],
            'has_ms_token':'secret','request_id':'private-cookie'}),{})

if __name__ == '__main__': unittest.main()
