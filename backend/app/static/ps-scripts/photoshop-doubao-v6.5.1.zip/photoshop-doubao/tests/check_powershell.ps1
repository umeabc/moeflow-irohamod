$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
foreach ($name in @('install.ps1', 'stop_legacy.ps1', 'notify_completion.ps1')) {
    $syntaxTokens = $null
    $syntaxErrors = $null
    [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $projectRoot $name), [ref]$syntaxTokens, [ref]$syntaxErrors) | Out-Null
    if ($syntaxErrors.Count) { throw ($syntaxErrors | Out-String) }
    Write-Output ('PowerShell ' + $PSVersionTable.PSVersion + ' syntax passed: ' + $name)
}
