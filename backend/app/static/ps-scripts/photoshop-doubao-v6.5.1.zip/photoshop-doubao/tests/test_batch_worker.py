"""Offline queue and one-shot completion tests. Never opens Photoshop or a browser."""
from pathlib import Path
import json
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import batch_worker as batch
import bridge_worker as worker
import completion_notifier as notifier

class BatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.runtime = self.root / 'runtime'
        self.folder = self.runtime / 'batches' / '100-200'
        self.folder.mkdir(parents=True)
        self.patches = [patch.object(batch, 'ROOT', self.root), patch.object(batch, 'RUNTIME', self.runtime),
                        patch.object(worker, 'ROOT', self.root), patch.object(worker, 'RUNTIME', self.runtime)]
        for p in self.patches: p.start()
        self.items = []
        for index in range(3):
            item = {'job_name': '200-' + str(index + 1), 'source_layer_id': 10 + index, 'source_layer_name': '同名图层'}
            self.items.append(item)
            job = self.runtime / 'jobs' / item['job_name']
            job.mkdir(parents=True)
            (job / 'source.png').write_bytes(b'not-read-by-fake-worker')
            worker.atomic_json(job / 'request.json', {'document_id': 1, 'source_layer_id': item['source_layer_id'],
                'batch_name': self.folder.name})
        self.manifest = {'schema': 1, 'document_id': 1, 'items': self.items, 'notify': False}
        worker.atomic_json(self.folder / 'request.json', self.manifest)
        self.calls = []
    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()
    def fake(self, job):
        self.calls.append(job.name)
        worker.atomic_json(job / 'status.json', {'state': 'done', 'message': '完成', 'stage': 'downloading'})
    def run_batch(self, process=None):
        with patch.object(worker, 'process_job', side_effect=process or self.fake):
            return batch.process_batch(self.folder, poll_seconds=0.01)
    def test_sequential_duplicate_names_keep_distinct_layer_ids_and_jobs(self):
        running = []
        def process(job):
            self.assertEqual(running, [])
            running.append(job.name)
            self.fake(job)
            running.pop()
        result = self.run_batch(process)
        self.assertEqual(result['state'], 'done')
        self.assertEqual(self.calls, [item['job_name'] for item in self.items])
        self.assertEqual([item['source_layer_id'] for item in result['items']], [10, 11, 12])
        self.assertEqual(result['counts']['done'], 3)

    def test_credential_snapshot_is_kept_during_queue_then_removed_at_completion(self):
        path = self.folder / 'credentials.json'
        path.write_text('{"private":"not exported"}', encoding='utf-8')
        def process(job):
            self.assertTrue(path.exists())
            self.fake(job)
        self.assertEqual(self.run_batch(process)['state'], 'done')
        self.assertFalse(path.exists())

    def test_cancelled_batch_removes_private_snapshot(self):
        path = self.folder / 'credentials.json'
        path.write_text('{"private":"not exported"}', encoding='utf-8')
        (self.folder / 'cancel.flag').touch()
        self.assertEqual(self.run_batch()['state'], 'cancelled')
        self.assertFalse(path.exists())
    def test_one_failure_does_not_misassign_or_repeat_remaining_tasks(self):
        def process(job):
            self.calls.append(job.name)
            state = 'error' if job.name == self.items[1]['job_name'] else 'done'
            worker.atomic_json(job / 'status.json', {'state': state, 'message': '模拟结果'})
        result = self.run_batch(process)
        self.assertEqual(result['state'], 'partial')
        self.assertEqual([r['state'] for r in result['items']], ['done', 'error', 'done'])
        self.assertEqual(len(self.calls), 3)
    def test_cancellation_keeps_completed_result_and_does_not_submit_later_layers(self):
        def process(job):
            self.fake(job)
            (self.folder / 'cancel.flag').touch()
        result = self.run_batch(process)
        self.assertEqual(result['state'], 'cancelled')
        self.assertEqual(self.calls, [self.items[0]['job_name']])
        self.assertEqual([r['state'] for r in result['items']], ['done', 'cancelled', 'cancelled'])
    def test_previous_submission_lock_never_triggers_automatic_regeneration(self):
        first = self.runtime / 'jobs' / self.items[0]['job_name']
        (first / 'submitted.lock').touch()
        result = self.run_batch()
        self.assertEqual(self.calls, [item['job_name'] for item in self.items[1:]])
        self.assertEqual(result['items'][0]['state'], 'error')
        self.assertIn('未重发', result['items'][0]['message'])
    def test_duplicate_or_cross_document_binding_is_rejected_before_any_generation(self):
        for mode in ('duplicate-layer', 'duplicate-job', 'wrong-doc', 'wrong-batch', 'traversal'):
            with self.subTest(mode=mode):
                data = json.loads(json.dumps(self.manifest))
                if mode == 'duplicate-layer': data['items'][1]['source_layer_id'] = 10
                elif mode == 'duplicate-job': data['items'][1] = dict(data['items'][0])
                elif mode == 'wrong-doc': data['document_id'] = 9
                elif mode == 'wrong-batch':
                    job = self.runtime / 'jobs' / self.items[0]['job_name']
                    worker.atomic_json(job / 'request.json', {'document_id': 1, 'source_layer_id': 10, 'batch_name': 'wrong'})
                else: data['items'][0]['job_name'] = '../outside'
                worker.atomic_json(self.folder / 'request.json', data)
                result = self.run_batch()
                self.assertEqual(result['state'], 'error')
                self.assertEqual(self.calls, [])
    def test_progress_snapshot_updates_while_task_is_running(self):
        observed = threading.Event()
        def process(job):
            self.fake(job)
            if not observed.is_set():
                worker.atomic_json(job / 'status.json', {'state': 'generating', 'message': '模拟等待'})
                for _ in range(100):
                    state = worker.read_json(self.folder / 'status.json')
                    if state['items'][0]['state'] == 'generating': observed.set(); break
                    observed.wait(0.01)
                worker.atomic_json(job / 'status.json', {'state': 'done', 'message': '完成'})
        result = self.run_batch(process)
        self.assertTrue(observed.is_set())
        self.assertEqual(result['state'], 'done')
    def test_worker_exception_is_recorded_and_queue_continues(self):
        def process(job):
            if job.name == self.items[0]['job_name']: raise RuntimeError('private data')
            self.fake(job)
        result = self.run_batch(process)
        self.assertEqual(result['state'], 'partial')
        self.assertNotIn('private data', (self.folder / 'status.json').read_text(encoding='utf-8'))
    def test_notification_is_launched_once_without_running_com_or_photoshop(self):
        with patch.object(notifier.subprocess, 'Popen') as launch:
            notifier.notify_completion(self.folder)
            notifier.notify_completion(self.folder)
        self.assertEqual(launch.call_count, 1)
        args = launch.call_args.args[0]
        self.assertIn('-WindowStyle', args)
        self.assertEqual(args[-1], self.folder.name)
        self.assertIn('Hidden', args)
    def test_duplicate_batch_launcher_is_inert(self):
        args = ['batch_worker.py', '--job', str(self.folder)]
        with patch.object(sys, 'argv', args), patch.object(batch, 'process_batch') as process:
            batch.main()
            batch.main()
        self.assertEqual(process.call_count, 1)
    def test_cancel_reaches_running_layer_and_no_later_layer_starts(self):
        reached = threading.Event()
        def process(job):
            self.calls.append(job.name)
            worker.atomic_json(job / 'status.json', {'state': 'generating', 'message': '模拟生成中'})
            (self.folder / 'cancel.flag').touch()
            deadline = time.monotonic() + 1
            while time.monotonic() < deadline:
                if (job / 'cancel.flag').exists():
                    reached.set()
                    worker.atomic_json(job / 'status.json', {'state': 'cancelled', 'message': '模拟取消'})
                    return
                reached.wait(0.01)
            raise RuntimeError('Cancellation was not propagated')
        result = self.run_batch(process)
        self.assertTrue(reached.is_set())
        self.assertEqual(self.calls, [self.items[0]['job_name']])
        self.assertEqual(result['counts']['cancelled'], 3)

class RetryBatchTests(unittest.TestCase):
    setUp, tearDown = BatchTests.setUp, BatchTests.tearDown
    fake, run_batch = BatchTests.fake, BatchTests.run_batch
    def prepare_retry(self):
        self.original = self.runtime / 'batches/100-100'
        self.original.mkdir()
        worker.atomic_json(self.original / 'request.json', self.manifest)
        for index, item in enumerate(self.items):
            job = self.runtime / 'jobs' / item['job_name']
            worker.atomic_json(job / 'request.json', {'document_id': 1, 'source_layer_id': item['source_layer_id'], 'batch_name': self.original.name})
            worker.atomic_json(job / 'status.json', {'state': 'error' if index == 0 else 'done', 'message': '原任务'})
            if index:
                (job / 'result.png').write_bytes(b'original-result')
                (job / 'submitted.lock').write_text('old-lock')
        (self.runtime / 'jobs' / self.items[2]['job_name'] / 'imported.flag').write_text('already-imported')
        new_job = self.runtime / 'jobs/300-1'
        new_job.mkdir()
        (new_job / 'source.png').write_bytes(b're-exported-current-layer')
        worker.atomic_json(new_job / 'request.json', {'document_id': 1, 'source_layer_id': 10,
            'batch_name': self.folder.name, 'retry_of': self.items[0]['job_name']})
        rows = [{**self.items[0], 'job_name': '300-1'}]
        rows += [{**item, 'carried': True, 'carried_from_batch': self.original.name} for item in self.items[1:]]
        self.manifest = {**self.manifest, 'items': rows, 'previous_batch_name': self.original.name}
        worker.atomic_json(self.folder / 'request.json', self.manifest)
        return new_job
    def test_retry_only_executes_new_failed_attempt_and_keeps_original_records(self):
        new_job = self.prepare_retry()
        result = self.run_batch()
        self.assertEqual(self.calls, [new_job.name])
        self.assertEqual(result['state'], 'done')
        self.assertEqual(result['counts']['done'], 3)
        self.assertEqual(worker.read_json(self.runtime / 'jobs/200-1/status.json')['state'], 'error')
        self.assertEqual((self.runtime / 'jobs/200-2/result.png').read_bytes(), b'original-result')
        self.assertEqual((self.runtime / 'jobs/200-3/imported.flag').read_text(), 'already-imported')
    def test_failed_unselected_row_stays_failed_without_resubmission(self):
        self.prepare_retry()
        worker.atomic_json(self.runtime / 'jobs/200-2/status.json', {'state': 'error', 'message': '未选中的失败项'})
        result = self.run_batch()
        self.assertEqual(self.calls, ['300-1'])
        self.assertEqual(result['state'], 'partial')
        self.assertEqual(result['counts'], {'done': 2, 'error': 1, 'cancelled': 0})
    def test_cancel_retry_keeps_previously_successful_rows(self):
        self.prepare_retry()
        (self.folder / 'cancel.flag').touch()
        result = self.run_batch()
        self.assertEqual(self.calls, [])
        self.assertEqual(result['counts'], {'done': 2, 'error': 0, 'cancelled': 1})
        self.assertEqual(worker.read_json(self.runtime / 'jobs/200-2/status.json')['state'], 'done')
    def test_second_run_never_reexecutes_old_or_new_submission(self):
        self.prepare_retry()
        self.run_batch()
        self.run_batch()
        self.assertEqual(self.calls, ['300-1'])
    def test_invalid_carried_reference_is_rejected_before_new_generation(self):
        for mode in ('wrong-source', 'cross-document', 'running', 'missing-result'):
            with self.subTest(mode=mode):
                if not hasattr(self, 'original'): self.prepare_retry()
                manifest = json.loads(json.dumps(self.manifest))
                status = {'state': 'done'}
                worker.atomic_json(self.runtime / 'jobs/200-2/status.json', status)
                (self.runtime / 'jobs/200-2/result.png').write_bytes(b'result')
                original = worker.read_json(self.original / 'request.json')
                original['document_id'] = 1
                if mode == 'wrong-source': manifest['items'][1]['carried_from_batch'] = '../outside'
                elif mode == 'cross-document': original['document_id'] = 99
                elif mode == 'running': worker.atomic_json(self.runtime / 'jobs/200-2/status.json', {'state': 'generating'})
                else: (self.runtime / 'jobs/200-2/result.png').unlink()
                worker.atomic_json(self.original / 'request.json', original)
                worker.atomic_json(self.folder / 'request.json', manifest)
                result = self.run_batch()
                self.assertEqual(result['state'], 'error')
                self.assertEqual(self.calls, [])
    def test_retry_batch_log_export_preserves_original_job_mapping(self):
        self.prepare_retry()
        self.run_batch()
        import support_logs as support
        with patch.object(support, 'RUNTIME', self.runtime):
            files = support.collect(batch_name=self.folder.name)
        self.assertIn('jobs/300-1/status.json', files)
        self.assertIn('jobs/200-2/status.json', files)
        self.assertIn('jobs/200-3/status.json', files)
        self.assertEqual(json.loads(files['jobs/300-1/metadata.json'])['retry_of'], '200-1')

if __name__ == '__main__': unittest.main()
