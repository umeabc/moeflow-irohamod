"""Wire-level offline checks, fake keys and images only."""
import base64
import json
from io import BytesIO
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import httpx
from PIL import Image
import bridge_worker as host
from generation_profiles import validate_api
from image_api import generate
from support_logs import safe_diagnostic


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.job = self.root / '1-1'
        self.job.mkdir()
        self.path = self.job / 'upload.png'
        Image.new('RGB', (30, 20), 'red').save(self.path)
        image = BytesIO()
        Image.new('RGB', (12, 18), 'blue').save(image, format='PNG')
        self.png = image.getvalue()
        self.b64 = base64.b64encode(self.png).decode('ascii')
        self.calls = []
        self.profile = {'protocol': 'openai', 'provider': 'openai', 'endpoint': 'https://api.openai.com/v1/images/edits',
            'api_key': 'private-key-example', 'model': 'gpt-image-2', 'billing_mode': 'standard', 'size': 'auto'}

    def tearDown(self): self.temp.cleanup()

    def run_generate(self, data=None, handler=None, status=200):
        if data is None: data = {'data': [{'b64_json': self.b64}]}
        def response(r):
            self.calls.append(r)
            return handler(r) if handler else httpx.Response(status, json=data)
        diagnostic = host.Diagnostics(self.job, host.WORKER_VERSION, host.atomic_json)
        with httpx.Client(transport=httpx.MockTransport(response)) as client:
            return generate(client, self.profile, self.path, 'private-prompt', lambda: 60, diagnostic, host.UserError)

    def gemini(self, relay=False):
        self.profile.update(protocol='gemini', provider='gemini', model='gemini-3.1-flash-image', size='2K',
            endpoint='https://' + ('relay.example' if relay else 'generativelanguage.googleapis.com') + '/v1beta/models/{model}:generateContent',
            billing_mode='custom' if relay else 'standard')

    def grsai(self, provider='gemini'):
        self.profile.update(protocol='grsai', provider=provider, model='nano-banana-2' if provider == 'gemini' else 'gpt-image-2.6',
            endpoint='https://grsaiapi.com/v1/api/generate', billing_mode='custom', size='1K' if provider == 'gemini' else '1024x1024')

    def test_openai_multipart_contains_exact_png_and_no_seedream_fields(self):
        result = self.run_generate()
        self.assertEqual(result['bytes'], self.png)
        self.assertEqual(result['reference_status'], 'not_reported')
        self.assertEqual(len(self.calls), 1)
        r = self.calls[0]
        self.assertEqual(str(r.url), self.profile['endpoint'])
        self.assertIn('boundary=', r.headers['content-type'])
        self.assertIn(self.path.read_bytes(), r.content)
        self.assertIn(b'name="image"; filename="layer.png"', r.content)
        for field in ('model', 'prompt', 'n', 'size', 'quality'):
            self.assertIn(('name="' + field + '"').encode(), r.content)
        self.assertNotIn(b'watermark', r.content)
        self.assertNotIn(b'response_format', r.content)

    def test_gemini_inline_image_and_official_header(self):
        self.gemini()
        result = self.run_generate({'candidates': [{'finishReason': 'STOP', 'content': {'parts': [
            {'inlineData': {'mimeType': 'image/png', 'data': self.b64}}]}}]})
        self.assertEqual(result['bytes'], self.png)
        r = self.calls[0]
        self.assertEqual(r.headers['x-goog-api-key'], 'private-key-example')
        self.assertNotIn('authorization', r.headers)
        self.assertTrue(r.url.path.endswith('/gemini-3.1-flash-image:generateContent'))
        payload = json.loads(r.content)
        self.assertEqual(base64.b64decode(payload['contents'][0]['parts'][1]['inlineData']['data']), self.path.read_bytes())
        self.assertEqual(payload['generationConfig'], {'responseModalities': ['TEXT', 'IMAGE'], 'imageConfig': {'imageSize': '2K'}})

    def test_gemini_auto_omits_image_config_and_relay_uses_bearer(self):
        self.gemini(relay=True)
        self.profile['size'] = 'auto'
        self.run_generate({'candidates': [{'content': {'parts': [{'inline_data': {'mime_type': 'image/png', 'data': self.b64}}]}}]})
        self.assertEqual(self.calls[0].headers['authorization'], 'Bearer private-key-example')
        self.assertNotIn('x-goog-api-key', self.calls[0].headers)
        self.assertNotIn('imageConfig', json.loads(self.calls[0].content)['generationConfig'])

    def test_gemini_text_or_thought_image_is_never_importable(self):
        self.gemini()
        for part in ({'text': 'private-upstream'}, {'thought': True, 'inlineData': {'mimeType': 'image/png', 'data': self.b64}}):
            with self.assertRaisesRegex(host.UserError, '只返回文本或没有图片'):
                self.run_generate({'candidates': [{'content': {'parts': [part]}}]})

    def test_gemini_safety_finish_blocks_image(self):
        self.gemini()
        with self.assertRaisesRegex(host.UserError, '未完整返回'):
            self.run_generate({'candidates': [{'finishReason': 'SAFETY', 'content': {'parts': [{'inlineData': {'mimeType': 'image/png', 'data': self.b64}}]}}]})

    def test_grsai_reference_array_not_empty_and_own_response(self):
        self.grsai()
        result = self.run_generate({'status': 'succeeded', 'results': [{'url': 'https://cdn.example/image'}]})
        self.assertEqual(result['url'], 'https://cdn.example/image')
        payload = json.loads(self.calls[0].content)
        self.assertEqual(len(payload['images']), 1)
        self.assertEqual(base64.b64decode(payload['images'][0].split(',')[1]), self.path.read_bytes())
        self.assertEqual(payload['replyType'], 'json')
        self.assertEqual(payload['imageSize'], '1K')
        self.assertNotIn('quality', payload)

    def test_grsai_gpt_uses_pixel_aspect_ratio(self):
        self.grsai('openai')
        self.run_generate({'status': 'succeeded', 'results': [{'b64_json': self.b64}]})
        payload = json.loads(self.calls[0].content)
        self.assertEqual(payload['aspectRatio'], '1024x1024')
        self.assertNotIn('imageSize', payload)

    def test_grsai_exact_task_poll_is_get_only(self):
        self.grsai()
        def handler(r):
            if r.method == 'POST': return httpx.Response(200, json={'status': 'running', 'id': '14-test-123'})
            self.assertEqual(str(r.url), 'https://grsaiapi.com/v1/api/result?id=14-test-123')
            return httpx.Response(200, json={'status': 'succeeded', 'id': '14-test-123', 'results': [{'b64_json': self.b64}]})
        # Finite polling delay is replaced only in this offline test.
        with patch('image_api.time.sleep'), patch('image_api.time.monotonic', side_effect=range(1000)):
            self.assertEqual(self.run_generate(handler=handler)['bytes'], self.png)
        self.assertEqual([r.method for r in self.calls], ['POST', 'GET'])

    def test_grsai_different_task_is_rejected(self):
        self.grsai()
        def handler(r):
            return httpx.Response(200, json={'status': 'running', 'id': 'one'}) if r.method == 'POST' else httpx.Response(200, json={'status': 'succeeded', 'id': 'other', 'results': [{'b64_json': self.b64}]})
        with patch('image_api.time.sleep'), patch('image_api.time.monotonic', side_effect=range(1000)):
            with self.assertRaisesRegex(host.UserError, '其他任务'): self.run_generate(handler=handler)
        self.assertEqual(sum(r.method == 'POST' for r in self.calls), 1)

    def test_unsupported_endpoint_protocol_or_auth_fails_without_post(self):
        variants = [dict(endpoint='https://api.openai.com/v1/images/generations'),
            dict(protocol='gemini', provider='gemini'), dict(auth_mode='google'), dict(billing_mode='plan'),
            dict(size='2K'), dict(endpoint='https://api.openai.com/v1/images/edits?key=private')]
        for variant in variants:
            p = {**self.profile, **variant}
            with self.assertRaises(host.UserError): validate_api(p, host.UserError)
        self.assertEqual(self.calls, [])

    def test_nonmatching_gemini_model_path_is_not_silently_changed(self):
        self.gemini()
        self.profile['endpoint'] = self.profile['endpoint'].replace('{model}', 'different-model')
        with self.assertRaisesRegex(host.UserError, '不一致'): self.run_generate()
        self.assertEqual(self.calls, [])

    def test_reference_count_zero_blocks_other_adapters(self):
        with self.assertRaisesRegex(host.UserError, '输入图片 0 张'):
            self.run_generate({'data': [{'b64_json': self.b64}], 'usage': {'input_images': 0}})
        self.assertEqual(len(self.calls), 1)

    def test_http_error_and_invalid_base64_never_retry(self):
        for data, status in (({'error': {'message': 'private-upstream', 'code': 'InvalidApiKey'}}, 401),
                             ({'data': [{'b64_json': 'invalid!'}]}, 200)):
            self.calls.clear()
            with self.assertRaises(host.UserError) as caught: self.run_generate(data, status=status)
            self.assertNotIn('private-upstream', str(caught.exception))
            self.assertEqual(len(self.calls), 1)

    def test_safe_diagnostics_include_protocol_without_credentials_image_or_prompt(self):
        self.gemini()
        self.run_generate({'candidates': [{'content': {'parts': [{'inlineData': {'mimeType': 'image/png', 'data': self.b64}}]}}]})
        raw = host.read_json(self.job / 'diagnostic.json')
        safe = safe_diagnostic(raw)
        self.assertEqual(safe['api_request']['protocol'], 'gemini')
        self.assertEqual(safe['input_image']['transport'], 'inline_data_png')
        text = json.dumps(safe)
        for value in ('private-key-example', 'private-prompt', self.b64): self.assertNotIn(value, text)


if __name__ == '__main__': unittest.main()
