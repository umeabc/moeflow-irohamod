"""Regression coverage for the redacted v6.1 history shape and SSE variants."""
import json
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import bridge_worker as w
import test_http_worker as legacy
import httpx

def block_image():
    return {'block_type': 2074, 'content_v2': json.dumps({'creation_block': {'creations': [
        {'type': 1, 'image': {'key': 'generated-1', 'image_ori_raw': {'url': 'https://cdn.example/new-image_raw.png'}}}]}})}

class FormatTests(unittest.TestCase):
    def test_redacted_real_history_shape(self):
        groups = json.loads((Path(__file__).parent / 'fixtures/history_v61_redacted.json').read_text(encoding='utf-8'))
        found = []
        for group in groups:
            variants = []
            for message in group: variants += w.image_variants({'message': message})
            found.append(any(v['source'] == 'server_original' for v in variants))
        self.assertEqual(found, [False, True, True])

    def test_new_full_message_and_patch_without_event_type(self):
        for name, payload in (
            ('FULL_MSG_NOTIFY', {'message': {'content_type': 9999, 'content_block': [block_image()]}}),
            ('STREAM_CHUNK', {'patch_op': [{'patch_value': {'content_block': [block_image()]}}]}),
            ('FULL_MSG_NOTIFY', {'message': json.dumps({'content_type': 9999, 'content': json.dumps([block_image()])})}),
        ):
            events = list(w.sse_events(['event: ' + name, 'data: ' + json.dumps(payload), ''], lambda: None))
            self.assertEqual(events[0]['_sse_event'], name)
            self.assertEqual(w.image_urls(events[0]), ['https://cdn.example/new-image_raw.png'])

    def test_reference_echo_and_unrelated_urls_never_become_output(self):
        for content in (
            {'message': {'reply_id': '0', 'content_type': 9999, 'content_block': [block_image()]}},
            {'message': {'user_type': 1, 'content_type': 9999, 'content_block': [block_image()]}},
            {'message': {'content_type': 1, 'content': json.dumps({'text': 'https://cdn.example/new-image_raw.png'}),
                         'attachments': [block_image()]}},
        ): self.assertEqual(w.image_urls(content), [])

    def test_temporary_failure_is_classified_without_recording_text(self):
        message = {'content_type': 9999, 'content': json.dumps([
            {'block_type': 10000, 'content': json.dumps({'text': '出了点问题，请稍后重试。 private text'})}])}
        msgs, blocks = w.generation_parts({'message': message})
        codes = w.server_notices(msgs, blocks)
        self.assertEqual(codes, ['server_temporary_problem'])
        self.assertIn('服务端暂时异常', str(w.no_image_error(codes)))
        self.assertNotIn('private text', str(w.no_image_error(codes)))

    def test_named_stream_error_is_not_ignored(self):
        events = list(w.sse_events(['event: STREAM_ERROR', 'data: {"error_code":701}', ''], lambda: None))
        with self.assertRaisesRegex(w.UserError, '701'): w.image_variants(events[0])

class DiagnosticHTTPTests(unittest.TestCase):
    # Reuse the established HTTP mock harness; no duplicated inherited tests.
    setUp, tearDown = legacy.OfflineHTTPTests.setUp, legacy.OfflineHTTPTests.tearDown
    handler, run_job = legacy.OfflineHTTPTests.handler, legacy.OfflineHTTPTests.run_job
    def test_new_card_full_pipeline_records_only_structure(self):
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                payload = {'message': {'content_type': 9999, 'content_block': [block_image()]}}
                return httpx.Response(200, text='event: FULL_MSG_NOTIFY\ndata: ' + json.dumps(payload) + '\n\ndata: [DONE]\n\n')
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'done', status)
        diag = w.read_json(self.job / 'diagnostic.json')
        self.assertEqual(diag['stream']['content_types'], {'9999': 1})
        self.assertIn('2074', diag['stream']['block_types'])
        self.assertTrue(diag['stream']['completed'])
        self.assertEqual([r['stage'] for r in diag['requests']], ['initializing', 'uploading', 'resolving', 'generating', 'downloading'])
        logged = (self.job / 'events.jsonl').read_text(encoding='utf-8') + json.dumps(diag)
        for secret in ('fake-secret', 'cdn.example', 'new-image_raw', '移除文字', 'a_bogus'):
            self.assertNotIn(secret, logged)

    def test_server_temporary_error_has_precise_status_and_counts(self):
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                payload = {'message': {'content_type': 9999, 'content_block': [
                    {'block_type': 10000, 'content_v2': {'text_block': {'text': '出了点问题，请稍后重试。'}}}]}}
                return httpx.Response(200, text='data: ' + json.dumps(payload) + '\n\n')
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'error')
        self.assertIn('服务端暂时异常', status['message'])
        diag = w.read_json(self.job / 'diagnostic.json')
        self.assertEqual(diag['stream']['notice_codes'], ['server_temporary_problem'])
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
        self.assertFalse(any(r.url.host == 'cdn.example' for r in self.calls))

    def test_unknown_structure_stays_distinct_from_login_failure(self):
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                return httpx.Response(200, text='data: {"event_type":2001,"event_data":{"message":{"content_type":7777}}}\n\n')
            return self.handler(request)
        status = self.run_job(handler)
        self.assertIn('响应格式变化', status['message'])
        self.assertNotIn('登录失效', status['message'])
        self.assertEqual(w.read_json(self.job / 'diagnostic.json')['stream']['content_types'], {'7777': 1})

    def test_missing_stream_card_reads_exact_acknowledged_history_without_regenerating(self):
        cid = '123456789012345678'
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                return httpx.Response(200, text='event: SSE_ACK\ndata: ' + json.dumps({'ack_client_meta': {'conversation_id': cid}}) + '\n\n')
            if request.url.path.endswith('/latest_messagelist'):
                self.calls.append(request)
                self.assertEqual(json.loads(request.content)['request_list'][0]['conversation_id'], cid)
                return httpx.Response(200, json={'code': 0, 'data': {'message_map': {cid: [
                    {'conversation_id': cid, 'content_type': 9999, 'content_block': [block_image()]}]}}})
            return self.handler(request)
        status = self.run_job(handler)
        self.assertEqual(status['state'], 'done', status)
        self.assertEqual(sum(r.url.path.endswith('/completion') for r in self.calls), 1)
        self.assertEqual(sum(r.url.path.endswith('/latest_messagelist') for r in self.calls), 1)
        diag = w.read_json(self.job / 'diagnostic.json')
        self.assertIn('history', [r['stage'] for r in diag['requests']])
        self.assertNotIn(cid, json.dumps(diag))

    def test_history_never_uses_image_from_other_conversation(self):
        cid = '123456789012345678'
        def handler(request):
            if request.url.path.endswith('/completion'):
                self.calls.append(request)
                return httpx.Response(200, text='data: ' + json.dumps({'conversation_id': cid}) + '\n\n')
            if request.url.path.endswith('/latest_messagelist'):
                self.calls.append(request)
                return httpx.Response(200, json={'code': 0, 'data': {'message_map': {'other': [
                    {'conversation_id': '999999999999999999', 'content_type': 9999, 'content_block': [block_image()]}]}}})
            return self.handler(request)
        from unittest.mock import patch
        with patch.object(w.time, 'sleep'):
            status = self.run_job(handler)
        self.assertEqual(status['state'], 'error')
        self.assertEqual(sum(r.url.path.endswith('/latest_messagelist') for r in self.calls), 3)
        self.assertFalse(any(r.url.host == 'cdn.example' for r in self.calls))

if __name__ == '__main__': unittest.main()
