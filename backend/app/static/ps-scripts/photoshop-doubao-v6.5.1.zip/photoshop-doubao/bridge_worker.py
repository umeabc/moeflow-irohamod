"""Finite HTTP-only worker. No browser or upstream application imports."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import time
from urllib.parse import urlencode, urlsplit
import uuid
from diagnostics import Diagnostics

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / 'runtime'
SIGNER_SHA256 = 'be9927d53abe10a88101eb09ab93c528ca22a5302cd0d4c8dfe22984d1d4c434'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
ORIGIN = 'https://www.doubao.com'
MAX_BYTES = 50 * 1024 * 1024
WORKER_VERSION = 'http-v6.5.1'
DEFAULT_PROMPT = '移除图片中的所有文字，自然补全背景，保持人物、物体、构图、颜色和非文字细节，避免添加文字。'

class UserError(Exception): pass
class Cancelled(UserError): pass

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    try:
        for attempt in range(20):
            try:
                os.replace(temp, path)
                return
            except PermissionError:
                if attempt == 19: raise
                time.sleep(0.05)
    finally:
        temp.unlink(missing_ok=True)

def normalize_session(data):
    params, name = {}, '豆包网页账号'
    if isinstance(data, dict) and 'accounts' in data:
        accounts = data['accounts']
        if isinstance(accounts, dict): accounts = list(accounts.values())
        if not accounts: raise UserError('账号文件没有登录信息。')
        active = data.get('active_account_id') or data.get('active_account')
        data = next((a for a in accounts if a.get('id') == active), accounts[0])
    if isinstance(data, dict):
        params = dict(data.get('params') or {})
        for key in ('device_id', 'web_id', 'fp', 'msToken'):
            if data.get(key): params[key] = str(data[key])
        name = str(data.get('name') or name)
        cookies = data.get('cookies', data.get('cookie', {}))
    else: cookies = data
    if isinstance(cookies, str):
        cookies = dict(part.strip().split('=', 1) for part in cookies.split(';') if '=' in part)
    if isinstance(cookies, list):
        cookies = {str(c['name']): str(c['value']) for c in cookies if isinstance(c, dict) and 'name' in c and 'value' in c}
    if not isinstance(cookies, dict) or not (cookies.get('sessionid') or cookies.get('sid_tt')):
        raise UserError('账号资料缺少 sessionid/sid_tt。请返回 PS 窗口点击“扫码登录”。')
    cookies = {str(k): str(v) for k, v in cookies.items()}
    if any('\r' in v or '\n' in v for v in cookies.values()): raise UserError('Cookie 字符无效。')
    if not params.get('device_id') or not params.get('web_id'):
        log = RUNTIME / 'service.log'
        if log.exists():
            matches = re.findall(r'Params: device_id=(\d+), web_id=(\d+), fp=([^\s,]+)', log.read_text(encoding='utf-8', errors='replace'))
            if matches:
                device, web, _ = matches[-1]
                params.setdefault('device_id', device)
                params.setdefault('web_id', web)
    params.setdefault('fp', cookies.get('s_v_web_id', ''))
    if not all(params.get(k) for k in ('device_id', 'web_id', 'fp')):
        raise UserError('资料缺少 device_id、web_id 或 fp。请按 session.example.json 填写后导入；不会启动浏览器。')
    return {'name': name, 'cookies': cookies, 'params': params}

def session_marker(session):
    return hashlib.sha256(json.dumps(session['cookies'], sort_keys=True).encode('utf-8')).hexdigest()[:24]

def load_session(import_path=None):
    path = Path(import_path) if import_path else RUNTIME / 'http-session.json'
    if not import_path and not path.exists(): path = RUNTIME / 'browser-profile' / 'accounts.json'
    if not path.is_file(): raise UserError('尚无网页账号资料。请在 PS 窗口中点击“扫码登录”，用手机豆包扫码确认。')
    session = normalize_session(read_json(path))
    atomic_json(RUNTIME / 'http-session.json', session)
    marker = session_marker(session)
    info = {'name': session['name'], 'message': '登录资料已保存；可点击“检查连接”确认', 'session_marker': marker}
    info_path = RUNTIME / 'http-account-info.json'
    if info_path.exists():
        try:
            previous = read_json(info_path)
            if previous.get('session_marker') == marker: info = previous
        except (ValueError, OSError): pass
    atomic_json(info_path, info)
    return session

def load_signer():
    path = RUNTIME / 'http-signer' / 'pure_signer.py'
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != SIGNER_SHA256:
        raise UserError('纯 HTTP 签名组件缺失或校验失败，请运行 install.cmd。')
    # Hash-pinned audited dependency: supply config constants without importing its server.
    source = path.read_text(encoding='utf-8').replace('from config import CONFIG, USER_AGENT', '# constants supplied by host')
    ns = {'__file__': str(path), '__name__': 'doubao_isolated_signer', 'CONFIG': {}, 'USER_AGENT': UA}
    exec(compile(source, str(path), 'exec'), ns)
    return ns['sign_payload_python']

def remaining(deadline, job):
    if (job / 'cancel.flag').exists(): raise Cancelled('已取消；已提交给豆包的生成可能继续，结果不会自动导入。')
    value = deadline - time.monotonic()
    if value <= 0: raise UserError('处理超时，未重复提交生成请求。')
    return value

def response_code(data):
    # Never copy an arbitrary response field into a local status/log.
    value = data.get('code', data.get('error_code', '未知')) if isinstance(data, dict) else '未知'
    return str(value) if re.fullmatch(r'-?\d{1,12}', str(value)) else '未知'

def error_category(detail):
    # Keep useful classifications, but never save free-form upstream messages:
    # those can echo a prompt, a URL, or login credentials.
    detail = object_data(detail)
    values = [detail.get(key) for key in ('message', 'msg', 'error_msg', 'error_message')]
    text = ' '.join(value[:2000].lower() for value in values if isinstance(value, str))
    categories = []
    for words, label in (
        (('captcha', '验证码', '人机验证'), '要求额外验证'),
        (('not login', 'not logged in', 'login expired', 'session expired', 'csrf', 'token mismatch', '未登录', '登录过期', '登录失效'), '账号授权异常'),
        (('quota', '额度', '次数已用完'), '额度或次数限制'),
        (('invalid parameter', 'invalid param', '参数错误', '参数无效', '参数不合法', 'invalid attachment', '附件无效'), '参数或附件无效'),
        (('risk control', '风控', '风险控制'), '风控限制'),
        (('sensitive', 'moderation', 'content policy', 'content review', 'unsafe image', '审核', '敏感', '违规'), '内容审核限制'),
    ):
        if any(word in text for word in words): categories.append(label)
    return '；'.join(categories)

def api_error(stage, code, detail=None):
    category = error_category(detail)
    explanation = f'接口提示：{category}。' if category else '接口未提供可识别的具体原因。'
    error = UserError(f'{stage}失败（{code}）。{explanation}此错误不能单独判定登录失效，可用“检查连接”单独核实账号。未自动重试。')
    if stage == '图片上传' and code == '接口码 671020000':
        error = UserError('图片上传被豆包拒绝（671020000）。本层尚未提交生成；' +
                          (('接口分类：' + category + '。') if category else '服务端未提供可识别的具体原因；不能仅据此判定为首张、登录或审核问题。') +
                          '批次结束后可选择本层重试，其他成功结果保留。')
    error.api_codes = re.findall(r'(?<!\d)-?\d{1,12}(?!\d)', str(code))
    return error

def check_response(response, stage):
    if response.status_code != 200: raise api_error(stage, 'HTTP ' + str(response.status_code))

def json_data(response, stage):
    check_response(response, stage)
    try: data = response.json()
    except ValueError as exc: raise api_error(stage, '非 JSON 响应') from exc
    if not isinstance(data, dict) or str(data.get('code', -1)) != '0':
        raise api_error(stage, '接口码 ' + response_code(data), data)
    result = data.get('data') or {}
    if not isinstance(result, dict): raise api_error(stage, '响应数据格式错误')
    return result

def object_data(value):
    if isinstance(value, str):
        try: value = json.loads(value)
        except ValueError: return {}
    return value if isinstance(value, dict) else {}

def decoded(value):
    if isinstance(value, str):
        try: return json.loads(value)
        except ValueError: return value
    return value

def message_blocks(message):
    output = []
    for value in (message.get('content_block'), message.get('content')):
        value = decoded(value)
        if isinstance(value, dict): value = value.get('content_block', [])
        if isinstance(value, list): output.extend(block for block in value if isinstance(block, dict))
    return output

def user_message(message):
    return str(message.get('reply_id', '')) == '0' or str(message.get('user_type', '')) == '1'

def generation_parts(event):
    payload = object_data(event.get('event_data')) if 'event_data' in event else event
    messages, blocks = [], []
    message = object_data(payload.get('message'))
    if message: messages.append(message)
    for patch in payload.get('patch_op', []) if isinstance(payload.get('patch_op'), list) else []:
        if not isinstance(patch, dict): continue
        value = decoded(patch.get('patch_value'))
        if isinstance(value, dict):
            if user_message(value): continue
            if isinstance(value.get('content_block'), list): blocks.extend(value['content_block'])
            if 'block_type' in value: blocks.append(value)
            msg = object_data(value.get('message'))
            if msg: messages.append(msg)
        elif isinstance(value, list): blocks.extend(value)
    for msg in messages:
        # User echoes can contain reference images. They are never output results.
        if not user_message(msg): blocks.extend(message_blocks(msg))
    return messages, [block for block in blocks if isinstance(block, dict)]

def server_notices(messages, blocks):
    texts = []
    for message in messages:
        if user_message(message): continue
        content = decoded(message.get('content'))
        if isinstance(content, dict) and isinstance(content.get('text'), str): texts.append(content['text'])
    for block in blocks:
        if str(block.get('block_type')) != '10000': continue
        for key in ('content', 'content_v2'):
            content = object_data(block.get(key))
            text = content.get('text') or object_data(content.get('text_block')).get('text')
            if isinstance(text, str): texts.append(text)
    text = '\n'.join(texts)
    found = []
    for phrases, code in (
        (('出了点问题', '服务异常', '系统繁忙', '服务繁忙'), 'server_temporary_problem'),
        (('次数已用完', '额度不足', '达到上限'), 'quota_limit'),
        (('订阅标准套餐专属能力', '升级正式订阅'), 'subscription_required'),
        (('请上传图片', '请先上传', '没有收到图片'), 'reference_image_requested'),
        (('请确认', '确认后生成'), 'confirmation_requested'),
        (('需要验证', '完成验证'), 'verification_requested'),
        (('审核未通过', '无法通过审核'), 'review_rejected'),
    ):
        if any(phrase in text for phrase in phrases): found.append(code)
    if texts and not found: found.append('text_reply_present')
    return found

def image_variants(event):
    if str(event.get('event_type')) == '2005':
        detail = object_data(event.get('event_data'))
        raise api_error('豆包生成', '事件 2005，接口码 ' + response_code(detail), detail)
    if event.get('_sse_event') == 'STREAM_ERROR': raise api_error('豆包生成', '流错误，接口码 ' + response_code(event), event)
    messages, blocks = generation_parts(event)
    data = []
    for message in messages:
        if user_message(message): continue
        if str(message.get('content_type')) == '2010':
            items = object_data(message.get('content')).get('data', [])
            if isinstance(items, list): data.extend(items)
    for block in blocks:
        if str(block.get('block_type')) != '2074': continue
        for key in ('content', 'content_v2'):
            content = object_data(block.get(key))
            creation = object_data(content.get('creation_block')) or content
            items = creation.get('creations')
            if not isinstance(items, list): continue
            for item in items:
                if isinstance(item, dict) and isinstance(item.get('image'), dict): data.append(item['image'])
    output, seen = [], set()
    for index, item in enumerate(data):
        if not isinstance(item, dict): continue
        identity = str(item.get('key') or item.get('image_id') or ('index:' + str(index)))
        for key in ('image_ori_raw', 'image_ori', 'image_raw', 'image_preview', 'image_thumb'):
            url = object_data(item.get(key)).get('url')
            if not isinstance(url, str) or not url.startswith('https://'): continue
            path = urlsplit(url).path.lower()
            marked = any(tag in path for tag in ('lwm3', 'watermark'))
            if marked: rank, source = -1, 'server_watermarked'
            elif key == 'image_ori_raw' or re.search(r'-image_raw[.~/]', path): rank, source = 3, 'server_original'
            elif 'dwm3' in path: rank, source = 2, 'server_dwm3'
            else: rank, source = 0, 'server_unspecified'
            if (identity, url) not in seen:
                output.append({'identity': identity, 'url': url, 'rank': rank, 'source': source})
                seen.add((identity, url))
    return output

def image_urls(event):
    variants = image_variants(event)
    identities = list(dict.fromkeys(item['identity'] for item in variants))
    return [max((v for v in variants if v['identity'] == key), key=lambda v: v['rank'])['url'] for key in identities]

def sse_events(lines, check):
    parts, total, event_name = [], 0, ''
    def frame(raw, name):
        try: data = json.loads(raw)
        except ValueError as exc: raise UserError('豆包生成事件格式无法识别。') from exc
        if not isinstance(data, dict): raise UserError('豆包生成事件不是有效对象。')
        data['_sse_event'] = name if name in ('FULL_MSG_NOTIFY', 'STREAM_CHUNK', 'STREAM_MSG_NOTIFY', 'STREAM_ERROR', 'STREAM_END', 'SSE_ACK', 'CHUNK_DELTA', '') else 'other'
        return data
    for line in lines:
        check()
        total += len(line)
        if total > 12 * 1024 * 1024: raise UserError('豆包响应过大，已停止解析。')
        if not line.strip():
            if parts:
                raw, parts = '\n'.join(parts), []
                if raw.strip() == '[DONE]': return
                yield frame(raw, event_name)
            event_name = ''
        elif line.startswith('data:'): parts.append(line[5:].lstrip())
        elif line.startswith('event:'): event_name = line[6:].strip()
        elif not parts and line.lstrip().startswith('{'):
            data = object_data(line)
            raise api_error('豆包生成', '接口码 ' + response_code(data) + '，普通 JSON 响应', data)
    if parts and '\n'.join(parts).strip() != '[DONE]':
        yield frame('\n'.join(parts), event_name)

def no_image_error(notices):
    for code, message in (
        ('server_temporary_problem', '豆包返回“出了点问题”一类服务端暂时异常，本次没有生成图片。'),
        ('quota_limit', '豆包回复额度或次数限制，本次没有返回图片。'),
        ('subscription_required', '豆包回复需要订阅权限，本次没有返回图片。'),
        ('verification_requested', '豆包回复需要额外验证，本次没有返回图片。'),
        ('review_rejected', '豆包回复审核未通过，本次没有返回图片。'),
        ('reference_image_requested', '豆包回复需要上传参考图，附件可能未被本次编辑识别。'),
        ('confirmation_requested', '豆包只回复确认要求，没有直接生成图片。'),
        ('text_reply_present', '豆包本次只返回文本，未发现可识别的结果图片。'),
    ):
        if code in notices: return UserError(message + '未自动重试，可查看或导出日志。')
    return UserError('豆包没有返回可识别的结果图片；可能是响应格式变化或上游未出图。请导出日志，未自动重试。')

def conversation_reference(event):
    payload = object_data(event.get('event_data')) if 'event_data' in event else event
    values = [payload.get('conversation_id'), object_data(payload.get('message')).get('conversation_id'),
              object_data(payload.get('ack_client_meta')).get('conversation_id')]
    for value in values:
        if isinstance(value, str) and re.fullmatch(r'\d{10,32}', value): return value
    return ''

class DoubaoHTTP:
    def __init__(self, client, session, signer, deadline, job, prefer_original=True, progress=None, diagnostic=None):
        self.client, self.session, self.signer = client, session, signer
        self.deadline, self.job = deadline, job
        self.prefer_original, self.progress = prefer_original, progress
        self.result_source = ''
        self.initialized = False
        self.diagnostic = diagnostic
        self.headers = {'User-Agent': UA, 'Origin': ORIGIN, 'Referer': ORIGIN + '/chat/', 'agw-js-conv': 'str',
                        'x-tt-passport-csrf-token': session['cookies'].get('passport_csrf_token') or session['cookies'].get('passport_csrf_token_default', '')}
        for key, value in session['cookies'].items(): client.cookies.set(key, value, domain='www.doubao.com', path='/')
    def timeout(self): return remaining(self.deadline, self.job)
    def receive_session(self, response):
        # Local snapshots install host-only copies. A fresh parent-domain cookie
        # must replace those copies, otherwise duplicate old/new tokens are sent.
        for fresh in response.cookies.jar:
            if (fresh.name not in ('passport_csrf_token', 'passport_csrf_token_default', 'msToken') or
                    fresh.domain.lstrip('.') not in ('doubao.com', 'www.doubao.com')): continue
            for old in list(self.client.cookies.jar):
                if (old.name == fresh.name and old.domain.lstrip('.') in ('doubao.com', 'www.doubao.com') and
                        (old.domain, old.path) != (fresh.domain, fresh.path)):
                    self.client.cookies.jar.clear(old.domain, old.path, old.name)
    def current_headers(self):
        # The server can update these cookies during initialization or upload.
        # Do not keep sending the token captured before the first response.
        cookies = dict(self.session['cookies'])
        for cookie in self.client.cookies.jar:
            if cookie.domain.lstrip('.') in ('doubao.com', 'www.doubao.com'):
                cookies[cookie.name] = cookie.value
        token = cookies.get('passport_csrf_token') or cookies.get('passport_csrf_token_default', '')
        self.headers['x-tt-passport-csrf-token'] = token
        return dict(self.headers)
    def upload_context(self):
        self.current_headers()
        cookies = dict(self.session['cookies'])
        for cookie in self.client.cookies.jar:
            if cookie.domain.lstrip('.') in ('doubao.com', 'www.doubao.com'): cookies[cookie.name] = cookie.value
        return {'initialized': self.initialized,
                'csrf_source': 'primary' if cookies.get('passport_csrf_token') else 'default' if cookies.get('passport_csrf_token_default') else 'missing',
                'has_ms_token': bool(cookies.get('msToken') or self.session['params'].get('msToken'))}
    def initialize_upload(self):
        # HTTP GET only: receive the site's session cookies, no JS or browser.
        started = time.monotonic()
        with self.client.stream('GET', ORIGIN + '/chat/', headers=self.current_headers(),
                                timeout=min(15, self.timeout())) as response:
            self.receive_session(response)
            if self.diagnostic: self.diagnostic.http('initializing', response, (time.monotonic() - started) * 1000)
            self.timeout()
            if response.status_code in (401, 403):
                raise UserError('上传前会话初始化被拒绝（HTTP ' + str(response.status_code) + '）。未上传或生成，请检查账号连接或额外验证。')
            if response.status_code != 200:
                raise UserError('上传前会话初始化未完成（HTTP ' + str(response.status_code) + '）。未上传或生成，不跟随跳转或打开浏览器。')
        self.initialized = True
        self.current_headers()
    def signed(self, path, body=''):
        p = self.session['params']
        params = {'aid': '497858', 'real_aid': '497858', 'device_id': p['device_id'], 'device_platform': 'web',
                  'doubao_device_platform': 'web', 'web_platform': 'browser', 'fp': p['fp'], 'language': 'zh',
                  'pc_version': '3.36.0', 'doubao_pc_version': '3.36.0', 'pkg_type': 'release_version', 'region': 'CN',
                  'sys_region': 'CN', 'samantha_web': '1', 'tea_uuid': p['web_id'], 'tz_name': 'Asia/Shanghai',
                  'use-olympus-account': '1', 'version_code': '20800', 'web_id': p['web_id'], 'web_tab_id': str(uuid.uuid4())}
        token = p.get('msToken') or self.session['cookies'].get('msToken')
        for cookie in self.client.cookies.jar:
            if cookie.name == 'msToken' and cookie.domain.lstrip('.') in ('doubao.com', 'www.doubao.com'):
                token = cookie.value
        if token: params['msToken'] = token
        return self.signer({'url': ORIGIN + path + '?' + urlencode(params), 'body': body,
                            'signOptions': {'userAgent': UA, 'platform': 'Win32'}})['signed_url']
    def upload(self, path):
        from api_diagnostics import response_details
        from PIL import Image
        with Image.open(path) as image:
            if image.format != 'PNG': raise UserError('上传副本不是有效 PNG，未上传或生成。')
            width, height = image.size
            image.verify()
        if self.diagnostic:
            self.diagnostic.input_image({'width': width, 'height': height, 'bytes': path.stat().st_size,
                                          'count': 1, 'transport': 'multipart_png', 'png_verified': True})
        for attempt in (1, 2):
            self.timeout()
            started = time.monotonic()
            context = self.upload_context()
            with path.open('rb') as handle:
                response = self.client.post(self.signed('/samantha/pages/upload_image'), headers=self.current_headers(),
                                           files={'data': ('source.png', handle, 'image/png'), 'file_type': (None, 'png')}, timeout=self.timeout())
            self.receive_session(response)
            if self.diagnostic: self.diagnostic.http('uploading', response, (time.monotonic() - started) * 1000)
            try: detail = response.json()
            except ValueError: detail = {}
            code, category = response_code(detail), error_category(detail)
            # Only a definitive rejected upload with no classified cause gets
            # one retry of the identical file. Never retry transport uncertainty,
            # authorization, review, verification/risk, or any generation call.
            retry = response.status_code == 200 and code == '671020000' and not category and attempt == 1
            category_id = next((label for text, label in (('内容审核限制', 'content_review'), ('风控限制', 'risk_control'),
                ('要求额外验证', 'verification'), ('账号授权异常', 'authentication'), ('额度或次数限制', 'quota_limit'),
                ('参数或附件无效', 'invalid_attachment')) if text in category), 'unclassified')
            if self.diagnostic:
                trace = response_details(response, {}, tuple(self.session['cookies'].values())).get('request_id')
                self.diagnostic.web_upload({**context, 'attempt': attempt, 'http_status': response.status_code,
                    'code': code, 'category': category_id, 'will_retry': retry, 'request_id': trace})
            self.timeout()
            if retry:
                if self.progress: self.progress('上传接口拒绝了首次请求；正在同步会话并仅重传原文件一次，尚未提交生成……')
                for _ in range(5):
                    self.timeout()
                    time.sleep(min(0.2, self.timeout()))
                continue
            try: uri = json_data(response, '图片上传').get('uri')
            except UserError as exc:
                if attempt == 2: exc.args = (str(exc) + '已使用同一原文件自动重传一次，仍被拒绝，不再自动重传。',)
                raise
            if not isinstance(uri, str) or not uri.strip(): raise UserError('上传未返回有效 URI，未提交生成请求。')
            return uri
    def resolve_attachment(self, upload_uri):
        # upload_image returns a short ID, not the attachment key required by
        # image editing. Resolve it exactly once before sending any generation.
        payload = {'uris': [upload_uri], 'type': 'image', 'format': 'png', 'expire_second': 3600}
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        started = time.monotonic()
        response = self.client.post(self.signed('/alice/message/get_file_url', body),
                                    headers={**self.current_headers(), 'Content-Type': 'application/json'},
                                    content=body.encode('utf-8'), timeout=self.timeout())
        self.receive_session(response)
        if self.diagnostic: self.diagnostic.http('resolving', response, (time.monotonic() - started) * 1000)
        files = json_data(response, '附件解析').get('file_urls')
        info = files[0] if isinstance(files, list) and files and isinstance(files[0], dict) else {}
        uri = info.get('uri')
        if not isinstance(uri, str) or not uri.strip() or uri.lower().startswith(('http:', 'https:')):
            raise UserError('附件解析未返回有效图片附件标识，未提交生成请求。')
        return uri
    def read_history(self, conversation_id):
        # Read only the exact conversation acknowledged by this generation.
        # Never discover another conversation by title/time or repeat completion.
        payload = {'request_list': [{'conversation_id': conversation_id, 'message_index': 0, 'count': 20}]}
        body = json.dumps(payload, separators=(',', ':'))
        started = time.monotonic()
        response = self.client.post(self.signed('/alice/conversation/latest_messagelist', body),
            headers={**self.current_headers(), 'Content-Type': 'application/json'}, content=body.encode(), timeout=self.timeout())
        self.receive_session(response)
        if self.diagnostic: self.diagnostic.http('history', response, (time.monotonic() - started) * 1000)
        data = json_data(response, '读取既有会话结果')
        message_map = data.get('message_map', {})
        if not isinstance(message_map, dict): return []
        messages = []
        for values in message_map.values():
            if isinstance(values, list):
                for message in values:
                    if isinstance(message, dict) and message.get('conversation_id') == conversation_id:
                        messages.append(message)
        return messages
    def generate_many(self, uris, prompt, expected):
        """One multi-attachment completion; identities are outputs, not source IDs."""
        if not uris or len(uris) != expected or len(set(uris)) != expected:
            raise UserError('合并附件数量或标识异常，未提交生成。')
        instruction = ('本次上传了 ' + str(expected) + ' 张独立原图。请分别编辑每张附件，' +
            '按附件顺序分别输出 ' + str(expected) + ' 张完整去字图片，每张只对应一张原图。' +
            '不要拼接成一张图，不要混合不同附件，不要遗漏，不要新增序号或文字。' +
            '仅去除文字并自然修补覆盖区域，保持每张原图其余内容、构图、颜色。具体要求：' + prompt)
        payload = {'messages': [{'content': json.dumps({'text': instruction}, ensure_ascii=False), 'content_type': 2009,
            'attachments': [{'type': 'image', 'key': uri, 'extra': {'refer_types': 'overall'}} for uri in uris],
            'references': [], 'skill': {'skill_type': 3, 'skill_type_no_default': 3, 'skill_id': '3', 'skill_id_no_default': '3'}}],
            'completion_option': {'is_regen': False, 'with_suggest': True, 'need_create_conversation': True,
            'launch_stage': 1, 'is_replace': False, 'is_delete': False, 'is_ai_playground': False,
            'memory_type': 0, 'message_from': 0, 'use_deep_think': False, 'use_auto_cot': False,
            'resend_for_regen': False, 'enable_commerce_credit': False, 'action_bar_skill_id': 3},
            'evaluate_option': {'web_ab_params': ''}, 'local_conversation_id': str(uuid.uuid4()), 'local_message_id': str(uuid.uuid4())}
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        candidates, notices, conversation_id = {}, set(), ''
        def collect(event):
            messages, blocks = generation_parts(event)
            notices.update(server_notices(messages, blocks))
            variants = image_variants(event)
            if self.diagnostic:
                self.diagnostic.observe(response_code({'code': event.get('event_type')}), event.get('_sse_event', ''),
                    [response_code({'code': m.get('content_type')}) for m in messages],
                    [response_code({'code': b.get('block_type')}) for b in blocks], notices, len(variants))
            for value in variants:
                previous = candidates.get(value['identity'])
                if previous is None or previous['rank'] < value['rank']: candidates[value['identity']] = value
            if len(candidates) > 500: raise UserError('合并结果超过 500 张，已停止解析。')
        started, last_progress = time.monotonic(), 0.0
        with self.client.stream('POST', self.signed('/samantha/chat/completion', body), content=body.encode('utf-8'),
            headers={**self.current_headers(), 'Content-Type': 'application/json', 'Accept': 'text/event-stream'}, timeout=self.timeout()) as response:
            if self.diagnostic: self.diagnostic.http('generating', response, (time.monotonic() - started) * 1000)
            check_response(response, '合并生成')
            for event in sse_events(response.iter_lines(), self.timeout):
                reference = conversation_reference(event)
                if reference and not conversation_id:
                    conversation_id = reference
                    atomic_json(self.job / 'conversation_ref.json', {'conversation_id': reference})
                collect(event)
                if self.progress and time.monotonic() - last_progress >= 10:
                    self.progress('合并生成中，已识别 ' + str(len(candidates)) + ' 张结果；正在等待全部响应……')
                    last_progress = time.monotonic()
        if self.diagnostic: self.diagnostic.stream_end()
        # A newly-created conversation contains only this completion; history reads
        # cannot pick a previous layer's turn. Never submit completion twice.
        if conversation_id and (len(candidates) < expected or any(v['rank'] < 2 for v in candidates.values())) and not (
                notices & {'server_temporary_problem', 'quota_limit', 'subscription_required', 'verification_requested', 'review_rejected'}):
            for _ in range(3):
                self.timeout()
                try: messages = self.read_history(conversation_id)
                except UserError: break
                for message in messages: collect({'message': message, '_sse_event': 'history'})
                if len(candidates) >= expected and all(v['rank'] >= 2 for v in candidates.values()): break
        self.timeout()
        if not candidates: raise no_image_error(notices)
        # Do not pretend output order establishes a source correspondence.
        return list(candidates.values())
    def generate(self, uri, prompt, ratio):
        payload = {'messages': [{'content': json.dumps({'text': prompt, 'ratio': ratio}, ensure_ascii=False), 'content_type': 2009,
                   'attachments': [{'type': 'image', 'key': uri, 'extra': {'refer_types': 'overall'}}], 'references': [],
                   'skill': {'skill_type': 3, 'skill_type_no_default': 3, 'skill_id': '3', 'skill_id_no_default': '3'}}],
                   'completion_option': {'is_regen': False, 'with_suggest': True, 'need_create_conversation': True,
                   'launch_stage': 1, 'is_replace': False, 'is_delete': False, 'is_ai_playground': False,
                   'memory_type': 0 if self.prefer_original else 2,
                   'message_from': 0, 'use_deep_think': False, 'use_auto_cot': False, 'resend_for_regen': False,
                   'enable_commerce_credit': False, 'action_bar_skill_id': 3}, 'evaluate_option': {'web_ab_params': ''},
                   'local_conversation_id': str(uuid.uuid4()), 'local_message_id': str(uuid.uuid4())}
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        headers = {**self.current_headers(), 'Content-Type': 'application/json', 'Accept': 'text/event-stream'}
        candidates, first_identity, last_progress, notices, conversation_id = [], None, 0.0, set(), ''
        started = time.monotonic()
        # Exactly one generation POST. Never retry an uncertain response.
        with self.client.stream('POST', self.signed('/samantha/chat/completion', body), content=body.encode('utf-8'),
                                headers=headers, timeout=self.timeout()) as response:
            if self.diagnostic: self.diagnostic.http('generating', response, (time.monotonic() - started) * 1000)
            check_response(response, '豆包生成')
            for event in sse_events(response.iter_lines(), self.timeout):
                if isinstance(event, dict):
                    reference = conversation_reference(event)
                    if reference and not conversation_id:
                        conversation_id = reference
                        # Private local recovery hint. Explicitly excluded from log exports.
                        atomic_json(self.job / 'conversation_ref.json', {'conversation_id': reference})
                    messages, blocks = generation_parts(event)
                    notices.update(server_notices(messages, blocks))
                    if self.diagnostic:
                        self.diagnostic.observe(response_code({'code': event.get('event_type')}), event.get('_sse_event', ''),
                            [response_code({'code': m.get('content_type')}) for m in messages],
                            [response_code({'code': b.get('block_type')}) for b in blocks], notices, 0)
                    variants = image_variants(event)
                    if self.diagnostic: self.diagnostic.data['stream']['image_variants'] += len(variants)
                    if variants and first_identity is None: first_identity = variants[0]['identity']
                    candidates.extend(v for v in variants if v['identity'] == first_identity)
                    # Only fixed local text is exposed; never echo raw events/prompts.
                    if self.progress and time.monotonic() - last_progress >= 10:
                        self.progress('豆包仍在处理，本地已收到响应；正在等待完整结果……')
                        last_progress = time.monotonic()
        self.timeout()
        if self.diagnostic: self.diagnostic.stream_end()
        if self.prefer_original and conversation_id and (not candidates or max(v['rank'] for v in candidates) < 2) and not (
                notices & {'server_temporary_problem', 'quota_limit', 'subscription_required', 'verification_requested', 'review_rejected'}):
            if self.progress: self.progress('响应流已结束，正在只读核对本次会话已有的图片结果；不会重复生成……')
            # Bounded reads cover late history cards, without creating another generation.
            for attempt in range(3):
                try: messages = self.read_history(conversation_id)
                except UserError:
                    if self.diagnostic: self.diagnostic.emit('history_read_failed')
                    break
                for message in messages:
                    event = {'message': message}
                    msgs, blocks = generation_parts(event)
                    notices.update(server_notices(msgs, blocks))
                    variants = image_variants(event)
                    if self.diagnostic:
                        self.diagnostic.observe(None, 'history', [response_code({'code': message.get('content_type')})],
                            [response_code({'code': b.get('block_type')}) for b in blocks], notices, len(variants))
                    if variants and first_identity is None: first_identity = variants[0]['identity']
                    candidates.extend(v for v in variants if v['identity'] == first_identity)
                if candidates and max(v['rank'] for v in candidates) >= 2: break
                if notices & {'server_temporary_problem', 'quota_limit', 'subscription_required', 'verification_requested', 'review_rejected'}: break
                if attempt < 2:
                    self.timeout()
                    time.sleep(min(3, self.timeout()))
            if self.diagnostic: self.diagnostic.flush()
        if not candidates: raise no_image_error(notices)
        chosen = max(candidates, key=lambda v: v['rank'])
        if self.prefer_original and chosen['rank'] < 2:
            raise UserError('豆包本次未提供可识别的无水印原图地址；结果未导入，也未重复生成。请保留日志。')
        self.result_source = chosen['source']
        if self.diagnostic:
            self.diagnostic.data['result_source'] = self.result_source
            self.diagnostic.emit('result_selected', source=self.result_source, rank=chosen['rank'])
            self.diagnostic.flush()
        return chosen['url']

def download_image(client, url, path, check, diagnostic=None):
    parts = urlsplit(url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password: raise UserError('结果地址无效。')
    started = time.monotonic()
    with client.stream('GET', url, timeout=check()) as response:
        if diagnostic: diagnostic.http('downloading', response, (time.monotonic() - started) * 1000)
        check_response(response, '结果下载')
        size = 0
        with path.open('wb') as handle:
            for chunk in response.iter_bytes():
                check()
                size += len(chunk)
                if size > MAX_BYTES: raise UserError('结果图片超过 50 MB。')
                handle.write(chunk)

def restore_image(source_path, downloaded, output_path, width, height):
    from PIL import Image, ImageOps
    with Image.open(source_path) as source:
        if source.size != (width, height): raise UserError('导出尺寸与任务记录不一致。')
        alpha, profile = source.convert('RGBA').getchannel('A'), source.info.get('icc_profile')
    bbox = alpha.getbbox()
    if bbox is None: raise UserError('所选图层完全透明。')
    try:
        with Image.open(downloaded) as generated:
            generated = ImageOps.exif_transpose(generated)
            original_size = generated.size
            result = generated.convert('RGB').resize((width, height), Image.Resampling.LANCZOS)
    except (OSError, ValueError, Image.DecompressionBombError) as exc: raise UserError('下载内容不是有效图片。') from exc
    result.putalpha(alpha)
    result.save(output_path, icc_profile=profile)
    preview = Image.new('RGB', result.size, 'white')
    preview.paste(result, mask=alpha)
    preview.thumbnail((360, 240))
    preview.save(output_path.with_name('preview.png'))
    return {'width': width, 'height': height, 'alpha_bounds': list(bbox), 'generated_size': list(original_size)}

def process_job(job):
    import httpx
    from PIL import Image
    log_path = job / 'worker.log'
    stage, attachment_resolved, backend = 'starting', False, 'web'
    reference_status = None
    diagnostic = Diagnostics(job, WORKER_VERSION, atomic_json)
    def status(state, message, **extra):
        atomic_json(job / 'status.json', {'state': state, 'message': message, 'log_path': str(log_path),
                    'worker_version': WORKER_VERSION, 'stage': stage, 'attachment_resolved': attachment_resolved, 'backend': backend,
                    'updated_at': int(time.time()), **extra})
        with log_path.open('a', encoding='utf-8') as log:
            # Never log cookies, signed URLs, raw responses or request exception traces.
            log.write(time.strftime('%Y-%m-%d %H:%M:%S ') + state + ' ' + message + '\n')
        diagnostic.state(state, stage, message)
    try:
        config = read_json(ROOT / 'config.json')
        timeout = float(config.get('timeout_seconds', 600))
        if not math.isfinite(timeout) or timeout <= 0: raise UserError('处理超时必须为正数。')
        deadline = time.monotonic() + timeout
        request = read_json(job / 'request.json')
        width, height = int(request['width']), int(request['height'])
        if width <= 0 or height <= 0 or width * height > 100_000_000: raise UserError('图片为空或超过一亿像素，请缩小图层。')
        prefer_original = request.get('prefer_watermark_free', config.get('prefer_watermark_free', True))
        if not isinstance(prefer_original, bool): raise UserError('无水印设置必须为 true 或 false。')
        diagnostic.options(width=width, height=height, document_id=request.get('document_id'),
            source_layer_id=request.get('source_layer_id'), prefer_watermark_free=prefer_original,
            memory_type=0 if prefer_original else 2)
        backend = request.get('backend', 'web')
        if backend not in ('web', 'api'): raise UserError('未知的生成方式，请重新选择。')
        diagnostic.data['backend'] = backend
        status('starting', '正在读取本批次固定的生成配置……')
        remaining(deadline, job)
        profile = None
        if request.get('credential_ref'):
            from generation_profiles import load_snapshot
            profile = load_snapshot(sys.modules[__name__], request)
        elif backend == 'api' or request.get('profile_id'):
            raise UserError('任务缺少固定的生成凭据，请重新提交。')
        if backend == 'web':
            session, signer = profile or load_session(request.get('session_file')), load_signer()
        source_path, upload_path = job / 'source.png', job / 'upload.png'
        with Image.open(source_path) as source:
            if source.size != (width, height): raise UserError('导出尺寸与任务记录不一致。')
            rgba = source.convert('RGBA')
        if not rgba.getchannel('A').getbbox(): raise UserError('所选图层完全透明。')
        preview = Image.new('RGB', rgba.size, 'white')
        preview.paste(rgba, mask=rgba.getchannel('A'))
        preview.save(upload_path)
        if upload_path.stat().st_size > MAX_BYTES: raise UserError('上传图片超过 50 MB，请缩小图层。')
        prompt = str(request.get('prompt') or config.get('prompt') or DEFAULT_PROMPT)
        generated_bytes = None
        with httpx.Client(trust_env=False, follow_redirects=False) as client:
            if backend == 'api':
                from image_api import generate
                stage = 'generating'
                status('generating', '正在通过所选 API 生成去字图片；每层仅提交一次，按 API 服务计费。')
                result = generate(client, profile, upload_path, prompt, lambda: remaining(deadline, job), diagnostic, UserError)
                result_source = result['source']
                reference_status = result['reference_status']
                url, generated_bytes = result.get('url'), result.get('bytes')
                from result_transfer import save
                save(job, request, result)
            else:
                api = DoubaoHTTP(client, session, signer, deadline, job, prefer_original,
                                 lambda message: status('generating' if stage == 'generating' else 'uploading', message), diagnostic)
                stage = 'initializing'
                status('uploading', '正在通过 HTTP 初始化上传会话并同步安全凭据；不会打开浏览器……')
                api.initialize_upload()
                stage = 'uploading'
                status('uploading', '正在通过 HTTP 上传所选图层……')
                upload_uri = api.upload(upload_path)
                stage = 'resolving'
                status('resolving', '图片已上传，正在解析图片编辑所需的附件标识……')
                uri = api.resolve_attachment(upload_uri)
                attachment_resolved = True
                ratio = min(('1:1', '16:9', '9:16', '4:3', '3:4'), key=lambda s: abs(math.log(width / height / (int(s.split(':')[0]) / int(s.split(':')[1])))))
                stage = 'generating'
                status('generating', '附件解析完成，正在请求豆包生成；进度自动记录，批次结束会提示。')
                url = api.generate(uri, prompt, ratio)
                result_source = api.result_source
                from result_transfer import save
                save(job, request, {'url': url, 'source': result_source})
        stage = 'downloading'
        status('downloading', '已返回结果，正在下载并恢复尺寸与原透明通道……')
        downloaded = job / 'generated.download'
        # Separate credential-free client for CDN downloads.
        if generated_bytes is not None: downloaded.write_bytes(generated_bytes)
        else:
            with httpx.Client(trust_env=False, follow_redirects=True) as client:
                from result_transfer import download
                download(client, url, downloaded, lambda: remaining(deadline, job), diagnostic,
                         lambda message: status('downloading', message))
        stage = 'restoring'
        status('restoring', '下载完成，正在恢复原图层尺寸与透明度……')
        metadata = restore_image(source_path, downloaded, job / 'result.png', width, height)
        remaining(deadline, job)
        downloaded.unlink(missing_ok=True)
        upload_path.unlink(missing_ok=True)
        done_message = '生成完成，可预览并导入对齐图层。'
        if backend == 'api':
            done_message += ('接口确认接收 1 张参考图；' if reference_status == 'confirmed' else
                             '图片已随请求发送，但接口未回报参考图接收数量；')
            done_message += '请先预览内容，模型仍可能重绘。'
        status('done', done_message, result_source=result_source, reference_status=reference_status,
               saved_to_history=backend == 'web' and prefer_original, backend=backend, **metadata)
    except Cancelled as exc:
        diagnostic.exception(exc)
        status('cancelled', str(exc))
    except Exception as exc:
        diagnostic.exception(exc)
        if isinstance(exc, UserError): message = str(exc)
        elif isinstance(exc, httpx.TimeoutException): message = 'HTTP 请求超时；未重复提交，豆包已开始的生成可能继续。'
        elif isinstance(exc, httpx.RequestError): message = 'HTTP 连接失败，请检查网络；未启动浏览器或重复提交。'
        else: message = '本地处理失败（' + type(exc).__name__ + '），请检查安装或账号 JSON 格式。'
        if stage == 'downloading' and (job / 'remote-result.json').exists():
            message = '生成已成功，但结果图片下载未完成。可点击“找回 / 下载所选结果”继续取回；不会重新生成。'
        status('error', message, generation_succeeded=(job / 'remote-result.json').exists(),
               download_recoverable=(job / 'remote-result.json').exists())

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--prepare-api', action='store_true')
    parser.add_argument('--start', action='store_true')
    parser.add_argument('--admin', action='store_true')
    args = parser.parse_args()
    if args.job:
        job = args.job.resolve()
        if job.parent != (RUNTIME / 'jobs').resolve() or not job.is_dir(): raise UserError('任务目录无效。')
        try:
            with (job / 'submitted.lock').open('x', encoding='ascii') as lock: lock.write(str(os.getpid()))
        except FileExistsError: return 0
        if read_json(job / 'request.json').get('kind') in ('login', 'check'):
            from account_worker import process_account
            process_account(job, sys.modules[__name__])
        else:
            process_job(job)
    elif args.prepare_api:
        import httpx
        from PIL import Image
        import ark_api, image_api, generation_profiles, result_transfer, result_recovery
        print('API components ready. Add an API profile inside Photoshop; no generation was requested.')
    elif args.prepare:
        load_signer()
        try:
            load_session()
            print('HTTP components ready. Saved account found; validity is not yet verified.')
        except UserError as exc: print(str(exc))
    else: print('No browser service is used. Open Doubao_RemoveText.jsx in Photoshop.')
    return 0

if __name__ == '__main__':
    try: raise SystemExit(main())
    except Exception as exc:
        if '--job' in sys.argv:
            try:
                task = Path(sys.argv[sys.argv.index('--job') + 1]).resolve()
                if task.parent == (RUNTIME / 'jobs').resolve():
                    atomic_json(task / 'status.json', {'state': 'error', 'message': '后台程序启动失败（' + type(exc).__name__ + '）。请运行 install.cmd。'})
            except Exception: pass
        if sys.stderr: print('Helper failed: ' + type(exc).__name__, file=sys.stderr)
        raise SystemExit(1)
