"""Validate current attempts and immutable carried results in retry batches."""
from pathlib import Path
import re
import bridge_worker as worker

def safe_name(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9]+-[0-9]+', value) is not None

def validate_item(runtime, batch_name, manifest, item, require_files=False):
    runtime = Path(runtime)
    if not isinstance(item, dict) or not safe_name(item.get('job_name')):
        raise worker.UserError('批次包含无效任务目录。')
    job = (runtime / 'jobs' / item['job_name']).resolve()
    if job.parent != (runtime / 'jobs').resolve(): raise worker.UserError('任务目录越界。')
    request = worker.read_json(job / 'request.json')
    if request.get('document_id') != manifest.get('document_id') or request.get('source_layer_id') != item.get('source_layer_id'):
        raise worker.UserError('任务与原图层的对应关系不一致，已停止。')
    for key in ('width', 'height', 'left', 'top', 'raw_bounds'):
        if key in item and item[key] != request.get(key): raise worker.UserError('任务的像素边界记录不一致。')
    if item.get('carried') is True:
        source = item.get('carried_from_batch')
        if not safe_name(source) or source == batch_name or request.get('batch_name') != source:
            raise worker.UserError('沿用任务的来源批次无效。')
        source_path = (runtime / 'batches' / source).resolve()
        if source_path.parent != (runtime / 'batches').resolve(): raise worker.UserError('来源批次目录越界。')
        original = worker.read_json(source_path / 'request.json')
        if original.get('document_id') != manifest.get('document_id') or not any(
            isinstance(old, dict) and old.get('job_name') == job.name and old.get('source_layer_id') == item['source_layer_id']
            for old in original.get('items', [])):
            raise worker.UserError('沿用任务不属于所记录的来源批次。')
        state = 'done' if (job / 'imported.flag').exists() else worker.read_json(job / 'status.json').get('state')
        if state not in ('done', 'error', 'cancelled'): raise worker.UserError('不能沿用尚未结束的任务。')
        if require_files and state == 'done' and not (job / 'result.png').is_file():
            raise worker.UserError('沿用的成功结果文件缺失，未提交重试。')
    elif request.get('batch_name') != batch_name:
        raise worker.UserError('任务与批次记录不一致，已停止。')
    if require_files and not (job / 'source.png').is_file(): raise worker.UserError('批次导出图片缺失，已停止。')
    return job, request
