"""One web completion for all attachments, followed by explicit local mapping.

Output identities identify generated images, never the original attachments.
The user reviews each unique assignment before any image becomes importable.
"""
from pathlib import Path
import argparse
import math
import os
import sys
import time

import bridge_worker as worker
from batch_records import validate_item


def set_status(job, state, message, diagnostic=None, **fields):
    worker.atomic_json(job / 'status.json', {'state': state, 'stage': state, 'backend': 'web',
        'message': message, 'worker_version': worker.WORKER_VERSION, 'updated_at': int(time.time()), **fields})
    with (job / 'worker.log').open('a', encoding='utf-8') as file:
        file.write(time.strftime('%Y-%m-%d %H:%M:%S ') + state + ' ' + message + '\n')
    if diagnostic: diagnostic.state(state, state, message)


def thumbnail(path, output):
    from PIL import Image, ImageOps
    with Image.open(path) as image:
        image = ImageOps.exif_transpose(image).convert('RGBA')
        if image.width * image.height > 100_000_000: raise worker.UserError('合并图片超过像素上限。')
        canvas = Image.new('RGB', image.size, 'white')
        canvas.paste(image, mask=image.getchannel('A'))
        canvas.thumbnail((280, 200))
        canvas.save(output, format='PNG')


def process(batch, manifest, snapshot):
    import httpx
    from PIL import Image
    pending = [item for item in manifest['items'] if item.get('carried') is not True]
    jobs, diagnostics = [], {}
    def all_status(state, message):
        for job in jobs: set_status(job, state, message, diagnostics.get(job.name))
        snapshot()
    try:
        config = worker.read_json(worker.ROOT / 'config.json')
        timeout = float(config.get('timeout_seconds', 600))
        if not math.isfinite(timeout) or timeout <= 0: raise worker.UserError('处理超时必须为正数。')
        deadline = time.monotonic() + timeout
        def check():
            if (batch / 'cancel.flag').exists(): raise worker.Cancelled('合并批次已取消；上游已开始的生成可能继续。')
            for job in jobs:
                if (job / 'cancel.flag').exists(): raise worker.Cancelled('合并批次已取消。')
            return worker.remaining(deadline, batch)
        requests = []
        # Preflight the entire set before uploads or a generation POST.
        for item in pending:
            job, request = validate_item(worker.RUNTIME, batch.name, manifest, item, require_files=True)
            if request.get('backend') != 'web' or request.get('web_upload_mode') != 'merged':
                raise worker.UserError('合并批次与图层上传模式不一致，未提交。')
            if (job / 'submitted.lock').exists(): raise worker.UserError('合并批次已有图层提交记录，未重新生成。')
            jobs.append(job)
            requests.append(request)
        if not jobs: raise worker.UserError('合并批次没有新图层。')
        first = requests[0]
        if any(r.get('profile_id') != first.get('profile_id') or r.get('credential_ref') != first.get('credential_ref') or
               r.get('prompt') != first.get('prompt') or r.get('prefer_watermark_free') != first.get('prefer_watermark_free') for r in requests):
            raise worker.UserError('合并批次的账号、提示词或图片设置不一致，未提交。')
        from generation_profiles import load_snapshot
        session = load_snapshot(worker, first)
        for job in jobs:
            with (job / 'submitted.lock').open('x', encoding='ascii') as file: file.write(str(os.getpid()))
            diagnostics[job.name] = worker.Diagnostics(job, worker.WORKER_VERSION, worker.atomic_json)
        all_status('uploading', '合并模式：正在集中上传全部附件，尚未提交生成……')
        uploads = []
        for index, (job, request) in enumerate(zip(jobs, requests)):
            width, height = int(request['width']), int(request['height'])
            if width <= 0 or height <= 0 or width * height > 100_000_000: raise worker.UserError('合并原图尺寸无效。')
            with Image.open(job / 'source.png') as image:
                if image.size != (width, height): raise worker.UserError('合并原图与记录尺寸不一致。')
                rgba = image.convert('RGBA')
            if not rgba.getchannel('A').getbbox(): raise worker.UserError('合并原图包含全透明图层。')
            image = Image.new('RGB', rgba.size, 'white')
            image.paste(rgba, mask=rgba.getchannel('A'))
            image.save(job / 'upload.png')
            thumbnail(job / 'source.png', job / 'source-preview.png')
            uploads.append(job / 'upload.png')
            diagnostics[job.name].options(width=width, height=height, document_id=request.get('document_id'),
                source_layer_id=request.get('source_layer_id'), prefer_watermark_free=first.get('prefer_watermark_free', True), memory_type=0)
        with httpx.Client(trust_env=False, follow_redirects=False) as client:
            api = worker.DoubaoHTTP(client, session, worker.load_signer(), deadline, jobs[0],
                first.get('prefer_watermark_free', True), lambda message: all_status('generating', message), diagnostics[jobs[0].name])
            api.timeout = check
            api.initialize_upload()
            uris = []
            for index, path in enumerate(uploads):
                check()
                api.job, api.diagnostic = jobs[index], diagnostics[jobs[index].name]
                all_status('uploading', '合并模式：正在上传附件 ' + str(index + 1) + ' / ' + str(len(jobs)) + '……')
                uris.append(api.resolve_attachment(api.upload(path)))
            api.job, api.diagnostic = jobs[0], diagnostics[jobs[0].name]
            all_status('generating', '全部附件已解析：一次提交，要求分别返回全部去字图片；不会重复生成。')
            candidates = api.generate_many(uris, str(first.get('prompt') or config.get('prompt') or worker.DEFAULT_PROMPT), len(jobs))
        all_status('downloading', '生成响应已结束，正在统一下载全部结果，之后核对原图对应……')
        folder = batch / 'merged-results'
        folder.mkdir(exist_ok=True)
        available, failed = [], 0
        with httpx.Client(trust_env=False, follow_redirects=True) as client:
            for index, candidate in enumerate(candidates):
                check()
                if first.get('prefer_watermark_free', True) and candidate['rank'] < 2:
                    failed += 1
                    continue
                name = str(index + 1)
                target = folder / (name + '.png')
                try:
                    from result_transfer import download
                    download(client, candidate['url'], folder / (name + '.download'), check, diagnostics[jobs[0].name])
                    with Image.open(folder / (name + '.download')) as image:
                        from PIL import ImageOps
                        image = ImageOps.exif_transpose(image)
                        if image.width * image.height > 100_000_000: raise worker.UserError('结果图片超过像素上限。')
                        image.convert('RGB').save(target, format='PNG')
                        dims = list(image.size)
                    thumbnail(target, folder / (name + '-preview.png'))
                    available.append({'id': name, 'width': dims[0], 'height': dims[1], 'source': candidate['source']})
                except worker.Cancelled: raise
                except (worker.UserError, httpx.RequestError, OSError, ValueError):
                    failed += 1
                    target.unlink(missing_ok=True)
                finally: (folder / (name + '.download')).unlink(missing_ok=True)
        if not available: raise worker.UserError('合并生成没有可下载的有效原图；未导入，未重复生成。')
        # Never assign by array position: multi-image APIs can omit, duplicate,
        # reorder or combine sources. Keep candidates separate until confirmed.
        worker.atomic_json(batch / 'merged-map.json', {'schema': 1, 'batch_name': batch.name,
            'items': [{'job_name': job.name, 'source_layer_id': r['source_layer_id']} for job, r in zip(jobs, requests)],
            'candidates': available, 'returned_count': len(candidates), 'failed_downloads': failed})
        message = ('合并已返回 ' + str(len(available)) + ' 张可用结果，原图 ' + str(len(jobs)) +
            ' 层。请点击“核对合并结果”逐层确认图片；缺失项可留空后重试。')
        if failed: message += '有 ' + str(failed) + ' 张下载失败或没有可识别原图地址，未导入。'
        all_status('mapping', message)
    except Exception as exc:
        if isinstance(exc, worker.Cancelled): state, message = 'cancelled', str(exc)
        elif isinstance(exc, worker.UserError): state, message = 'error', str(exc)
        elif isinstance(exc, httpx.TimeoutException): state, message = 'error', '合并请求超时；未重复提交，上游生成可能继续。'
        elif isinstance(exc, httpx.RequestError): state, message = 'error', '合并 HTTP 连接失败；未重复提交。'
        else: state, message = 'error', '合并本地处理异常（' + type(exc).__name__ + '），请导出日志。'
        # Include every new item even if preflight stopped halfway.
        for item in pending:
            job = worker.RUNTIME / 'jobs' / item['job_name']
            if (job / 'imported.flag').exists(): continue
            if (job / 'submitted.lock').exists() and (job / 'status.json').exists() and worker.read_json(job / 'status.json').get('state') in ('done', 'error', 'cancelled', 'mapping'):
                continue
            diagnostic = diagnostics.get(job.name)
            if diagnostic: diagnostic.exception(exc)
            set_status(job, state, message, diagnostic)
        snapshot()
    finally:
        for job in jobs: (job / 'upload.png').unlink(missing_ok=True)


def finalize(task, notify=True):
    """Prepare results from locally downloaded files; never contact an upstream."""
    from batch_worker import load_manifest
    from batch_records import safe_name
    request = worker.read_json(task / 'request.json')
    if request.get('kind') != 'merged_finalize' or not safe_name(request.get('batch_name')):
        raise worker.UserError('合并结果核对请求无效。')
    batch = worker.RUNTIME / 'batches' / request['batch_name']
    manifest = load_manifest(batch)
    mapping = worker.read_json(batch / 'merged-map.json')
    if mapping.get('schema') != 1 or mapping.get('batch_name') != batch.name:
        raise worker.UserError('合并结果记录无效。')
    expected = [{'job_name': x['job_name'], 'source_layer_id': x['source_layer_id']} for x in manifest['items'] if x.get('carried') is not True]
    if mapping.get('items') != expected: raise worker.UserError('核对记录与原图层不一致，未处理。')
    selections = request.get('selections')
    if not isinstance(selections, list) or len(selections) != len(expected): raise worker.UserError('核对列表长度无效。')
    candidates = {x['id']: x for x in mapping['candidates']}
    used = set()
    prepared = []
    for item, choice in zip(expected, selections):
        job = worker.RUNTIME / 'jobs' / item['job_name']
        if not isinstance(choice, dict) or choice.get('job_name') != job.name or choice.get('source_layer_id') != item['source_layer_id']:
            raise worker.UserError('核对时图层编号发生变化，未处理。')
        state = worker.read_json(job / 'status.json').get('state')
        if (job / 'imported.flag').exists() or state != 'mapping': raise worker.UserError('结果已核对或导入，不能再次覆盖。')
        cid = choice.get('candidate_id')
        if cid is not None:
            if not isinstance(cid, str) or not cid.isdigit() or cid not in candidates or cid in used:
                raise worker.UserError('同一结果不能分配给多个图层，或结果编号无效。')
            if not (batch / 'merged-results' / (cid + '.png')).is_file(): raise worker.UserError('合并结果文件缺失，未处理。')
            used.add(cid)
        prepared.append((job, cid))
    # Atomic local lock ensures simultaneous review windows cannot rewrite results.
    try:
        with (batch / 'mapping.lock').open('x', encoding='ascii') as file: file.write(str(os.getpid()))
    except FileExistsError: raise worker.UserError('此合并批次已经核对或正在处理，不会重复执行。')
    for job, cid in prepared:
        if cid is None:
            set_status(job, 'error', '合并结果缺失或未分配；可针对该原图层重新生成。')
            continue
        try:
            r = worker.read_json(job / 'request.json')
            metadata = worker.restore_image(job / 'source.png', batch / 'merged-results' / (cid + '.png'),
                                            job / 'result.png', int(r['width']), int(r['height']))
            set_status(job, 'done', '合并结果对应已确认，可预览并导入原图层上方。',
                result_source=candidates[cid]['source'], saved_to_history=True, mapping_confirmed=True,
                candidate_id=cid, **metadata)
        except Exception as exc:
            (job / 'result.png').unlink(missing_ok=True)
            set_status(job, 'error', str(exc) if isinstance(exc, worker.UserError) else '本地恢复合并结果失败（' + type(exc).__name__ + '）。')
    worker.atomic_json(batch / 'mapping-confirmed.json', {'selections': selections, 'auto_import': request.get('auto_import') is True})
    rows = []
    for item in manifest['items']:
        job = worker.RUNTIME / 'jobs' / item['job_name']
        info = worker.read_json(job / 'status.json')
        if (job / 'imported.flag').exists(): info = {'state': 'done', 'message': '已导入'}
        rows.append({**item, 'state': info['state'], 'message': info.get('message', '')})
    counts = {s: sum(x['state'] == s for x in rows) for s in ('done', 'error', 'cancelled')}
    state = 'done' if counts['done'] == len(rows) else 'partial' if counts['done'] else 'error'
    message = '对应已处理：成功 ' + str(counts['done']) + ' 层，失败 ' + str(counts['error']) + ' 层。'
    worker.atomic_json(batch / 'status.json', {'state': state, 'message': message, 'items': rows, 'counts': counts,
        'worker_version': worker.WORKER_VERSION, 'updated_at': int(time.time())})
    set_status(task, 'done', message)
    if notify and request.get('notify', True):
        from completion_notifier import notify_completion
        # Let the confirmation JSX return before attaching to Photoshop COM.
        # A single finite delay; never relaunch in a loop or block PS with polling.
        time.sleep(1)
        notify_completion(batch, phase='mapping')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path, required=True)
    args = parser.parse_args()
    task = args.job.resolve()
    if task.parent != (worker.RUNTIME / 'jobs').resolve() or not task.is_dir(): raise worker.UserError('核对任务目录无效。')
    try:
        with (task / 'submitted.lock').open('x', encoding='ascii') as file: file.write(str(os.getpid()))
    except FileExistsError: return 0
    try: finalize(task)
    except Exception as exc:
        set_status(task, 'error', str(exc) if isinstance(exc, worker.UserError) else '本地核对处理失败（' + type(exc).__name__ + '）。')
        if os.name == 'nt':
            import ctypes
            message = worker.read_json(task / 'status.json')['message']
            ctypes.windll.user32.MessageBoxW(None, message + '\n任务日志：' + str(task / 'worker.log'), '合并图片对应失败', 0x10)
    return 0


if __name__ == '__main__': raise SystemExit(main())
