"""Finite sequential layer queue. Each layer has one immutable job identity."""
from __future__ import annotations
import argparse
from pathlib import Path
import os
import threading
import time
import bridge_worker as worker
from batch_records import validate_item

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / 'runtime'
TERMINAL = {'done', 'error', 'cancelled'}

def safe_name(value):
    import re
    return isinstance(value, str) and re.fullmatch(r'[0-9]+-[0-9]+', value) is not None

def load_manifest(batch):
    data = worker.read_json(batch / 'request.json')
    tasks = data.get('items')
    if data.get('schema') != 1 or not isinstance(tasks, list) or not tasks or len(tasks) > 500:
        raise worker.UserError('批次记录无效，支持每批 1 至 500 个图层。')
    seen_jobs, seen_layers = set(), set()
    mode = data.get('web_upload_mode', 'separate')
    if mode not in ('separate', 'merged'): raise worker.UserError('批次上传模式无效。')
    for item in tasks:
        job, request = validate_item(RUNTIME, batch.name, data, item, require_files=True)
        if item.get('carried') is not True and (request.get('web_upload_mode', 'separate') != mode or
                mode == 'merged' and request.get('backend') != 'web'):
            raise worker.UserError('图层与批次上传模式不一致。')
        identity = (request.get('document_id'), request.get('source_layer_id'))
        if item['job_name'] in seen_jobs or identity in seen_layers:
            raise worker.UserError('批次包含重复图层或任务，已停止以免重复生成。')
        if not (job / 'source.png').is_file(): raise worker.UserError('批次导出图片缺失，已停止。')
        seen_jobs.add(item['job_name'])
        seen_layers.add(identity)
    return data

def task_status(item):
    job = RUNTIME / 'jobs' / item['job_name']
    if (job / 'imported.flag').exists(): return {'state': 'done', 'message': '已导入', 'imported': True}
    path = job / 'status.json'
    if path.exists():
        try: return worker.read_json(path)
        except (ValueError, OSError): pass
    return {'state': 'queued', 'message': '等待处理'}

def process_batch(batch, poll_seconds=2):
    manifest, current = None, None
    notify_requested = True
    last_snapshot = None
    def snapshot(state='running', message=''):
        nonlocal last_snapshot
        rows = []
        for item in manifest['items']:
            info = task_status(item)
            rows.append({**item, 'state': info['state'], 'message': info.get('message', ''), 'stage': info.get('stage', '')})
        counts = {key: sum(row['state'] == key for row in rows) for key in TERMINAL}
        text = message or f"共 {len(rows)} 层：成功 {counts['done']}，失败 {counts['error']}，取消 {counts['cancelled']}。"
        carried_count = sum(item.get('carried') is True for item in manifest['items'])
        if carried_count and not message: text = f"本轮处理 {len(rows) - carried_count} 层，沿用 {carried_count} 层。" + text
        result = {'state': state, 'message': text, 'items': rows, 'counts': counts,
                  'total': len(rows), 'new_attempts': len(rows) - carried_count, 'carried_count': carried_count,
                  'worker_version': worker.WORKER_VERSION, 'updated_at': int(time.time())}
        worker.atomic_json(batch / 'status.json', result)
        stamp = [(row['state'], row['message']) for row in rows]
        signature = (state, text, stamp)
        if signature != last_snapshot:
            with (batch / 'worker.log').open('a', encoding='utf-8') as log:
                log.write(time.strftime('%Y-%m-%d %H:%M:%S ') + state + ' ' + text + '\n')
                for index, row in enumerate(rows): log.write(f"  {index + 1}. layer_id={row['source_layer_id']} {row['state']} {row['message']}\n")
            last_snapshot = signature
        return result
    try:
        notify_requested = worker.read_json(batch / 'request.json').get('notify', True)
        manifest = load_manifest(batch)
        snapshot()
        merged = manifest.get('web_upload_mode', 'separate') == 'merged'
        if merged:
            from merged_worker import process
            process(batch, manifest, snapshot)
        for item in ([] if merged else manifest['items']):
            current = RUNTIME / 'jobs' / item['job_name']
            # A retry batch keeps other rows visible; their immutable jobs never run again.
            if item.get('carried') is True: continue
            if (batch / 'cancel.flag').exists():
                if task_status(item)['state'] not in TERMINAL:
                    worker.atomic_json(current / 'status.json', {'state': 'cancelled', 'message': '批次已取消；此图层未提交。'})
                continue
            # A prior lock is evidence of a possible upstream submission. Never resubmit.
            try:
                with (current / 'submitted.lock').open('x', encoding='ascii') as lock: lock.write(str(os.getpid()))
            except FileExistsError:
                if task_status(item)['state'] not in TERMINAL:
                    worker.atomic_json(current / 'status.json', {'state': 'error', 'message': '任务已有提交记录，结果未确认；为避免重复生成未重发。'})
                continue
            def run_task():
                try: worker.process_job(current)
                except Exception as exc:
                    worker.atomic_json(current / 'status.json', {'state': 'error', 'message': '本地图层任务异常（' + type(exc).__name__ + '）。'})
            thread = threading.Thread(target=run_task, daemon=False)
            thread.start()
            while thread.is_alive():
                if (batch / 'cancel.flag').exists() and task_status(item)['state'] not in TERMINAL:
                    (current / 'cancel.flag').touch()
                snapshot()
                thread.join(poll_seconds)
            snapshot()
        result = snapshot()
        counts = result['counts']
        if any(row['state'] == 'mapping' for row in result['items']): state = 'review'
        elif counts['cancelled']: state = 'cancelled'
        elif counts['done'] == len(manifest['items']): state = 'done'
        elif counts['done']: state = 'partial'
        else: state = 'error'
        result = snapshot(state, '合并结果已下载，请在 PS 脚本中点击“核对合并结果”，逐层确认图片后再导入。' if state == 'review' else '')
    except Exception as exc:
        message = str(exc) if isinstance(exc, worker.UserError) else '本地批次处理失败（' + type(exc).__name__ + '），请检查任务记录。'
        result = {'state': 'error', 'message': message, 'worker_version': worker.WORKER_VERSION, 'updated_at': int(time.time())}
        worker.atomic_json(batch / 'status.json', result)
    # A completed batch never needs generation credentials to preview/import.
    try: (batch / 'credentials.json').unlink(missing_ok=True)
    except OSError: pass
    if notify_requested:
        try:
            from completion_notifier import notify_completion
            notify_completion(batch)
        except Exception:
            worker.atomic_json(batch / 'notification.json', {'state': 'error', 'message': '自动提示未能启动；请重新运行 PS 脚本查看已保存结果。'})
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path, required=True)
    args = parser.parse_args()
    batch = args.job.resolve()
    if batch.parent != (RUNTIME / 'batches').resolve() or not batch.is_dir() or not safe_name(batch.name):
        raise worker.UserError('批次目录无效。')
    try:
        with (batch / 'submitted.lock').open('x', encoding='ascii') as lock: lock.write(str(os.getpid()))
    except FileExistsError: return 0
    process_batch(batch)
    return 0

if __name__ == '__main__': raise SystemExit(main())
