"""Notify once through the existing Photoshop COM instance; no browser or service."""
from pathlib import Path
import os
import subprocess
import re
import bridge_worker as worker

def notify_completion(batch, phase='generation'):
    if os.name != 'nt': return
    if phase not in ('generation', 'mapping') and not re.fullmatch(r'recovery-[0-9]+-[0-9]+', phase): return
    try:
        name = 'notification-started.flag' if phase == 'generation' else 'notification-' + phase + '-started.flag'
        with (batch / name).open('x', encoding='ascii') as file: file.write('once')
    except FileExistsError: return
    script = Path(__file__).resolve().with_name('notify_completion.ps1')
    powershell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
    worker.atomic_json(batch / 'notification.json', {'state': 'requested', 'message': '完成提示已启动；正在尝试返回 PS 结果窗口。'})
    subprocess.Popen([str(powershell), '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
                      '-WindowStyle', 'Hidden', '-File', str(script), '-BatchName', batch.name],
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     creationflags=subprocess.CREATE_NO_WINDOW)
