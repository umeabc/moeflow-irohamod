@echo off
echo The old browser/admin entry is disabled.
echo Use the account import button in the Photoshop script window.
pause
