param([switch]$Quiet)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') + '\'
$jobRoot = Join-Path $PSScriptRoot 'runtime\jobs'
if (Test-Path -LiteralPath $jobRoot) {
    Get-ChildItem -LiteralPath $jobRoot -Directory | ForEach-Object {
        $statePath = Join-Path $_.FullName 'status.json'
        if (Test-Path -LiteralPath $statePath) {
            try {
                $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($state.state -in @('starting','uploading','resolving','generating','downloading','waiting_scan','scanned')) {
                    [IO.File]::WriteAllText((Join-Path $_.FullName 'cancel.flag'), 'cancelled')
                }
            } catch { }
        }
    }
}
$batchRoot = Join-Path $PSScriptRoot 'runtime\batches'
if (Test-Path -LiteralPath $batchRoot) {
    Get-ChildItem -LiteralPath $batchRoot -Directory | ForEach-Object {
        $batchStatus = Join-Path $_.FullName 'status.json'
        if (Test-Path -LiteralPath $batchStatus) {
            try {
                $batchInfo = Get-Content -LiteralPath $batchStatus -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($batchInfo.state -in @('running','starting')) {
                    [IO.File]::WriteAllText((Join-Path $_.FullName 'cancel.flag'), 'cancelled')
                    $batchInfo.state = 'cancelled'
                    $batchInfo.message = 'Stopped by Stop_Doubao.cmd; existing results are retained.'
                    $batchInfo | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $batchStatus -Encoding UTF8
                }
            } catch { }
        }
    }
}
$all = @(Get-CimInstance Win32_Process)
$ids = @{}
foreach ($proc in $all) {
    if ($proc.Name -notin @('python.exe','pythonw.exe','node.exe','chrome.exe','chromium.exe','wscript.exe','cscript.exe','powershell.exe')) { continue }
    if ($proc.ProcessId -eq $PID) { continue }
    if ($proc.Name -eq 'powershell.exe' -and (-not $proc.CommandLine -or
        $proc.CommandLine.IndexOf(($projectRoot + 'notify_completion.ps1'), [StringComparison]::OrdinalIgnoreCase) -lt 0)) { continue }
    $ownExe = $proc.ExecutablePath -and $proc.ExecutablePath.StartsWith($projectRoot, [StringComparison]::OrdinalIgnoreCase)
    $ownCommand = $proc.CommandLine -and $proc.CommandLine.IndexOf($projectRoot, [StringComparison]::OrdinalIgnoreCase) -ge 0
    if ($ownExe -or $ownCommand) { $ids[[int]$proc.ProcessId] = $true }
}
# Include descendants of positively identified project processes, never their parents.
$added = $true
while ($added) {
    $added = $false
    foreach ($proc in $all) {
        if ($ids.ContainsKey([int]$proc.ParentProcessId) -and -not $ids.ContainsKey([int]$proc.ProcessId)) {
            $ids[[int]$proc.ProcessId] = $true
            $added = $true
        }
    }
}
foreach ($processId in @($ids.Keys)) {
    # Recheck identity in case a PID was reused since the snapshot.
    $before = $all | Where-Object { $_.ProcessId -eq $processId } | Select-Object -First 1
    $now = Get-CimInstance Win32_Process -Filter "ProcessId=$processId" -ErrorAction SilentlyContinue
    if ($now -and $before -and $now.CreationDate -eq $before.CreationDate) {
        Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
    }
}
New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot 'runtime') | Out-Null
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'runtime\legacy-disabled.flag'), 'Browser service disabled; HTTP only.')
if (-not $Quiet) { Write-Host ('Stopped project processes: ' + $ids.Count + '. No browser/service will be restarted.') }
