﻿param([Parameter(Mandatory=$true)][ValidatePattern('^[0-9]+-[0-9]+$')][string]$BatchName)
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$batchPath = Join-Path $taskRoot ('runtime\batches\' + $BatchName)
$notificationPath = Join-Path $batchPath 'notification.json'
function Set-Notice([string]$State, [string]$Message) {
    $payload = @{state=$State; message=$Message} | ConvertTo-Json -Compress
    $tempPath = Join-Path $batchPath ('notice-' + [guid]::NewGuid().ToString('N') + '.tmp')
    [IO.File]::WriteAllText($tempPath, $payload, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $tempPath -Destination $notificationPath -Force
}
try {
    if (-not (Test-Path -LiteralPath (Join-Path $batchPath 'status.json'))) { exit 1 }
    # Attach only. Never start Photoshop, open a document, or loop over script launches.
    $photoshop = [Runtime.InteropServices.Marshal]::GetActiveObject('Photoshop.Application')
    $manifest = Get-Content -LiteralPath (Join-Path $batchPath 'request.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.photoshop_version -and $photoshop.Version -ne $manifest.photoshop_version) {
        throw 'The active COM instance is a different Photoshop version.'
    }
    $jsxPath = (Join-Path $taskRoot 'Doubao_RemoveText.jsx') | ConvertTo-Json -Compress
    $batchJson = $BatchName | ConvertTo-Json -Compress
    $expectedPath = $manifest.photoshop_path | ConvertTo-Json -Compress
    $code = 'if(app.path.fsName!==' + $expectedPath + '){throw new Error("Different Photoshop instance");}' +
            '$.global.__doubaoBatchName=' + $batchJson + ';$.evalFile(' + $jsxPath + ');'
    Set-Notice 'opening' '正在返回 Photoshop 结果窗口。'
    $null = $photoshop.DoJavaScript($code)
    Set-Notice 'returned' 'PS 已显示批次结果窗口。'
} catch {
    try { Set-Notice 'fallback' 'PS 正忙、已关闭或 COM 不可用；结果已保存，请重新运行脚本查看。' } catch { }
    Add-Type -AssemblyName System.Windows.Forms
    $status = Get-Content -LiteralPath (Join-Path $batchPath 'status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $text = '豆包批次已结束。' + [Environment]::NewLine + $status.message + [Environment]::NewLine +
            '结果已保存。请返回 Photoshop，重新运行豆包脚本查看和导入，无需重新生成。'
    $null = [Windows.Forms.MessageBox]::Show($text, '豆包去字 v6.5.1', 'OK', 'Information')
}
