"""Seedream image editing over HTTP. One submission, no account fallback/retries."""
import base64
import binascii
import time
from urllib.parse import urlsplit
from generation_profiles import validate_api, model_family
from api_diagnostics import response_details

MAX_INPUT = 30 * 1024 * 1024
MAX_RESULT = 50 * 1024 * 1024
EDIT_INSTRUCTION = ('请仅编辑 image 字段提供的这一张原图，执行局部文字清理，而不是重新创作图片。'
                    '只移除文字笔画并自然修补其覆盖区域；保持其余区域、人物数量与姿态、'
                    '线条、网点、气泡、颜色、裁切和构图不变，不补全画外内容，不新增物体。'
                    '输出完整的处理后原图。用户补充要求：')


def fail_response(response, data, error, profile=None, prompt='', request_prompt=''):
    profile = profile or {}
    detail = response_details(response, data, (profile.get('api_key'), prompt, request_prompt))
    reasons = {'authentication': '认证失败，请核对 API Key 是否属于当前计费入口',
               'permission': '权限不足，请核对模型开通状态及当前入口的 Key 权限',
               'quota_limit': '额度、余额或频率受限，请检查所选服务控制台',
               'content_review': '内容审核未通过',
               'unsupported_parameter': '接口不支持所列参数，请导出日志用于核对协议',
               'invalid_model': '模型名或模型权限不匹配，请核对当前入口支持的模型',
               'invalid_input_image': '参考图参数不符合接口要求',
               'invalid_output_size': '输出档位不符合当前模型要求',
               'invalid_parameter': '接口参数、模型或地址无效，请核对配置及模型权限',
               'service_unavailable': '服务端暂时异常', 'invalid_response': '接口未返回可用图片'}
    labels = ['HTTP ' + str(response.status_code)]
    if detail.get('code'): labels.append('业务码 ' + detail['code'])
    if detail.get('param'): labels.append('参数 ' + detail['param'])
    reason = reasons.get(detail.get('category'), reasons['invalid_response'])
    if profile.get('billing_mode') == 'plan' and detail.get('category') in ('authentication', 'permission', 'invalid_model', 'invalid_parameter'):
        reason += '；Agent Plan 请使用套餐专属 Key 和套餐支持的模型名'
    exc = error('API 生成失败（' + '，'.join(labels) + '）：' + reason + '。未自动重试。')
    exc.api_codes = [str(response.status_code)]
    exc.api_error_details = detail
    raise exc


def generate(client, profile, upload_path, prompt, check, diagnostic, error):
    from PIL import Image
    profile = validate_api(profile, error)
    if upload_path.stat().st_size > MAX_INPUT: raise error('API 输入图片超过 30 MB，请缩小原图层后重新提交。')
    with Image.open(upload_path) as image:
        if image.format != 'PNG': raise error('API 参考图不是有效的 PNG 上传副本，未提交生成。')
        w, h = image.size
        if min(w, h) <= 14 or w * h > 36_000_000 or not 1 / 16 <= w / h <= 16:
            raise error('API 参考图须宽高均大于 14 像素、总像素不超过 3600 万，宽高比在 1:16 至 16:1 之间。请调整图层后重新提交。')
        image.verify()
    source_bytes = upload_path.read_bytes()
    encoded = base64.b64encode(source_bytes).decode('ascii')
    if base64.b64decode(encoded, validate=True) != source_bytes:
        raise error('API 参考图编码校验失败，未提交生成。')
    payload = {'model': profile['model'], 'prompt': EDIT_INSTRUCTION + prompt,
               'image': 'data:image/png;base64,' + encoded,
               'size': profile['size'], 'response_format': 'url', 'watermark': False}
    diagnostic.input_image({'width': w, 'height': h, 'bytes': len(source_bytes), 'count': 1,
                            'transport': 'data_uri_png', 'png_verified': True,
                            'encoding_verified': True, 'edit_instruction': 'preserve_source_v1'})
    family = model_family(profile['model'])
    if family in ('seedream5_pro', 'seedream5_flash', 'seedream5_lite'): payload['output_format'] = 'png'
    # Pro/Flash reject even disabled/false values for unsupported group/stream
    # parameters. Omit both; the documented default is one non-streaming image.
    diagnostic.api_request({'billing_mode': profile['billing_mode'], 'model_family': family,
                            'size': profile['size'], 'model_normalized': profile['model_normalized'],
                            'fields': list(payload)})
    started = time.monotonic()
    # Response cap and finite deadline, including receipt of the whole body.
    with client.stream('POST', profile['endpoint'], headers={'Authorization': 'Bearer ' + profile['api_key'],
                       'Content-Type': 'application/json'}, json=payload, timeout=check()) as response:
        body = bytearray()
        for chunk in response.iter_bytes():
            check()
            body.extend(chunk)
            if len(body) > MAX_RESULT * 4 // 3 + 1024 * 1024: raise error('API 响应超过本机处理上限。未重复提交。')
        diagnostic.http('generating', response, (time.monotonic() - started) * 1000)
        import json
        try: data = json.loads(body)
        except (ValueError, UnicodeError): data = None
        if response.status_code != 200 or not isinstance(data, dict) or data.get('error'):
            fail_response(response, data, error, profile, prompt, payload['prompt'])
        usage = data.get('usage') if isinstance(data.get('usage'), dict) else {}
        input_count = usage.get('input_images')
        valid_count = isinstance(input_count, int) and not isinstance(input_count, bool) and 0 <= input_count <= 10000
        reference_status = ('confirmed' if input_count == 1 else 'rejected' if input_count == 0 else 'unexpected') if valid_count else 'not_reported'
        detail = response_details(response, data, (profile.get('api_key'), prompt, payload['prompt']))
        diagnostic.api_response({'input_images': input_count, 'generated_images': usage.get('generated_images'),
                                 'reference_status': reference_status, 'request_id': detail.get('request_id')})
        if valid_count and input_count != 1:
            raise error('API 参考图未被正确接收（服务端报告输入图片 ' + str(input_count) +
                        ' 张，应为 1 张）。已阻止下载和导入此结果，未自动重试或切换接口。请导出日志核对。')
        items = data.get('data')
        if not isinstance(items, list) or not items or not isinstance(items[0], dict): fail_response(response, data, error, profile, prompt, payload['prompt'])
        first = items[0]
        if first.get('error'): fail_response(response, {'error': first['error']}, error, profile, prompt, payload['prompt'])
        encoded = first.get('b64_json')
        if encoded is not None:
            try:
                if not isinstance(encoded, str) or len(encoded) > MAX_RESULT * 4 // 3 + 4: raise ValueError()
                decoded = base64.b64decode(encoded, validate=True)
                if not decoded or len(decoded) > MAX_RESULT: raise ValueError()
            except (ValueError, binascii.Error): raise error('API 返回图片编码无效或超过 50 MB。')
            check()
            return {'bytes': decoded, 'source': 'api_base64', 'reference_status': reference_status}
        url = first.get('url')
        try:
            parts = urlsplit(url) if isinstance(url, str) else None
            valid = parts and parts.scheme == 'https' and parts.hostname and not parts.username and not parts.password
        except ValueError: valid = False
        if not valid: raise error('API 没有返回有效的 HTTPS 图片下载地址。未重复提交。')
        check()
        return {'url': url, 'source': 'api_url', 'reference_status': reference_status}
