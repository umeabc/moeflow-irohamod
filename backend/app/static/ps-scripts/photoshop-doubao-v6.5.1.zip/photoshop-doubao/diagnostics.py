"""Bounded, structured diagnostics. No request bodies, credentials or raw replies."""
from collections import Counter
import time
from api_diagnostics import safe_error_details, safe_request_summary, safe_input_image, safe_api_response, safe_web_upload, safe_transfer

class Diagnostics:
    def __init__(self, job, version, writer):
        self.job, self.writer = job, writer
        self.start = time.monotonic()
        self.last_flush = 0.0
        self.data = {'schema': 1, 'worker_version': version, 'job_name': job.name,
                     'started_at': int(time.time()), 'options': {}, 'requests': [],
                     'stream': {'frames': 0, 'event_types': {}, 'event_names': {},
                                'content_types': {}, 'block_types': {}, 'notice_codes': [],
                                'image_variants': 0, 'completed': False}, 'outcome': 'starting'}
    def emit(self, kind, **fields):
        row = {'time': int(time.time()), 'elapsed_ms': round((time.monotonic() - self.start) * 1000),
               'kind': kind, **fields}
        with (self.job / 'events.jsonl').open('a', encoding='utf-8') as file:
            import json
            file.write(json.dumps(row, ensure_ascii=False) + '\n')
    def flush(self):
        self.data['elapsed_ms'] = round((time.monotonic() - self.start) * 1000)
        self.writer(self.job / 'diagnostic.json', self.data)
        self.last_flush = time.monotonic()
    def options(self, **fields):
        allowed = {'width', 'height', 'document_id', 'source_layer_id', 'prefer_watermark_free', 'memory_type'}
        self.data['options'] = {key: value for key, value in fields.items() if key in allowed and isinstance(value, (int, float, bool))}
        self.emit('options', **self.data['options'])
        self.flush()
    def state(self, state, stage, message):
        self.data['outcome'], self.data['stage'] = state, stage
        self.data['message'] = message
        self.emit('state', state=state, stage=stage, message=message)
        self.flush()
    def http(self, stage, response, elapsed_ms):
        content_type = response.headers.get('content-type', '').split(';')[0].lower()
        if content_type not in ('application/json', 'text/event-stream', 'text/plain', 'text/html', ''): content_type = 'other'
        row = {'stage': stage, 'status': response.status_code, 'content_type': content_type,
               'elapsed_ms': round(elapsed_ms)}
        self.data['requests'].append(row)
        self.emit('http', **row)
        self.flush()
    def api_request(self, summary):
        self.data['api_request'] = safe_request_summary(summary)
        self.emit('api_request', **self.data['api_request'])
        self.flush()
    def input_image(self, details):
        self.data['input_image'] = safe_input_image(details)
        self.emit('input_image', **self.data['input_image'])
        self.flush()
    def api_response(self, details):
        self.data['api_response'] = safe_api_response(details)
        self.emit('api_response', **self.data['api_response'])
        self.flush()
    def web_upload(self, details):
        row = safe_web_upload(details)
        self.data.setdefault('uploads', []).append(row)
        self.emit('web_upload', **row)
        self.flush()
    def transfer(self, details):
        row = safe_transfer(details)
        self.data.setdefault('downloads', []).append(row)
        self.emit('result_transfer', **row)
        self.flush()
    def api_error(self, details):
        self.data['api_error'] = safe_error_details(details)
        self.emit('api_error', **self.data['api_error'])
        self.flush()
    def observe(self, event_type, event_name, content_types, block_types, notices, variant_count):
        stream = self.data['stream']
        stream['frames'] += 1
        for key, values in (('event_types', [event_type]), ('event_names', [event_name]),
                            ('content_types', content_types), ('block_types', block_types)):
            counter = Counter(stream[key])
            counter.update(str(value) for value in values if value is not None)
            stream[key] = dict(counter)
        stream['notice_codes'] = sorted(set(stream['notice_codes']) | set(notices))
        stream['image_variants'] += variant_count
        if time.monotonic() - self.last_flush >= 2: self.flush()
    def stream_end(self):
        self.data['stream']['completed'] = True
        self.emit('stream_summary', **self.data['stream'])
        self.flush()
    def exception(self, exc):
        # Exception messages from HTTP libraries can contain signed URLs.
        self.data['exception_type'] = type(exc).__name__
        if getattr(exc, 'api_error_details', None): self.api_error(exc.api_error_details)
        import re
        codes = [code for code in getattr(exc, 'api_codes', []) if isinstance(code, str) and re.fullmatch(r'-?\d{1,12}', code)]
        if codes: self.data['api_codes'] = codes
        self.emit('exception', exception_type=type(exc).__name__, api_codes=codes)
        self.flush()
