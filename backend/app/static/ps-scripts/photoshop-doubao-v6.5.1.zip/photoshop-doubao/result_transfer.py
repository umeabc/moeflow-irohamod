"""Private result checkpoints and bounded GET retries; never submits generation."""
import re
import time
from urllib.parse import urlsplit


def save(job, request, result):
    import bridge_worker as worker
    data = {'schema': 1, **{k: request.get(k) for k in ('document_id', 'source_layer_id', 'width', 'height', 'backend')},
            **{k: result.get(k) for k in ('source', 'reference_status', 'task_id', 'query_endpoint', 'endpoint') if result.get(k) is not None}}
    if result.get('url'):
        parts = urlsplit(result['url'])
        if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password: raise worker.UserError('结果下载地址无效。')
        data['url'] = result['url']
    elif result.get('bytes'):
        (job / 'result-cache.bin').write_bytes(result['bytes'])
        data['cached_bytes'] = True
    else: raise worker.UserError('没有可保存的生成结果。')
    # Contains signed URLs: excluded from support logs and public packages.
    worker.atomic_json(job / 'remote-result.json', data)
    return data


def load(job, request):
    import bridge_worker as worker
    data = worker.read_json(job / 'remote-result.json')
    if data.get('schema') != 1 or any(data.get(k) != request.get(k) for k in ('document_id', 'source_layer_id', 'width', 'height', 'backend')):
        raise worker.UserError('保存的结果与原图层不一致，未下载或生成。')
    return data


def network_kind(exc):
    import httpx
    import socket
    import ssl
    seen = set()
    current = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, ssl.SSLError): return 'tls'
        if isinstance(current, socket.gaierror): return 'dns'
        # Inspect only in memory; raw exception strings can contain signed URLs.
        text = str(current).lower()
        if 'certificate_verify_failed' in text or 'ssl:' in text: return 'tls'
        if 'getaddrinfo' in text or 'name resolution' in text: return 'dns'
        current = current.__cause__ or current.__context__
    if isinstance(exc, httpx.TimeoutException): return 'timeout'
    if isinstance(exc, httpx.RequestError): return 'connection'
    return 'http'


def download(client, url, target, check, diagnostic=None, progress=None):
    import bridge_worker as worker
    import httpx
    for attempt in range(1, 4):
        check()
        try:
            worker.download_image(client, url, target, lambda: min(30, check()), diagnostic)
            return
        except worker.Cancelled:
            target.unlink(missing_ok=True)
            raise
        except (httpx.RequestError, worker.UserError) as exc:
            codes = getattr(exc, 'api_codes', [])
            retryable = isinstance(exc, httpx.RequestError) or any(str(code) in ('429', '500', '502', '503', '504') for code in codes)
            will_retry = retryable and attempt < 3
            if diagnostic:
                diagnostic.transfer({'attempt': attempt, 'will_retry': will_retry, 'category': network_kind(exc),
                    'exception_type': type(exc).__name__, 'generation_succeeded': True})
            target.unlink(missing_ok=True)
            if not will_retry:
                failure = worker.UserError('生成已成功，但结果图片下载失败。可点击“找回 / 下载所选结果”重取已有图片；不会重新生成。')
                failure.transfer_failure = True
                raise failure from exc
            if progress: progress('生成已成功，正在重试下载图片（' + str(attempt + 1) + '/3）；不会重新生成……')
            until = time.monotonic() + attempt
            while time.monotonic() < until:
                check()
                time.sleep(min(0.2, max(0, until - time.monotonic())))


def lookup_grsai(client, profile, task_id, check, diagnostic):
    """Only exact existing-task GET. No fallback endpoint or POST."""
    import bridge_worker as worker
    from image_api import read_response, reference_status, image_result
    from generation_profiles import validate_api
    profile = validate_api(profile, worker.UserError)
    if profile['protocol'] != 'grsai' or not isinstance(task_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{6,150}', task_id):
        raise worker.UserError('请选择原 Grsai 配置，并填写中转站详情内的完整任务 ID。')
    parts = urlsplit(profile['endpoint'])
    endpoint = parts.scheme + '://' + parts.netloc + '/v1/api/result'
    data, detail = read_response(client, 'GET', endpoint, check, diagnostic, worker.UserError, profile, '',
        headers={'Authorization': 'Bearer ' + profile['api_key']}, params={'id': task_id})
    if data.get('id') != task_id: raise worker.UserError('中转返回了其他任务的结果，已停止。')
    if data.get('status') != 'succeeded': raise worker.UserError('该任务尚未成功或未返回可用结果；只查询已有任务，没有重新生成。')
    ref = reference_status(data, detail, diagnostic, worker.UserError)
    items = data.get('results')
    first = items[0] if isinstance(items, list) and items else None
    result = image_result(first, ref, worker.UserError)
    return {**result, 'task_id': task_id, 'query_endpoint': endpoint, 'endpoint': profile['endpoint']}
