﻿#target photoshop
/* Photoshop 2023 / ExtendScript ES3. Keep this file beside config.json and bridge_worker.py. */
(function () {
    var root = new File($.fileName).parent;
    var originalDoc = null, originalLayer = null, scratch = null;
    var job = null, imported = null, historyBeforeImport = null;
    var rulerBefore = app.preferences.rulerUnits, dialogsBefore = app.displayDialogs;
    var originBefore = null, succeeded = false;
    var backend = "web", accountID = "", apiID = "", webUploadMode = "separate";
    var sessionFile = "", prompt = "", notice = "", response = null;
    var batchFolder = null, entries = [], currentIndex = 0, requestedIndex = 0;
    var selectedRowIndices = [], requestedIndices = [], uiTab = 0;
    var raw = null, box = null, width = 0, height = 0, selectedIDsAtOpen = [];
    var resumeBatchName = $.global.__doubaoBatchName || "";
    try { delete $.global.__doubaoBatchName; } catch (ignoredGlobal) {}

    function fail(message) { throw new Error(message); }
    function child(folder, name) { return new File(folder.fsName + "/" + name); }
    function ensureFolder(folder) {
        if (folder.exists) { return; }
        if (folder.parent && !folder.parent.exists) { ensureFolder(folder.parent); }
        if (!folder.create()) { fail("无法创建目录：" + folder.fsName); }
    }
    function writeText(file, text) {
        file.encoding = "UTF-8";
        if (!file.open("w")) { fail("无法写入：" + file.fsName); }
        try { if (!file.write(text)) { fail("写入失败：" + file.fsName); } }
        finally { file.close(); }
    }
    function readText(file) {
        file.encoding = "UTF-8";
        if (!file.open("r")) { fail("无法读取：" + file.fsName); }
        try { return file.read().replace(/^\uFEFF/, ""); } finally { file.close(); }
    }
    function quote(text) {
        return '"' + String(text).replace(/["\\\x00-\x1f]/g, function (c) {
            var escapes = {'"': '\\"', '\\': '\\\\', '\n': '\\n', '\r': '\\r', '\t': '\\t'};
            if (escapes[c]) { return escapes[c]; }
            return "\\u" + ("0000" + c.charCodeAt(0).toString(16)).slice(-4);
        }) + '"';
    }
    // Strict data parser: avoids depending on JSON globals installed by other PS scripts.
    function parseJSON(text) {
        var pos = 0;
        function ws() { while (/\s/.test(text.charAt(pos)) && pos < text.length) { pos++; } }
        function string() {
            var out = "", c, hex, escapeMap = {'"': '"', '\\': '\\', '/': '/', b: '\b', f: '\f', n: '\n', r: '\r', t: '\t'};
            pos++;
            while (pos < text.length) {
                c = text.charAt(pos++);
                if (c === '"') { return out; }
                if (c === "\\") {
                    c = text.charAt(pos++);
                    if (c === "u") {
                        hex = text.substr(pos, 4);
                        if (!/^[0-9a-fA-F]{4}$/.test(hex)) { fail("JSON Unicode 格式错误。"); }
                        out += String.fromCharCode(parseInt(hex, 16)); pos += 4;
                    } else {
                        if (!escapeMap.hasOwnProperty(c)) { fail("JSON 转义格式错误。"); }
                        out += escapeMap[c];
                    }
                } else {
                    if (c.charCodeAt(0) < 32) { fail("JSON 字符串格式错误。"); }
                    out += c;
                }
            }
            fail("JSON 字符串未结束。");
        }
        function value(depth) {
            if (depth > 50) { fail("JSON 嵌套过深。"); }
            ws(); var c = text.charAt(pos), out, key, token;
            if (c === '"') { return string(); }
            if (c === "{" || c === "[") {
                var object = c === "{", close = object ? "}" : "]";
                out = object ? {} : []; pos++; ws();
                if (text.charAt(pos) === close) { pos++; return out; }
                while (pos < text.length) {
                    ws();
                    if (object) {
                        if (text.charAt(pos) !== '"') { fail("JSON 对象键无效。"); }
                        key = string(); ws();
                        if (text.charAt(pos++) !== ":") { fail("JSON 缺少冒号。"); }
                        if (key === "__proto__" || key === "constructor" || key === "prototype") { fail("JSON 对象键不允许。"); }
                        out[key] = value(depth + 1);
                    } else { out.push(value(depth + 1)); }
                    ws(); c = text.charAt(pos++);
                    if (c === close) { return out; }
                    if (c !== ",") { fail("JSON 缺少分隔符。"); }
                }
                fail("JSON 未结束。");
            }
            token = /^(true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(text.substr(pos));
            if (!token) { fail("JSON 值无效。"); }
            pos += token[0].length;
            if (token[0] === "true") { return true; }
            if (token[0] === "false") { return false; }
            if (token[0] === "null") { return null; }
            return Number(token[0]);
        }
        var result = value(0); ws();
        if (pos !== text.length) { fail("JSON 末尾有额外内容。"); }
        return result;
    }
    function encodeJSON(value) {
        var i, parts = [], key;
        if (value === null) { return "null"; }
        if (typeof value === "string") { return quote(value); }
        if (typeof value === "number") { if (!isFinite(value)) { fail("记录含无效数值。"); } return String(value); }
        if (typeof value === "boolean") { return value ? "true" : "false"; }
        if (value instanceof Array) {
            for (i = 0; i < value.length; i++) { parts.push(encodeJSON(value[i])); }
            return "[" + parts.join(",") + "]";
        }
        for (key in value) { if (value.hasOwnProperty(key)) { parts.push(quote(key) + ":" + encodeJSON(value[key])); } }
        return "{" + parts.join(",") + "}";
    }
    function selectedLayerIDs() {
        var ref = new ActionReference(), descriptor, list, ids = [], i;
        ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("targetLayersIDs"));
        ref.putEnumerated(stringIDToTypeID("document"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
        descriptor = executeActionGet(ref);
        if (descriptor.hasKey(stringIDToTypeID("targetLayersIDs"))) {
            list = descriptor.getList(stringIDToTypeID("targetLayersIDs"));
            for (i = 0; i < list.count; i++) { ids.push(list.getReference(i).getIdentifier()); }
        }
        if (!ids.length) { ids.push(originalDoc.activeLayer.id); }
        return ids;
    }
    function findLayer(container, id) {
        var i, layer, found;
        for (i = 0; i < container.layers.length; i++) {
            layer = container.layers[i];
            if (layer.id === id) { return layer; }
            if (layer.typename === "LayerSet") { found = findLayer(layer, id); if (found) { return found; } }
        }
        return null;
    }
    function selectIDs(ids) {
        var i, d, ref, added = false;
        app.activeDocument = originalDoc;
        for (i = 0; i < ids.length; i++) {
            if (!findLayer(originalDoc, ids[i])) { continue; }
            d = new ActionDescriptor(); ref = new ActionReference();
            ref.putIdentifier(stringIDToTypeID("layer"), ids[i]); d.putReference(charIDToTypeID("null"), ref);
            if (added) { d.putEnumerated(stringIDToTypeID("selectionModifier"), stringIDToTypeID("selectionModifierType"), stringIDToTypeID("addToSelection")); }
            d.putBoolean(stringIDToTypeID("makeVisible"), false); executeAction(charIDToTypeID("slct"), d, DialogModes.NO);
            added = true;
        }
    }
    function validateLayer(layer) {
        if (!layer || layer.typename !== "ArtLayer" || (layer.kind !== LayerKind.NORMAL && layer.kind !== LayerKind.SMARTOBJECT)) {
            fail("请选择像素图层或智能对象；图层组、文字及调整图层不能直接处理。");
        }
        if (layer.grouped) { fail("图层“" + layer.name + "”是剪贴图层，请先复制并合成为独立图片。"); }
    }
    function collectSelected(ids) {
        var output = [], i, layer, b, rect, w, h;
        if (!ids.length || ids.length > 500) { fail("每批支持 1 至 500 个图片图层。"); }
        for (i = 0; i < ids.length; i++) {
            layer = findLayer(originalDoc, ids[i]); validateLayer(layer); b = bounds(layer);
            rect = [Math.floor(b[0]), Math.floor(b[1]), Math.ceil(b[2]), Math.ceil(b[3])];
            w = rect[2] - rect[0]; h = rect[3] - rect[1];
            if (w <= 0 || h <= 0 || w * h > 100000000) { fail("图层“" + layer.name + "”为空或超过一亿像素。"); }
            output.push({source_layer_id: layer.id, source_layer_name: layer.name, raw_bounds: b,
                         width: w, height: h, left: rect[0], top: rect[1], job_name: ""});
        }
        return output;
    }
    function bindEntry(index) {
        if (!entries.length) { currentIndex = 0; originalLayer = null; raw = null; box = null; width = 0; height = 0; job = null; return; }
        if (index < 0 || index >= entries.length) { index = 0; }
        currentIndex = index;
        var entry = entries[index];
        originalLayer = findLayer(originalDoc, entry.source_layer_id);
        raw = entry.raw_bounds; width = entry.width; height = entry.height;
        box = [entry.left, entry.top, entry.left + width, entry.top + height];
        job = entry.job_name ? new Folder(root.fsName + "/runtime/jobs/" + entry.job_name) : null;
    }
    function bounds(layer) {
        var b = layer.bounds;
        return [b[0].as("px"), b[1].as("px"), b[2].as("px"), b[3].as("px")];
    }
    function cancelJob() {
        if (job) { try { writeText(child(job, "cancel.flag"), "cancelled"); } catch (ignored) {} }
    }
    // ASCII-only VBS supports Unicode paths via ChrW, without relying on WSH's code page.
    function vbsExpression(text) {
        var expressions = [], i, code;
        for (i = 0; i < text.length; i++) {
            code = text.charCodeAt(i);
            expressions.push("ChrW(" + (code > 32767 ? code - 65536 : code) + ")");
        }
        return expressions.join(" & ");
    }
    function launchWorker(pythonw, worker, taskFolder) {
        var task = taskFolder || job;
        var command = '"' + pythonw.fsName + '" -X utf8 "' + worker.fsName + '" --job "' + task.fsName + '"';
        var lines = ["Option Explicit", "On Error Resume Next", "Dim shell, command, fso, errorFile, errorPath", "command = \"\""], i;
        for (i = 0; i < command.length; i += 32) {
            lines.push("command = command & " + vbsExpression(command.substr(i, 32)));
        }
        lines.push("errorPath = \"\"");
        var errorPath = child(task, "launch-error.txt").fsName;
        for (i = 0; i < errorPath.length; i += 32) {
            lines.push("errorPath = errorPath & " + vbsExpression(errorPath.substr(i, 32)));
        }
        lines.push('Set shell = CreateObject("WScript.Shell")', 'shell.Run command, 0, False',
                   'If Err.Number <> 0 Then', '  Set fso = CreateObject("Scripting.FileSystemObject")',
                   '  Set errorFile = fso.CreateTextFile(errorPath, True, False)',
                   '  errorFile.WriteLine "Windows Script Host launch failed."', '  errorFile.Close',
                   '  WScript.Quit 1', 'End If');
        var launcher = child(task, "launch.vbs");
        writeText(launcher, lines.join("\r\n"));
        if (!launcher.execute()) { fail("无法启动 Windows 脚本，请检查 wscript.exe 或系统的 VBS 文件关联。"); }
    }
    function exportSource(box) {
        var docW = originalDoc.width.as("px"), docH = originalDoc.height.as("px");
        var expandedW = Math.max(docW, box[2]) - Math.min(0, box[0]);
        var expandedH = Math.max(docH, box[3]) - Math.min(0, box[1]);
        if (expandedW * expandedH > 100000000) {
            fail("临时导出画布超过一亿像素，为避免内存不足已停止。请在裁小的文档副本中处理该图层。");
        }
        var profile = "";
        try { if (originalDoc.colorProfileType !== ColorProfileType.NONE) { profile = originalDoc.colorProfileName; } } catch (ignored) {}
        if (profile) {
            scratch = app.documents.add(originalDoc.width, originalDoc.height, originalDoc.resolution, "豆包去字_临时导出",
                                        NewDocumentMode.RGB, DocumentFill.TRANSPARENT, 1, originalDoc.bitsPerChannel, profile);
        } else {
            scratch = app.documents.add(originalDoc.width, originalDoc.height, originalDoc.resolution, "豆包去字_临时导出",
                                        NewDocumentMode.RGB, DocumentFill.TRANSPARENT, 1, originalDoc.bitsPerChannel);
        }
        scratch.rulerOrigin = [0, 0];
        app.activeDocument = originalDoc;
        var copy = originalLayer.duplicate(scratch, ElementPlacement.PLACEATBEGINNING);
        app.activeDocument = scratch;
        if (copy.isBackgroundLayer) { copy.isBackgroundLayer = false; }
        copy.allLocked = false;
        try { copy.positionLocked = false; copy.pixelsLocked = false; copy.transparentPixelsLocked = false; } catch (ignoredLocks) {}
        copy.visible = true;
        // Match source canvas size first so unlinked masks keep their document coordinates.
        // Expand the canvas before rasterizing, retaining content outside the original canvas.
        var padLeft = Math.max(0, -box[0]), padTop = Math.max(0, -box[1]);
        var padRight = Math.max(0, box[2] - docW), padBottom = Math.max(0, box[3] - docH);
        if (padLeft || padTop) {
            scratch.resizeCanvas(UnitValue(docW + padLeft, "px"), UnitValue(docH + padTop, "px"), AnchorPosition.BOTTOMRIGHT);
        }
        if (padRight || padBottom) {
            scratch.resizeCanvas(UnitValue(docW + padLeft + padRight, "px"), UnitValue(docH + padTop + padBottom, "px"), AnchorPosition.TOPLEFT);
        }
        var blank = scratch.artLayers.add();
        blank.move(copy, ElementPlacement.PLACEAFTER);
        scratch.activeLayer = copy;
        copy.merge(); // Bake this layer's mask, opacity and effects onto an empty layer.
        scratch.crop([UnitValue(box[0] + padLeft, "px"), UnitValue(box[1] + padTop, "px"),
                      UnitValue(box[2] + padLeft, "px"), UnitValue(box[3] + padTop, "px")]);
        scratch.bitsPerChannel = BitsPerChannelType.EIGHT;
        scratch.convertProfile("sRGB IEC61966-2.1", Intent.RELATIVECOLORIMETRIC, true, false);
        var options = new PNGSaveOptions();
        options.compression = 6; options.interlaced = false;
        scratch.saveAs(child(job, "source.png"), options, true, Extension.LOWERCASE);
        scratch.close(SaveOptions.DONOTSAVECHANGES); scratch = null;
        app.activeDocument = originalDoc;
    }
    function placedCanvas() {
        var ref = new ActionReference();
        ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("smartObjectMore"));
        ref.putEnumerated(stringIDToTypeID("layer"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
        var desc = executeActionGet(ref).getObjectValue(stringIDToTypeID("smartObjectMore"));
        var list = desc.getList(stringIDToTypeID("transform")), xs = [], ys = [], i;
        for (i = 0; i < 8; i += 2) { xs.push(list.getDouble(i)); ys.push(list.getDouble(i + 1)); }
        return [Math.min.apply(null, xs), Math.min.apply(null, ys), Math.max.apply(null, xs), Math.max.apply(null, ys)];
    }
    function sameBox(a, b) {
        var i;
        for (i = 0; i < 4; i++) { if (Math.abs(a[i] - b[i]) > 0.01) { return false; } }
        return true;
    }
    function importResult(status, box) {
        var file = child(job, "result.png"), a = status.alpha_bounds, d, c, b;
        if (!originalLayer) { fail("原图层已删除，已跳过对应结果。"); }
        if (!file.exists || status.width !== box[2] - box[0] || status.height !== box[3] - box[1] ||
                !a || a.length !== 4 || a[0] < 0 || a[1] < 0 || a[2] > status.width || a[3] > status.height ||
                a[2] <= a[0] || a[3] <= a[1]) { fail("结果文件或尺寸记录不完整，无法导入。"); }
        if (!sameBox(bounds(originalLayer), raw)) { fail("原图层的位置或尺寸已变化，旧结果已停止导入。请恢复提交时的原图层，或读取当前图层重新生成。"); }
        app.activeDocument = originalDoc;
        originalDoc.activeLayer = originalLayer;
        historyBeforeImport = originalDoc.activeHistoryState;
        try {
            // Place in the original document. No result document and no suspendHistory callback.
            d = new ActionDescriptor();
            d.putPath(charIDToTypeID("null"), file);
            d.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
            executeAction(charIDToTypeID("Plc "), d, DialogModes.NO);
            imported = originalDoc.activeLayer;
            if (imported.id === originalLayer.id) { imported = null; fail("PS 没有建立结果图层。"); }
            c = placedCanvas();
            if (c[2] <= c[0] || c[3] <= c[1]) { fail("置入图片的变换信息无效。"); }
            // Use the entire placed PNG canvas, including transparent margins, for scaling.
            imported.resize((box[2] - box[0]) / (c[2] - c[0]) * 100,
                            (box[3] - box[1]) / (c[3] - c[1]) * 100, AnchorPosition.TOPLEFT);
            c = placedCanvas();
            imported.translate(UnitValue(box[0] - c[0], "px"), UnitValue(box[1] - c[1], "px"));
            if (!sameBox(placedCanvas(), box)) { fail("完整图片画布对齐校验失败，已撤回导入。"); }
            imported.rasterize(RasterizeType.ENTIRELAYER);
            imported.move(originalLayer, ElementPlacement.PLACEBEFORE);
            imported.name = originalLayer.name + "_豆包去字";
            imported.visible = true;
            b = [box[0] + a[0], box[1] + a[1], box[0] + a[2], box[1] + a[3]];
            if (!sameBox(bounds(imported), b)) { fail("透明像素边界校验失败，已撤回导入。"); }
            originalDoc.activeLayer = imported;
            succeeded = true;
        } catch (error) {
            try { originalDoc.activeHistoryState = historyBeforeImport; imported = null; }
            catch (undoError) { try { if (imported) { imported.remove(); imported = null; } } catch (ignored) {} }
            throw error;
        }
    }
    function statusNow() {
        if (!job) { return null; }
        if (child(job, "imported.flag").exists) { return {state: "imported", message: "此任务已导入。"}; }
        if (child(job, "launch-error.txt").exists) { return {state: "error", message: "Windows 无法启动后台程序，请检查 Windows Script Host。"}; }
        if (child(job, "status.json").exists) {
            var state = parseJSON(readText(child(job, "status.json")));
            if (child(job, "cancel.flag").exists && state.download_recovery !== true) { return {state: "cancelled", message: "此任务已取消，不会导入。"}; }
            if (!batchFolder && state.state !== "done" && state.state !== "error" && state.state !== "cancelled") {
                var req = parseJSON(readText(child(job, "request.json")));
                var age = (new Date().getTime() - Number(req.started_ms || 0)) / 1000;
                if (age > timeout + 30) {
                    cancelJob();
                    return {state: "cancelled", message: "等待已超时，未重复提交。"};
                }
            }
            return state;
        }
        if (child(job, "cancel.flag").exists) { return {state: "cancelled", message: "此任务已取消，不会导入。"}; }
        var requestFile = child(job, "request.json");
        if (batchFolder && requestFile.exists) { return {state: "queued", message: "等待前面的图层处理；无需反复刷新，批次结束会自动提示。"}; }
        if (requestFile.exists) {
            var requestData = parseJSON(readText(requestFile));
            if (new Date().getTime() - Number(requestData.started_ms || 0) > 30000) {
                cancelJob();
                return {state: "error", message: "后台程序 30 秒内没有返回状态。请运行 install.cmd，并检查 VBS 是否被系统禁用。"};
            }
        }
        if (!requestFile.exists) { return {state: "error", message: "图片导出未完成。请查看上方错误信息后重新开始。"}; }
        return {state: "starting", message: "后台程序正在启动；进度自动记录，批次结束会提示。"};
    }

    function profileList(kind) { return kind === "api" ? config.apis : config.accounts; }
    function findProfile(kind, id) {
        var list = profileList(kind), i;
        for (i = 0; i < list.length; i++) { if (list[i].id === id) { return list[i]; } }
        return null;
    }
    function savePreferences() {
        config.prompt = prompt; config.backend = backend;
        config.web_upload_mode = webUploadMode;
        config.selected_account_id = accountID; config.selected_api_id = apiID;
        var target = child(root, "config.json"), previous = child(root, "config.previous.json");
        var temp = child(root, "config.pending-" + makeName() + ".json"), existed = target.exists;
        writeText(temp, encodeJSON(config));
        if (previous.exists && !previous.remove()) { temp.remove(); fail("无法更新本机配置备份，请检查目录权限。"); }
        if (existed && !target.rename("config.previous.json")) { temp.remove(); fail("无法保存配置，请检查 config.json 是否被占用。"); }
        if (!temp.rename("config.json")) {
            if (existed) { previous.rename("config.json"); }
            temp.remove(); fail("配置保存失败，已尝试恢复原配置。");
        }
        if (previous.exists) { previous.remove(); }
    }
    function initProfiles() {
        if (config.accounts && !(config.accounts instanceof Array)) { fail("config.json 中 accounts 必须为数组，未覆盖已有配置。"); }
        if (config.apis && !(config.apis instanceof Array)) { fail("config.json 中 apis 必须为数组，未覆盖已有配置。"); }
        if (!config.accounts) { config.accounts = []; }
        if (!config.apis) { config.apis = []; }
        if (!config.profiles_migrated) {
            var legacy = child(root, "runtime/http-session.json"), infoFile = child(root, "runtime/http-account-info.json");
            if (!legacy.exists) { legacy = child(root, "runtime/browser-profile/accounts.json"); }
            if (legacy.exists) {
                try {
                    var legacySession = parseJSON(readText(legacy)), legacyInfo = {};
                    if (infoFile.exists) { try { legacyInfo = parseJSON(readText(infoFile)); } catch (ignoredOldInfo) {} }
                    var old = {id: "account-" + makeName(), name: legacyInfo.name || legacySession.name || "原有豆包账号", session: legacySession, info: legacyInfo};
                    config.accounts.push(old); config.selected_account_id = old.id;
                } catch (legacyError) {
                    notice = "旧版账号文件无法读取，已保留原文件；可在账号管理中重新扫码或手动导入，也可选择 API。";
                }
            }
            config.profiles_migrated = true;
        }
        backend = config.backend === "api" ? "api" : "web";
        webUploadMode = config.web_upload_mode === "merged" ? "merged" : "separate";
        accountID = config.selected_account_id || ""; apiID = config.selected_api_id || "";
        if (!findProfile("web", accountID)) { accountID = config.accounts.length ? config.accounts[0].id : ""; }
        if (!findProfile("api", apiID)) { apiID = config.apis.length ? config.apis[0].id : ""; }
        var p, normalized, mappedCount = 0;
        for (p = 0; p < config.apis.length; p++) {
            try {
                normalized = normalizeAPIProfile(config.apis[p]);
                if (normalized.model !== config.apis[p].model) { mappedCount++; }
                config.apis[p] = normalized;
            } catch (ignoredOldAPI) { /* Keep editable invalid configurations; generation preflight will explain. */ }
        }
        if (mappedCount) { notice = "已按原计费地址修正 " + mappedCount + " 项 API 模型名，接口地址和 Key 保持原值。"; }
        savePreferences();
    }
    function generationChoice() {
        var id = backend === "api" ? apiID : accountID, profile = findProfile(backend, id);
        if (!profile) { fail(backend === "api" ? "请先在“生成与账号”中新增并选择 API 配置。" : "请先在“生成与账号”中新增并选择豆包账号。"); }
        if (backend === "api") {
            if (!profile.api_key || !profile.model || !validEndpoint(profile.endpoint)) { fail("API 配置不完整，请在管理界面检查地址、Model ID 和 API Key。"); }
            profile = normalizeAPIProfile(profile);
        } else if (!profile.session) { fail("所选账号没有登录凭据，请重新扫码登录。"); }
        return {backend: backend, profile_id: id, profile: backend === "api" ? profile : profile.session};
    }
    function validEndpoint(value) { return /^https:\/\/[^\s\/?#@:]+(?::443)?\/[^\s?#]+$/.test(value || ""); }
    function apiEndpointMode(endpoint) {
        var parts = /^https:\/\/([^\/]+)(\/[^?#]*)$/.exec(endpoint || ""), host;
        if (!parts) { return "custom"; }
        host = parts[1].toLowerCase();
        if (host === "api.openai.com" || host === "api.openai.com:443" || host === "generativelanguage.googleapis.com" || host === "generativelanguage.googleapis.com:443") { return "standard"; }
        if (host === "ark.cn-beijing.volces.com" || host === "ark.cn-beijing.volces.com:443") {
            if (parts[2] === "/api/plan/v3/images/generations") { return "plan"; }
            if (parts[2] === "/api/v3/images/generations") { return "standard"; }
        }
        return "custom";
    }
    function normalizeAPIProfile(profile) {
        var result = parseJSON(encodeJSON(profile)), mode = apiEndpointMode(result.endpoint);
        result.protocol = result.protocol || "seedream";
        result.provider = result.provider || (result.protocol === "openai" ? "openai" : (result.protocol === "gemini" ? "gemini" : "seedream"));
        if (!/^(seedream|openai|gemini|grsai)$/.test(result.protocol) || !/^(seedream|openai|gemini)$/.test(result.provider) ||
                (result.protocol !== "grsai" && result.protocol !== result.provider) || (result.protocol === "grsai" && result.provider === "seedream")) { fail("服务与图片编辑协议不匹配。"); }
        if (!validEndpoint(result.endpoint)) { fail("请填写 HTTPS 完整接口地址，不包含查询参数。"); }
        if (!result.billing_mode) { result.billing_mode = mode; }
        if (result.billing_mode !== mode) { fail("API 类型与地址不匹配，请在管理 API 中核对计费类型和完整接口地址；没有切换计费入口。"); }
        var path = result.endpoint.replace(/^https:\/\/[^\/]+/, ""), host = result.endpoint.replace(/^https:\/\//, "").split("/")[0].toLowerCase().replace(/:443$/, "");
        var suffix = result.protocol === "seedream" ? "/images/generations" : (result.protocol === "openai" ? "/images/edits" : "/v1/api/generate");
        if (result.protocol === "gemini") {
            if (!/\/models\/[^\/]+:generateContent$/.test(path) || !/^[A-Za-z0-9_.-]{1,200}$/.test(result.model || "")) { fail("Gemini 地址应以 /models/{model}:generateContent 结尾，Model ID 仅用字母、数字、点、横线和下划线。"); }
            var pathModel = path.split("/models/").pop().replace(/:generateContent$/, "");
            if (pathModel !== "{model}" && pathModel !== result.model) { fail("Gemini 地址模型与 Model ID 不一致，请使用 {model} 占位符。"); }
        } else if (path.slice(-suffix.length) !== suffix) { fail("地址与图片编辑协议不匹配，应以 " + suffix + " 结尾。"); }
        if ((host === "ark.cn-beijing.volces.com" && result.protocol !== "seedream") || (host === "api.openai.com" && result.protocol !== "openai") ||
                (host === "generativelanguage.googleapis.com" && result.protocol !== "gemini")) { fail("官方地址与图片编辑协议不匹配。"); }
        result.auth_mode = result.auth_mode || (result.protocol === "gemini" && mode === "standard" ? "google" : "bearer");
        if (!/^(bearer|google)$/.test(result.auth_mode) || (result.protocol !== "gemini" && result.auth_mode !== "bearer") ||
                (mode === "standard" && result.auth_mode !== (result.protocol === "gemini" ? "google" : "bearer"))) { fail("认证方式与接口不匹配。"); }
        result.size = result.size || (result.provider === "seedream" ? "2K" : "auto");
        var sizes = result.provider === "seedream" ? ",1K,1.5K,2K," : (result.provider === "openai" ? ",auto,1024x1024,1536x1024,1024x1536," : ",auto,1K,2K,4K,");
        if (sizes.indexOf("," + result.size + ",") < 0) { fail("输出档位与所选服务不匹配，请重新选择。"); }
        result.quality = result.quality || "auto";
        if (!/^(auto|low|medium|high)$/.test(result.quality)) { fail("图片质量选项无效。"); }
        if (mode === "plan" && (result.model === "doubao-seedream-5-0-pro-260628" || result.model === "doubao-seedream-5.0-pro")) {
            result.model = "doubao-seedream-5-0-pro";
        } else if (mode === "standard" && (result.model === "doubao-seedream-5-0-pro" || result.model === "doubao-seedream-5.0-pro")) {
            result.model = "doubao-seedream-5-0-pro-260628";
        }
        if (mode === "plan" && /^doubao-seedream-.+-\d{6}$/.test(result.model || "")) {
            fail("Agent Plan 请填写套餐支持的模型名，并使用套餐专属 Key；不要混用普通 API 的日期版本模型 ID。");
        }
        return result;
    }
    function askName(title, initial) {
        var win = new Window("dialog", title), accepted = false;
        win.orientation = "column"; win.alignChildren = ["fill", "top"];
        win.add("statictext", undefined, "显示名称（便于区分账号或接口）：");
        var editor = win.add("edittext", undefined, initial); editor.characters = 40;
        var row = win.add("group"), ok = row.add("button", undefined, "保存"), back = row.add("button", undefined, "取消");
        ok.onClick = function () { accepted = true; win.close(1); };
        back.onClick = function () { win.close(1); };
        win.show();
        if (!accepted) { return null; }
        var name = editor.text.replace(/^\s+|\s+$/g, "");
        if (!name || name.length > 80) { fail("名称须为 1 至 80 个字符。"); }
        return name;
    }
    function editAPI(existing) {
        var win = new Window("dialog", existing ? "编辑 API 配置" : "新增 API 配置"), accepted = false;
        win.orientation = "column"; win.alignChildren = ["fill", "top"];
        function field(label, value, secret) {
            win.add("statictext", undefined, label);
            var control = win.add("edittext", undefined, value, secret ? {noecho: true} : {}); control.characters = 62; return control;
        }
        var initial = null;
        if (existing) {
            try { initial = normalizeAPIProfile(existing); }
            catch (editableOldProfile) {
                initial = parseJSON(encodeJSON(existing)); initial.protocol = initial.protocol || "seedream";
                initial.provider = initial.provider || (initial.protocol === "gemini" ? "gemini" : (initial.protocol === "openai" ? "openai" : "seedream"));
                initial.billing_mode = initial.billing_mode || apiEndpointMode(initial.endpoint); initial.auth_mode = initial.auth_mode || "bearer";
                initial.size = initial.size || (initial.provider === "seedream" ? "2K" : "auto");
            }
        }
        var name = field("名称", existing ? existing.name : "火山方舟 Seedream 5.0 Pro", false);
        win.add("statictext", undefined, "服务入口 / 计费来源（密钥必须属于该入口）：");
        var modes = ["standard", "plan", "custom"], initialMode = initial ? initial.billing_mode : "standard";
        var billingMode = win.add("dropdownlist", undefined, ["官方 API（按服务规则计费）", "Agent Plan（套餐）", "中转站 / 自定义接口"]);
        billingMode.selection = initialMode === "plan" ? 1 : (initialMode === "custom" ? 2 : 0);
        win.add("statictext", undefined, "服务与图片编辑协议：");
        var service = win.add("dropdownlist", undefined, ["Seedream / 火山方舟 JSON", "OpenAI 图片编辑（multipart）", "Nano Banana / Gemini generateContent", "Grsai 中转专用 JSON / GPT Image", "Grsai 中转专用 JSON / Nano Banana"]);
        var serviceIndex = initial ? (initial.protocol === "grsai" ? (initial.provider === "gemini" ? 4 : 3) : (initial.protocol === "openai" ? 1 : (initial.protocol === "gemini" ? 2 : 0))) : 0;
        service.selection = serviceIndex;
        var endpoint = field("完整接口网址（HTTPS，Gemini 可用 {model} 占位符）", existing ? existing.endpoint : "https://ark.cn-beijing.volces.com/api/v3/images/generations", false);
        var model = field("Model ID / Endpoint ID（以服务商已开通列表为准）", existing ? existing.model : "doubao-seedream-5-0-pro-260628", false);
        var key = field(existing ? "API Key（同入口、同地址、同协议时可留空保留）" : "API Key", "", true);
        var options = win.add("group"); options.add("statictext", undefined, "输出档位：");
        var size = options.add("dropdownlist", undefined, ["auto", "1K", "1.5K", "2K", "4K", "1024x1024", "1536x1024", "1024x1536"]);
        function selectSize(value) { var i; for (i = 0; i < size.items.length; i++) { if (size.items[i].text === value) { size.selection = i; return; } } size.selection = 0; }
        selectSize(initial ? initial.size : "2K");
        options.add("statictext", undefined, "质量：");
        var quality = options.add("dropdownlist", undefined, ["auto", "low", "medium", "high"]); quality.selection = 0;
        var qi; for (qi = 0; qi < quality.items.length; qi++) { if (initial && quality.items[qi].text === initial.quality) { quality.selection = qi; } }
        var authRow = win.add("group"); authRow.add("statictext", undefined, "认证：");
        var auth = authRow.add("dropdownlist", undefined, ["Bearer API Key", "x-goog-api-key（Gemini）"]); auth.selection = initial && initial.auth_mode === "google" ? 1 : 0;
        var hint = win.add("statictext", undefined, "", {multiline: true}); hint.preferredSize = [600, 72];
        function updateDefaults() {
            var route = billingMode.selection ? modes[billingMode.selection.index] : "standard", index = service.selection ? service.selection.index : 0;
            if (route === "plan" && index !== 0) { hint.text = "当前仅支持火山方舟图片 Agent Plan，请选择 Seedream。其他厂商的套餐需其提供可用图片编辑接口。"; return; }
            if (index >= 3 && route !== "custom") { hint.text = "Grsai 专用协议请选择“中转站 / 自定义接口”。"; return; }
            if (index === 0) {
                endpoint.text = route === "plan" ? "https://ark.cn-beijing.volces.com/api/plan/v3/images/generations" : (route === "standard" ? "https://ark.cn-beijing.volces.com/api/v3/images/generations" : "https://填写中转域名/images/generations");
                model.text = route === "plan" ? "doubao-seedream-5-0-pro" : "doubao-seedream-5-0-pro-260628"; selectSize("2K"); auth.selection = 0;
            } else if (index === 1) {
                endpoint.text = route === "standard" ? "https://api.openai.com/v1/images/edits" : "https://填写中转域名/v1/images/edits";
                model.text = "gpt-image-2"; selectSize("auto"); auth.selection = 0;
            } else if (index === 2) {
                endpoint.text = route === "standard" ? "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent" : "https://填写中转域名/v1beta/models/{model}:generateContent";
                model.text = "gemini-3.1-flash-image"; selectSize("auto"); auth.selection = route === "standard" ? 1 : 0;
            } else {
                endpoint.text = "https://grsaiapi.com/v1/api/generate"; model.text = index === 3 ? "gpt-image-2.6" : "nano-banana-2"; selectSize(index === 3 ? "1024x1024" : "1K"); auth.selection = 0;
            }
            hint.text = "已填入所选入口示例，请核对模型权限和完整地址。保存不会生成或验证额度。切换入口、协议或地址须重新填写 Key。";
        }
        billingMode.onChange = updateDefaults; service.onChange = updateDefaults;
        hint.text = "Seedream：1K / 1.5K / 2K；OpenAI：auto 或像素尺寸；Gemini：auto / 1K / 2K / 4K。\n质量仅用于 OpenAI / Grsai GPT。输出最终恢复原图层尺寸。\n按所选服务的账号、模型和入口计费；套餐与普通 API 不会自动互换。";
        var row = win.add("group"), ok = row.add("button", undefined, "保存"), back = row.add("button", undefined, "取消");
        ok.onClick = function () { accepted = true; win.close(1); };
        back.onClick = function () { win.close(1); };
        win.show();
        if (!accepted) { return null; }
        var index = service.selection ? service.selection.index : 0;
        var result = {id: existing ? existing.id : "api-" + makeName(), name: name.text.replace(/^\s+|\s+$/g, ""),
            endpoint: endpoint.text.replace(/^\s+|\s+$/g, ""), model: model.text.replace(/^\s+|\s+$/g, ""),
            api_key: key.text.replace(/^\s+|\s+$/g, "") || (existing ? existing.api_key : ""), size: size.selection ? size.selection.text : "auto",
            protocol: index === 0 ? "seedream" : (index === 1 ? "openai" : (index === 2 ? "gemini" : "grsai")),
            provider: index === 0 ? "seedream" : (index === 1 || index === 3 ? "openai" : "gemini"),
            auth_mode: auth.selection && auth.selection.index === 1 ? "google" : "bearer", quality: quality.selection ? quality.selection.text : "auto",
            billing_mode: billingMode.selection ? modes[billingMode.selection.index] : "standard"};
        if (!result.name || result.name.length > 80 || !validEndpoint(result.endpoint) || !result.model || !result.api_key || /\s/.test(result.api_key) || /填写/.test(result.endpoint)) {
            fail("配置未保存。请填写名称、HTTPS 完整接口地址、Model ID 和有效 API Key。");
        }
        if (existing && (result.billing_mode !== initialMode || result.endpoint !== existing.endpoint || result.protocol !== initial.protocol || result.provider !== initial.provider || result.auth_mode !== initial.auth_mode) && !key.text.replace(/\s/g, "")) {
            fail("切换计费类型、协议或网址时，请重新填写目标类型对应的 API Key。原配置未修改。");
        }
        return normalizeAPIProfile(result);
    }
    function applyAccountResult(task, targetID, displayName) {
        var file = child(task, "account-result.json");
        if (!file.exists) { return; }
        var result = parseJSON(readText(file)), existing = findProfile("web", targetID);
        if (!result.session || !result.info) { fail("账号结果不完整，未修改已保存账号。"); }
        var entry = existing || {id: "account-" + makeName(), name: displayName || result.info.name || "豆包账号"};
        entry.session = result.session; entry.info = result.info;
        if (!existing) { config.accounts.push(entry); }
        accountID = entry.id; backend = "web"; savePreferences();
        file.remove();
    }
    function manageProfiles(kind) {
        var keepOpen = true, selectedID = kind === "api" ? apiID : accountID;
        while (keepOpen) {
            var list = profileList(kind), win = new Window("dialog", kind === "api" ? "管理 API 配置" : "管理豆包账号");
            var action = "back", chosen = -1, i;
            win.orientation = "column"; win.alignChildren = ["fill", "top"];
            win.add("statictext", undefined, kind === "api" ? "新增或编辑接口、密钥与模型；生成只使用选中的一项。" : "扫码新增账号，或选中已有账号检查、重新登录、改名和删除。");
            var listing = win.add("listbox", undefined, [], {multiselect: false}); listing.preferredSize = [660, 210];
            for (i = 0; i < list.length; i++) {
                listing.add("item", list[i].name + (kind === "api" ? "  ·  " +
                    ((list[i].billing_mode || apiEndpointMode(list[i].endpoint)) === "plan" ? "Agent Plan" :
                    ((list[i].billing_mode || apiEndpointMode(list[i].endpoint)) === "standard" ? "普通 API" : "自定义接口")) +
                    "  ·  " + (list[i].protocol || "seedream") + "  ·  " + list[i].model : "  ·  " + (list[i].info ? list[i].info.message : "尚未检查连接")));
                if (list[i].id === selectedID) { chosen = i; }
            }
            if (list.length) { listing.selection = chosen >= 0 ? chosen : 0; }
            var row = win.add("group"), row2 = win.add("group");
            function addButton(parent, title, value, enabled) {
                var control = parent.add("button", undefined, title); control.enabled = enabled;
                control.onClick = function () { action = value; chosen = listing.selection ? listing.selection.index : -1; win.close(1); };
            }
            addButton(row, kind === "api" ? "新增 API" : "新增账号（扫码）", "add", true);
            addButton(row, kind === "api" ? "编辑配置" : "重新扫码登录", "edit", list.length > 0);
            if (kind === "web") { addButton(row, "检查连接", "check", list.length > 0); addButton(row, "导入账号资料", "import", true); }
            addButton(row2, "选用此项", "select", list.length > 0);
            if (kind === "web") { addButton(row2, "改名", "rename", list.length > 0); }
            addButton(row2, "删除", "delete", list.length > 0); addButton(row2, "返回", "back", true);
            win.add("statictext", undefined, "删除仅移除本机保存项，不注销云端账号。已提交批次继续使用提交时的配置。", {multiline: true});
            win.show();
            var existing = chosen >= 0 && chosen < list.length ? list[chosen] : null, edited, name, selected;
            if (existing) { selectedID = existing.id; }
            if (action === "back") { keepOpen = false; }
            else if (action === "select" && existing) {
                if (kind === "api") { apiID = existing.id; } else { accountID = existing.id; }
                backend = kind; savePreferences(); notice = "已选用：" + existing.name; keepOpen = false;
            } else if (kind === "api" && (action === "add" || action === "edit")) {
                edited = editAPI(action === "edit" ? existing : null);
                if (edited) {
                    if (action === "edit") { list[chosen] = edited; } else { list.push(edited); }
                    selectedID = edited.id; apiID = edited.id; backend = "api"; savePreferences();
                }
            } else if (kind === "web" && (action === "add" || action === "edit")) {
                name = action === "add" ? askName("新增豆包账号", "豆包账号 " + (list.length + 1)) : existing.name;
                if (name !== null) { accountOperation("login", action === "edit" ? existing.id : "", name); selectedID = accountID; }
            } else if (action === "check" && existing) { accountOperation("check", existing.id, existing.name); }
            else if (action === "import") {
                selected = File.openDialog("选择豆包账号会话 JSON（不会打开浏览器）", "JSON:*.json", false);
                if (selected) {
                    name = askName("导入豆包账号", "导入账号 " + (list.length + 1));
                    if (name !== null) { accountOperation("check", "", name, parseJSON(readText(selected))); selectedID = accountID; }
                }
            } else if (action === "rename" && existing) {
                name = askName("账号改名", existing.name);
                if (name !== null) { existing.name = name; savePreferences(); }
            } else if (action === "delete" && existing) {
                if (confirm("删除本机保存的“" + existing.name + "”？\n已提交批次继续使用快照；云端账号不会注销。")) {
                    list.splice(chosen, 1);
                    if (kind === "api" && apiID === existing.id) { apiID = list.length ? list[0].id : ""; }
                    if (kind === "web" && accountID === existing.id) { accountID = list.length ? list[0].id : ""; }
                    savePreferences(); selectedID = "";
                }
            }
        }
    }

    function accountOperation(kind, targetID, displayName, importData) {
        var task = new Folder(root.fsName + "/runtime/jobs/" + new Date().getTime() + "-" + Math.floor(Math.random() * 1000000));
        ensureFolder(task);
        var chosenAccount = findProfile("web", targetID || accountID);
        if (kind === "check") {
            if (!importData && !chosenAccount) { fail("请先新增或选择豆包账号。"); }
            writeText(child(task, "account-session.json"), encodeJSON(importData || chosenAccount.session));
        }
        writeText(child(task, "request.json"), encodeJSON({kind: kind, managed: true, started_ms: new Date().getTime()}));
        var started = new Date().getTime(), state = null, action, win, info, qr, buttons, refreshButton, backButton;
        var terminal = false, launchOK = false;
        try {
            launchWorker(pythonw, worker, task); launchOK = true;
            while (true) {
                state = {state: "starting", message: kind === "login" ? "正在获取二维码，请稍后点击刷新登录状态。" : "正在检查连接，请稍后点击刷新检查状态。"};
                if (child(task, "status.json").exists) { state = parseJSON(readText(child(task, "status.json"))); }
                if (child(task, "launch-error.txt").exists) { state = {state: "error", message: "后台启动失败，请运行 install.cmd，并检查 Windows Script Host。"}; }
                terminal = state.state === "done" || state.state === "error" || state.state === "cancelled" || state.state === "unverified";
                if (!terminal && new Date().getTime() - started > (kind === "login" ? 150000 : 50000)) {
                    writeText(child(task, "cancel.flag"), "cancelled");
                    state = {state: "error", message: "登录或检查已超时。请返回后重新操作；不会自动重试。"}; terminal = true;
                }
                win = new Window("dialog", kind === "login" ? "豆包账号 · 手机扫码登录" : "豆包账号 · 检查连接");
                win.orientation = "column"; win.alignChildren = ["fill", "top"];
                win.add("statictext", undefined, kind === "login" ? "电脑不打开浏览器。请用手机豆包扫描二维码，并在手机确认登录。" : "检查现有账号，不上传图片、不发起生成。");
                info = win.add("edittext", undefined, state.message || "处理中……", {multiline: true, readonly: true, scrolling: true});
                info.preferredSize = [540, 85];
                if (kind === "login" && !terminal && child(task, "qrcode.png").exists) {
                    try { qr = win.add("image", undefined, child(task, "qrcode.png")); qr.preferredSize = [256, 256]; }
                    catch (expiredImage) { win.add("statictext", undefined, "二维码状态刚有更新，请点击刷新。"); }
                } else if (kind === "login" && !terminal) {
                    win.add("statictext", undefined, "二维码准备中，等待几秒后点击“刷新登录状态”。");
                }
                if (!terminal) { win.add("statictext", undefined, "二维码约两分钟有效；返回主窗口将取消未完成的登录或检查。"); }
                buttons = win.add("group"); action = "back";
                refreshButton = buttons.add("button", undefined, kind === "login" ? "刷新登录状态" : "刷新检查状态");
                refreshButton.enabled = !terminal;
                refreshButton.onClick = function () { action = "refresh"; win.close(1); };
                backButton = buttons.add("button", undefined, "返回主窗口");
                backButton.onClick = function () { action = "back"; win.close(1); };
                win.show();
                if (action === "back") {
                    if (child(task, "status.json").exists) {
                        state = parseJSON(readText(child(task, "status.json")));
                        terminal = state.state === "done" || state.state === "error" || state.state === "cancelled" || state.state === "unverified";
                    }
                    if (!terminal) { writeText(child(task, "cancel.flag"), "cancelled"); }
                    if (terminal) { applyAccountResult(task, targetID || "", displayName || "豆包账号"); }
                    notice = terminal ? state.message : "已取消未完成的登录或检查，原有账号保留。";
                    return;
                }
            }
        } finally {
            if (launchOK && !terminal) { try { writeText(child(task, "cancel.flag"), "cancelled"); } catch (ignoredCancel) {} }
        }
    }
    function showUI(state) {
        var action = "close", win = new Window("dialog", "豆包去字 v6.5.1");
        requestedIndex = currentIndex;
        win.orientation = "column"; win.alignChildren = ["fill", "top"];
        var overall = batchStatus(), active = batchIsRunning(), saved = currentIndex, snapshots = [], i, info, item;
        var counts = {done: 0, error: 0, imported: 0, waiting: 0};
        var labels = {done: "待导入", error: "失败", cancelled: "已取消", imported: "已导入", generating: "生成中", resolving: "解析附件", uploading: "上传中", starting: "启动中", downloading: "下载中", restoring: "恢复尺寸", queued: "等待中", mapping: "待核对图片"};
        for (i = 0; i < entries.length; i++) {
            bindEntry(i); info = statusNow(); snapshots.push(info);
            if (info && info.state === "done") { counts.done++; }
            else if (info && info.state === "error") { counts.error++; }
            else if (info && info.state === "imported") { counts.imported++; }
            else { counts.waiting++; }
        }
        bindEntry(saved);
        var summary = "共 " + entries.length + " 层  ·  待导入 " + counts.done + "  ·  已导入 " + counts.imported + "  ·  失败 " + counts.error;
        win.add("statictext", undefined, entries.length ? summary : "列表为空，请先读取 Photoshop 中选中的图片图层。");
        var tabs = win.add("tabbedpanel"); tabs.preferredSize = [760, 465]; tabs.alignChildren = ["fill", "fill"];
        var layerTab = tabs.add("tab", undefined, "图层与结果"), settingsTab = tabs.add("tab", undefined, "生成与账号"), toolsTab = tabs.add("tab", undefined, "日志与历史");
        var tabList = [layerTab, settingsTab, toolsTab];
        for (i = 0; i < tabList.length; i++) { tabList[i].orientation = "column"; tabList[i].alignChildren = ["fill", "top"]; tabList[i].margins = 12; tabList[i].spacing = 6; }
        var toolbar = layerTab.add("group");
        var listing = layerTab.add("listbox", undefined, [], {multiselect: true, numberOfColumns: 4, showHeaders: true,
            columnTitles: ["原图层", "尺寸（像素）", "状态", "图层 ID"], columnWidths: [320, 130, 105, 105]});
        listing.preferredSize = [725, 160];
        for (i = 0; i < entries.length; i++) {
            info = snapshots[i]; item = listing.add("item", entries[i].source_layer_name);
            item.subItems[0].text = entries[i].width + " × " + entries[i].height;
            item.subItems[1].text = info ? (labels[info.state] || "处理中") : "未提交";
            item.subItems[2].text = String(entries[i].source_layer_id);
        }
        if (entries.length) {
            var restored = [];
            for (i = 0; i < selectedRowIndices.length; i++) {
                if (selectedRowIndices[i] >= 0 && selectedRowIndices[i] < entries.length) { restored.push(selectedRowIndices[i]); }
            }
            listing.selection = restored.length ? restored : [currentIndex];
        }
        var detail = layerTab.add("group"); detail.orientation = "row"; detail.alignChildren = ["fill", "top"];
        var detailText = detail.add("edittext", undefined, "", {multiline: true, readonly: true, scrolling: true});
        detailText.preferredSize = [400, 190];
        var previewPanel = detail.add("panel", undefined, entries.length ? "预览：" + entries[currentIndex].source_layer_name : "结果预览");
        previewPanel.preferredSize = [310, 190];
        if (state && state.state === "done" && child(job, "preview.png").exists) {
            var preview = previewPanel.add("image", undefined, child(job, "preview.png")); preview.preferredSize = [285, 155];
        } else { previewPanel.add("statictext", undefined, entries.length ? "选择图层后点“查看所选预览”" : "生成完成后可查看图片"); }
        function selectedDetails() {
            var indices = listIndices(listing), first = indices.length ? indices[0] : -1;
            if (first < 0) { detailText.text = "请选择列表中的图层。按住 Ctrl 可选择多个失败图层重试。"; return; }
            var entry = entries[first], row = snapshots[first];
            detailText.text = "已选择 " + indices.length + " 层\n" + entry.source_layer_name + "  [ID " + entry.source_layer_id + "]\n" +
                (row ? row.message : "尚未提交。请点击下方“开始生成”。") +
                "\n\n结果对应提交时的内容与位置。修改像素、蒙版或样式后，请重新生成；位置或尺寸改变会阻止旧结果导入。";
        }
        listing.onChange = selectedDetails; selectedDetails();
        layerTab.add("statictext", undefined, "重试会重新导出原图层当前内容；只重试失败项，成功结果和导入记录继续保留。");
        settingsTab.add("statictext", undefined, "去字要求（开始生成或重试时使用）：");
        var editor = settingsTab.add("edittext", undefined, prompt, {multiline: true, scrolling: true}); editor.preferredSize = [720, 90];
        var providerRow = settingsTab.add("group");
        providerRow.add("statictext", undefined, "生成方式：");
        var provider = providerRow.add("dropdownlist", undefined, ["豆包网页账号", "API 接口"]); provider.selection = backend === "api" ? 1 : 0;
        var uploadRow = settingsTab.add("group"); uploadRow.add("statictext", undefined, "网页上传逻辑：");
        var uploadMode = uploadRow.add("dropdownlist", undefined, ["区分：每图层新建一个对话", "合并：全部附件一次提交到一个对话"]); uploadMode.selection = webUploadMode === "merged" ? 1 : 0;
        var accountPanel = settingsTab.add("panel", undefined, "账号与接口选择"); accountPanel.orientation = "column"; accountPanel.alignChildren = ["fill", "top"];
        accountPanel.margins = 10; accountPanel.spacing = 6;
        var webRow = accountPanel.add("group"), apiRow = accountPanel.add("group"), k;
        webRow.add("statictext", undefined, "豆包账号：");
        var accountPicker = webRow.add("dropdownlist", undefined, []);
        accountPicker.preferredSize = [420, 25];
        for (k = 0; k < config.accounts.length; k++) { accountPicker.add("item", config.accounts[k].name); if (config.accounts[k].id === accountID) { accountPicker.selection = k; } }
        if (!config.accounts.length) { accountPicker.add("item", "请先新增豆包账号"); accountPicker.selection = 0; }
        apiRow.add("statictext", undefined, "API 配置：");
        var apiPicker = apiRow.add("dropdownlist", undefined, []);
        apiPicker.preferredSize = [420, 25];
        for (k = 0; k < config.apis.length; k++) { apiPicker.add("item", config.apis[k].name); if (config.apis[k].id === apiID) { apiPicker.selection = k; } }
        if (!config.apis.length) { apiPicker.add("item", "请先新增 API 配置"); apiPicker.selection = 0; }
        var accountButtons = accountPanel.add("group"), apiButtons = accountButtons;
        var settingsHint = settingsTab.add("statictext", undefined, "", {multiline: true}); settingsHint.preferredSize = [710, 50];
        function updateProvider() {
            var useAPI = provider.selection && provider.selection.index === 1;
            webRow.enabled = !useAPI && !active; apiRow.enabled = !!useAPI && !active;
            uploadRow.enabled = !useAPI && !active;
            settingsHint.text = useAPI ? "API 按所选服务计费；不使用豆包网页 Cookie，不启动浏览器。\n每层通过图片编辑协议发送一张原图；返回后恢复原尺寸和透明度。" :
                "合并：集中上传后只提交一次，返回数量由豆包决定；结束后需核对图片对应。\n区分：每层独立对话。两种模式均不启动浏览器。";
        }
        provider.enabled = !active; provider.onChange = updateProvider; updateProvider();
        var prefsButtons = settingsTab.add("group");
        toolsTab.add("statictext", undefined, "诊断日志：后台自动记录，导出包不含账号、图片、提示词或下载链接。");
        var logButtons = toolsTab.add("group");
        toolsTab.add("statictext", undefined, "历史任务：清空列表后仍可重新打开旧批次；图片、日志与账号均保留。");
        var historyButtons = toolsTab.add("group");
        var alignmentHint = toolsTab.add("edittext", undefined,
            "原图层修改与对齐\n\n改名、调整图层顺序：继续按图层 ID 对应。\n移动、缩放、旋转、改变像素边界：旧结果停止导入。\n像素、蒙版、样式等内容改变但边界不变：无法单凭边界检测，旧结果仍对应旧内容，请重新生成。\n删除原图层、关闭重开 PSD：原 ID 可能失效，不会导入其他图层。\n\n清空只清理当前列表，不会取消正在运行的任务；请先取消并等待任务结束。",
            {multiline: true, readonly: true, scrolling: true}); alignmentHint.preferredSize = [720, 235];
        var footer = win.add("group"), closeRow = win.add("group");
        var text = notice || ((overall ? overall.message + "\n" : "") + (state ? state.message : "请在“生成与账号”选择所用账号或 API，然后开始生成。"));
        var statusLabel = win.add("edittext", undefined, text, {multiline: true, readonly: true, scrolling: true}); statusLabel.preferredSize = [760, 48];
        function button(row, title, value, enabled) {
            var btn = row.add("button", undefined, title);
            btn.enabled = enabled;
            btn.onClick = function () {
                prompt = editor.text; requestedIndices = listIndices(listing); selectedRowIndices = requestedIndices;
                requestedIndex = requestedIndices.length ? requestedIndices[0] : currentIndex;
                uiTab = tabs.selection === settingsTab ? 1 : (tabs.selection === toolsTab ? 2 : 0); action = value; win.close(1);
            };
        }
        button(toolbar, "读取 PS 所选图层", "newselection", !active);
        button(toolbar, "查看所选预览 / 进度", "view", entries.length > 0);
        button(toolbar, "清空当前批次", "clear", !active && entries.length > 0);
        button(footer, "开始生成", "generate", !active && entries.length > 0 && !batchFolder && !job);
        button(footer, "导入全部成功结果", "importall", !active && counts.done > 0);
        button(toolbar, "核对合并结果", "mapmerged", !active && !!overall && overall.state === "review");
        button(footer, "重试所选失败", "retryselected", !active && counts.error > 0);
        button(footer, "重试全部失败", "retryall", !active && counts.error > 0);
        button(accountButtons, "管理豆包账号（新增 / 删除 / 登录）", "manageweb", !active);
        button(apiButtons, "管理 API（新增 / 编辑 / 删除）", "manageapi", !active);
        button(prefsButtons, "保存提示词与当前选择", "saveprefs", true);
        button(logButtons, "查看所选日志", "logs", !!job);
        button(logButtons, "导出日志 ZIP", "exportlogs", !!batchFolder || !!job);
        button(historyButtons, "打开历史批次", "history", !active);
        button(historyButtons, "找回单张结果", "recover", !active && entries.length === 1);
        button(historyButtons, "找回 / 下载所选结果", "downloadresult", !active && !!batchFolder && entries.length > 0);
        button(closeRow, "取消批次", "cancel", !!active);
        button(closeRow, active ? "后台等待，结束时提示" : "关闭", "close", true);
        tabs.selection = tabList[uiTab] || layerTab;
        win.show();
        prompt = editor.text;
        backend = provider.selection && provider.selection.index === 1 ? "api" : "web";
        webUploadMode = uploadMode.selection && uploadMode.selection.index === 1 ? "merged" : "separate";
        if (accountPicker.selection && config.accounts[accountPicker.selection.index]) { accountID = config.accounts[accountPicker.selection.index].id; }
        if (apiPicker.selection && config.apis[apiPicker.selection.index]) { apiID = config.apis[apiPicker.selection.index].id; }
        return action;
    }
    function listIndices(listing) {
        var selected = listing.selection, indices = [], i;
        if (!selected) { return indices; }
        if (selected instanceof Array) {
            for (i = 0; i < selected.length; i++) { indices.push(selected[i].index); }
        } else { indices.push(selected.index); }
        return indices;
    }
    function openHistory() {
        var folder = new Folder(root.fsName + "/runtime/batches"), folders = folder.getFiles(), rows = [], i, manifest, status;
        folders.sort(function (a, b) { return Number(b.name.split("-")[0]) - Number(a.name.split("-")[0]); });
        for (i = 0; i < folders.length && rows.length < 100; i++) {
            if (!(folders[i] instanceof Folder) || !/^[0-9]+-[0-9]+$/.test(folders[i].name)) { continue; }
            try {
                manifest = parseJSON(readText(child(folders[i], "request.json")));
                if (manifest.document_id !== originalDoc.id || !manifest.items || !manifest.items.length) { continue; }
                status = child(folders[i], "status.json").exists ? parseJSON(readText(child(folders[i], "status.json"))) : null;
                rows.push({folder: folders[i], title: new Date(Number(manifest.started_ms)).toLocaleString() + "  ·  " + manifest.items.length + " 层  ·  " +
                    (status ? status.message : "尚无状态记录")});
            } catch (ignoredHistory) {}
        }
        if (!rows.length) { fail("当前 PSD 会话没有可打开的历史批次。若 PSD 已关闭重开，请选中对应单层后使用“找回单张结果”。"); }
        var win = new Window("dialog", "打开历史批次"), chosen = -1;
        win.orientation = "column"; win.alignChildren = ["fill", "top"];
        win.add("statictext", undefined, "仅列出当前 PSD 会话的最近 100 个批次；打开后不会重新生成。");
        var list = win.add("listbox", undefined, [], {multiselect: false}); list.preferredSize = [700, 260];
        for (i = 0; i < rows.length; i++) { list.add("item", rows[i].title); }
        list.selection = 0;
        var group = win.add("group"), open = group.add("button", undefined, "打开"), close = group.add("button", undefined, "返回");
        open.onClick = function () { chosen = list.selection ? list.selection.index : -1; win.close(1); };
        close.onClick = function () { win.close(1); };
        win.show();
        if (chosen >= 0) {
            readBatch(rows[chosen].folder);
            var dismissed = child(batchFolder, "dismissed.flag"), cleared = child(root, "runtime/ui-cleared-" + originalDoc.id + ".json");
            if (dismissed.exists && !dismissed.remove()) { fail("无法重新启用此历史批次的完成提示，请检查目录权限。"); }
            if (cleared.exists && !cleared.remove()) { fail("无法恢复当前历史批次窗口，请检查目录权限。"); }
            uiTab = 0; notice = "已打开历史批次；不会重复生成或导入已有结果。";
        }
    }
    function recordPS(kind, extra) {
        if (!job) { return; }
        try {
            var file = child(job, "ps-events.jsonl");
            file.encoding = "UTF-8";
            if (file.open("a")) {
                try { file.writeln(encodeJSON({time_ms: new Date().getTime(), version: "6.5.1", kind: kind,
                    source_layer_id: entries[currentIndex].source_layer_id,
                    line: extra && extra.line ? Number(extra.line) : 0, placed: !!(extra && extra.placed)})); }
                finally { file.close(); }
            }
        } catch (ignoredLog) {}
    }
    function showLogs() {
        var win = new Window("dialog", "豆包去字 v6.5.1 · 日志"), text = [], file, i;
        win.orientation = "column"; win.alignChildren = ["fill", "top"];
        text.push("日志在后台自动记录。这里显示打开时的快照；批次结束会另行提示。\n");
        text.push("当前图层 ID：" + entries[currentIndex].source_layer_id);
        if (batchFolder) {
            text.push("批次：" + batchFolder.name);
            file = child(batchFolder, "worker.log");
            if (file.exists) { text.push("\n批次进度：\n" + readText(file).slice(-16000)); }
        }
        if (job) {
            text.push("\n当前任务：" + job.name);
            var names = ["worker.log", "diagnostic.json", "ps-events.jsonl", "import-error.json"];
            for (i = 0; i < names.length; i++) {
                file = child(job, names[i]);
                if (file.exists) { text.push("\n" + names[i] + "：\n" + readText(file).slice(-16000)); }
            }
            if (!child(job, "diagnostic.json").exists) { text.push("\n旧版本未记录接口结构计数；本版新任务会自动记录。"); }
        }
        var editor = win.add("edittext", undefined, text.join("\n"), {multiline: true, readonly: true, scrolling: true});
        editor.preferredSize = [650, 440];
        var group = win.add("group"), exportButton = group.add("button", undefined, "导出日志 ZIP"), back = group.add("button", undefined, "返回");
        var exportRequested = false;
        exportButton.onClick = function () { exportRequested = true; win.close(1); };
        back.onClick = function () { win.close(1); };
        win.show();
        if (exportRequested) { exportLogs(); }
    }
    function exportLogs() {
        if (!batchFolder && !job) { fail("没有已提交的任务可导出。"); }
        var folder = new Folder(root.fsName + "/runtime/exports"); ensureFolder(folder);
        var suggested = new File(folder.fsName + "/doubao-logs-" + (batchFolder ? batchFolder.name : job.name) + ".zip");
        var output = suggested.saveDlg("导出诊断日志（不含账号、图片或提示词）", "ZIP:*.zip");
        if (!output) { return; }
        if (!/\.zip$/i.test(output.name)) { output = new File(output.fsName + ".zip"); }
        var task = new Folder(root.fsName + "/runtime/support_jobs/" + makeName()); ensureFolder(task);
        var request = {output: output.fsName};
        if (batchFolder) { request.batch_name = batchFolder.name; } else { request.job_name = job.name; }
        writeText(child(task, "request.json"), encodeJSON(request));
        launchWorker(pythonw, child(root, "support_logs.py"), task);
        notice = "日志正在本机打包，完成或失败时会显示 Windows 提示。不会联网或重新生成。";
    }
    function recordActive() {
        writeText(child(root, "runtime/active-http-job.json"), '{"job_name":' + quote(job.name) + '}');
    }
    function readRequest(folder) {
        var request = parseJSON(readText(child(folder, "request.json")));
        if (request.width !== width || request.height !== height || request.left !== box[0] || request.top !== box[1]) {
            fail("此任务的尺寸或位置与当前图层不同。请选择对应原图层后再找回。");
        }
        return request;
    }
    function resumeActive() {
        var activeFile = child(root, "runtime/active-http-job.json");
        if (!activeFile.exists) { return; }
        try {
            var data = parseJSON(readText(activeFile));
            if (!/^[0-9]+-[0-9]+$/.test(data.job_name)) { return; }
            var folder = new Folder(root.fsName + "/runtime/jobs/" + data.job_name);
            if (child(folder, "dismissed.flag").exists) { return; }
            var request = readRequest(folder);
            if (request.batch_name && /^[0-9]+-[0-9]+$/.test(request.batch_name) &&
                    child(new Folder(root.fsName + "/runtime/batches/" + request.batch_name), "dismissed.flag").exists) { return; }
            if (request.document_id === originalDoc.id && request.source_layer_id === originalLayer.id &&
                    !child(folder, "imported.flag").exists) { job = folder; }
        } catch (ignored) {}
    }
    function batchStatus() {
        if (!batchFolder) { return null; }
        if (child(batchFolder, "status.json").exists) {
            try { return parseJSON(readText(child(batchFolder, "status.json"))); } catch (ignored) {}
        }
        if (child(batchFolder, "launch-error.txt").exists) { return {state: "error", message: "无法启动批次后台程序，请检查 Windows Script Host。"}; }
        return {state: "starting", message: "后台批次正在启动，结束后会自动提示。"};
    }
    function batchIsRunning() {
        var state = batchStatus();
        if (state) { return state.state === "starting" || state.state === "running"; }
        var single = statusNow();
        return !!single && single.state !== "done" && single.state !== "error" && single.state !== "cancelled" && single.state !== "imported";
    }
    function hasReadyResults() {
        var saved = currentIndex, i, ready = false, state;
        for (i = 0; i < entries.length; i++) {
            bindEntry(i); state = statusNow(); if (state && state.state === "done") { ready = true; }
        }
        bindEntry(saved); return ready;
    }
    function readBatch(folder) {
        if (folder.parent.fsName !== new Folder(root.fsName + "/runtime/batches").fsName || !/^[0-9]+-[0-9]+$/.test(folder.name)) { fail("批次目录无效。"); }
        var data = parseJSON(readText(child(folder, "request.json"))), seen = {}, i, item, req;
        if (data.schema !== 1 || data.document_id !== originalDoc.id || !data.items || !data.items.length || data.items.length > 500) {
            fail("批次与当前 PSD 不对应。请打开原文档；结果文件仍保存在本机。");
        }
        for (i = 0; i < data.items.length; i++) {
            item = data.items[i];
            if (!/^[0-9]+-[0-9]+$/.test(item.job_name) || seen["layer" + item.source_layer_id] || seen["job" + item.job_name]) { fail("批次图层记录重复或无效。"); }
            req = parseJSON(readText(child(new Folder(root.fsName + "/runtime/jobs/" + item.job_name), "request.json")));
            var expectedBatch = item.carried === true ? item.carried_from_batch : folder.name;
            if (!/^[0-9]+-[0-9]+$/.test(expectedBatch)) { fail("任务来源批次编号无效。"); }
            if (item.carried === true) {
                var sourceManifest = parseJSON(readText(child(new Folder(root.fsName + "/runtime/batches/" + expectedBatch), "request.json")));
                var sourceFound = false, sourceIndex;
                if (sourceManifest.document_id !== originalDoc.id) { fail("沿用结果来源文档不一致。"); }
                for (sourceIndex = 0; sourceIndex < sourceManifest.items.length; sourceIndex++) {
                    if (sourceManifest.items[sourceIndex].job_name === item.job_name && sourceManifest.items[sourceIndex].source_layer_id === item.source_layer_id) { sourceFound = true; break; }
                }
                if (!sourceFound || expectedBatch === folder.name) { fail("沿用结果的来源批次记录不一致。"); }
            }
            if (req.document_id !== originalDoc.id || req.source_layer_id !== item.source_layer_id || req.batch_name !== expectedBatch ||
                    req.width !== item.width || req.height !== item.height || req.left !== item.left || req.top !== item.top ||
                    !item.raw_bounds || item.raw_bounds.length !== 4 || !req.raw_bounds || !sameBox(req.raw_bounds, item.raw_bounds)) {
                fail("批次与单层任务记录不一致，已停止以免错配。");
            }
            seen["layer" + item.source_layer_id] = true; seen["job" + item.job_name] = true;
        }
        entries = data.items; batchFolder = folder; selectedRowIndices = []; bindEntry(0);
    }
    function resumeActiveBatch() {
        var file = child(root, "runtime/active-http-batch.json"), data, folder, manifest, i, j;
        if (!file.exists) { return false; }
        try {
            data = parseJSON(readText(file)); if (!/^[0-9]+-[0-9]+$/.test(data.batch_name)) { return false; }
            folder = new Folder(root.fsName + "/runtime/batches/" + data.batch_name);
            if (child(folder, "dismissed.flag").exists) { return false; }
            manifest = parseJSON(readText(child(folder, "request.json")));
            if (manifest.document_id !== originalDoc.id) { return false; }
            for (i = 0; i < selectedIDsAtOpen.length; i++) {
                for (j = 0; j < manifest.items.length; j++) {
                    if (manifest.items[j].source_layer_id === selectedIDsAtOpen[i]) { readBatch(folder); return true; }
                }
            }
        } catch (ignored) {}
        return false;
    }
    function makeName() { return new Date().getTime() + "-" + Math.floor(Math.random() * 1000000); }
    function clearCurrentBatch() {
        if (batchIsRunning()) { fail("请先取消批次并等待任务结束，再清空列表。"); }
        var file, data;
        if (batchFolder) {
            writeText(child(batchFolder, "dismissed.flag"), "cleared from UI; files retained");
            file = child(root, "runtime/active-http-batch.json");
            if (file.exists) { data = parseJSON(readText(file)); if (data.batch_name === batchFolder.name && !file.remove()) { fail("无法清除当前批次记录。"); } }
        } else if (job) { writeText(child(job, "dismissed.flag"), "cleared from UI; files retained"); }
        file = child(root, "runtime/active-http-job.json");
        if (file.exists) {
            data = parseJSON(readText(file));
            for (var i = 0; i < entries.length; i++) { if (data.job_name === entries[i].job_name) { file.remove(); break; } }
        }
        writeText(child(root, "runtime/ui-cleared-" + originalDoc.id + ".json"), encodeJSON({document_id: originalDoc.id, cleared_ms: new Date().getTime()}));
        entries = []; batchFolder = null; selectedRowIndices = []; requestedIndices = []; requestedIndex = 0; bindEntry(0); uiTab = 0;
        notice = "已清空当前列表，图片、日志、导入记录与账号全部保留。可读取 PS 所选图层开始新批次，或到“日志与历史”打开旧批次。";
    }
    function retryFailed(indices) {
        if (batchIsRunning()) { fail("请等待当前批次结束后再重试。"); }
        var selected = {}, chosen = [], i, saved = currentIndex, state;
        for (i = 0; i < indices.length; i++) { selected["row" + indices[i]] = true; }
        for (i = 0; i < entries.length; i++) {
            if (!selected["row" + i]) { continue; }
            bindEntry(i); state = statusNow();
            if (state && state.state === "error") { chosen.push(i); }
        }
        bindEntry(saved);
        if (!chosen.length) { fail("所选项目没有失败图层。请选择标为“失败”的行，或点击“重试全部失败”。"); }
        startBatch(chosen);
        return chosen.length;
    }
    function startBatch(retryIndices) {
        if (!prompt.replace(/\s/g, "")) { fail("请输入去字提示词。"); }
        if (!entries.length) { fail("请先读取 PS 所选图层。"); }
        var choice = generationChoice();
        var activeFile = child(root, "runtime/active-http-batch.json"), activeData, activeFolder, activeState;
        var previousActiveText = activeFile.exists ? readText(activeFile) : "";
        if (activeFile.exists) {
            activeData = parseJSON(readText(activeFile));
            if (/^[0-9]+-[0-9]+$/.test(activeData.batch_name)) {
                activeFolder = new Folder(root.fsName + "/runtime/batches/" + activeData.batch_name);
                if (child(activeFolder, "status.json").exists) {
                    activeState = parseJSON(readText(child(activeFolder, "status.json")));
                    if (activeState.state === "running" || activeState.state === "starting") { fail("已有批次正在处理，请先等待结束或取消该批次。"); }
                } else if (child(activeFolder, "request.json").exists) { fail("已有批次正在启动，请先查看该批次；不会同时重复提交。"); }
            }
        }
        var previousEntries = entries, previousBatch = batchFolder, previousIndex = currentIndex;
        var nextEntries = [], chosen = {}, i, item, request, manifest, oldRequest;
        var retrying = retryIndices instanceof Array;
        if (retrying) {
            if (!retryIndices.length) { fail("没有失败图层可重试。"); }
            for (i = 0; i < retryIndices.length; i++) { chosen["row" + retryIndices[i]] = true; }
        }
        // Preflight every source before exporting; no generation starts on partial export.
        for (i = 0; i < entries.length; i++) {
            if (!retrying || chosen["row" + i]) {
                item = collectSelected([entries[i].source_layer_id])[0];
                if (retrying) { item.retry_of = entries[i].job_name; }
            } else {
                item = parseJSON(encodeJSON(entries[i]));
                oldRequest = parseJSON(readText(child(new Folder(root.fsName + "/runtime/jobs/" + item.job_name), "request.json")));
                if (!/^[0-9]+-[0-9]+$/.test(oldRequest.batch_name)) { fail("旧任务缺少来源批次，无法沿用；请逐张导入后读取新选择。"); }
                item.carried = true; item.carried_from_batch = oldRequest.batch_name;
            }
            nextEntries.push(item);
        }
        var nextBatch = new Folder(root.fsName + "/runtime/batches/" + makeName()); ensureFolder(nextBatch);
        entries = nextEntries; batchFolder = nextBatch;
        try {
            writeText(child(nextBatch, "credentials.json"), encodeJSON(choice));
            for (i = 0; i < entries.length; i++) {
                item = entries[i];
                if (item.carried === true) { continue; }
                item.job_name = makeName(); bindEntry(i); validateLayer(originalLayer);
                if (!sameBox(bounds(originalLayer), raw)) { fail("原图层边界发生变化，请重新选择图层。"); }
                selectIDs([originalLayer.id]);
                ensureFolder(job); exportSource(box);
                request = {width: width, height: height, left: box[0], top: box[1], raw_bounds: raw,
                           document_id: originalDoc.id, source_layer_id: originalLayer.id, source_layer_name: originalLayer.name,
                           batch_name: batchFolder.name, started_ms: new Date().getTime(), prompt: prompt,
                           backend: choice.backend, profile_id: choice.profile_id, credential_ref: batchFolder.name, prefer_watermark_free: config.prefer_watermark_free !== false,
                           web_upload_mode: choice.backend === "web" ? webUploadMode : "separate"};
                if (item.retry_of) { request.retry_of = item.retry_of; }
                writeText(child(job, "request.json"), encodeJSON(request));
            }
            manifest = {schema: 1, version: "6.5.1", document_id: originalDoc.id, document_name: originalDoc.name,
                        photoshop_version: app.version, photoshop_path: app.path.fsName,
                        started_ms: new Date().getTime(), items: entries, notify: true};
            manifest.web_upload_mode = choice.backend === "web" ? webUploadMode : "separate";
            if (retrying && previousBatch) { manifest.previous_batch_name = previousBatch.name; }
            writeText(child(batchFolder, "request.json"), encodeJSON(manifest));
            writeText(child(batchFolder, "status.json"), encodeJSON({state: "starting", message: retrying ? "失败图层重试正在启动；其他图层沿用原结果。" : "后台批次正在启动。"}));
            writeText(activeFile, encodeJSON({batch_name: batchFolder.name}));
            selectedRowIndices = []; bindEntry(0); selectIDs(selectedIDsAtOpen);
            launchWorker(pythonw, child(root, "batch_worker.py"), batchFolder);
            var clearedMarker = child(root, "runtime/ui-cleared-" + originalDoc.id + ".json");
            if (clearedMarker.exists) { clearedMarker.remove(); }
        } catch (error) {
            try { writeText(child(nextBatch, "status.json"), encodeJSON({state: "error", message: "批次导出或启动失败；没有自动重试。"})); } catch (ignoredFailure) {}
            try { child(nextBatch, "credentials.json").remove(); } catch (ignoredCredentials) {}
            entries = previousEntries; batchFolder = previousBatch; bindEntry(previousIndex);
            try { if (previousActiveText) { writeText(activeFile, previousActiveText); } else if (activeFile.exists) { activeFile.remove(); } } catch (ignoredActiveRecord) {}
            try { selectIDs(selectedIDsAtOpen); } catch (ignoredSelection) {}
            throw error;
        }
    }
    function validateMergedSelections(mapping, choices) {
        if (!mapping || mapping.schema !== 1 || !mapping.items || !mapping.candidates || choices.length !== mapping.items.length) { fail("合并对应记录无效。"); }
        var used = {}, valid = {}, result = [], i, id, count = 0;
        for (i = 0; i < mapping.candidates.length; i++) {
            id = mapping.candidates[i].id; if (!/^[0-9]+$/.test(id)) { fail("合并结果编号无效。"); } valid["id" + id] = true;
        }
        for (i = 0; i < choices.length; i++) {
            id = choices[i];
            if (id !== null) {
                if (!valid["id" + id] || used["id" + id]) { fail("同一结果不能对应多个图层，请核对重复选择。"); }
                used["id" + id] = true; count++;
            }
            result.push({job_name: mapping.items[i].job_name, source_layer_id: mapping.items[i].source_layer_id, candidate_id: id});
        }
        if (!count) { fail("请至少为一个图层选择对应结果，其余缺失项可以留空。"); }
        return result;
    }
    function reviewMergedResults() {
        if (!batchFolder || batchIsRunning()) { fail("请等待合并批次结束后核对。"); }
        var mapFile = child(batchFolder, "merged-map.json");
        if (!mapFile.exists || child(batchFolder, "mapping.lock").exists) { fail("没有待核对的合并结果，或已经处理过对应关系。"); }
        var mapping = parseJSON(readText(mapFile)), choices = [], i, j, index = 0, keep = true, selections;
        if (mapping.batch_name !== batchFolder.name || !mapping.items || !mapping.items.length || !mapping.candidates || !mapping.candidates.length) { fail("合并结果记录无效。"); }
        for (i = 0; i < mapping.items.length; i++) { choices.push(null); }
        var draft = child(batchFolder, "mapping-draft.json");
        if (draft.exists) { try { var savedDraft = parseJSON(readText(draft)); if (savedDraft.choices && savedDraft.choices.length === choices.length) { choices = savedDraft.choices; } } catch (ignoredDraft) {} }
        while (keep) {
            var win = new Window("dialog", "核对合并结果（仅在本机操作，不生成）"), action = "back";
            win.orientation = "column"; win.alignChildren = ["fill", "top"];
            win.add("statictext", undefined, "原图 " + mapping.items.length + " 层 / 可用结果 " + mapping.candidates.length + " 张。逐层选择对应图片，同一结果只用一次；缺失项留空。");
            var layerPicker = win.add("dropdownlist", undefined, []);
            for (i = 0; i < mapping.items.length; i++) {
                var label = "图层 ID " + mapping.items[i].source_layer_id;
                for (j = 0; j < entries.length; j++) { if (entries[j].job_name === mapping.items[i].job_name) { label = entries[j].source_layer_name + " [ID " + entries[j].source_layer_id + "]"; break; } }
                layerPicker.add("item", (i + 1) + ". " + label + " → " + (choices[i] === null ? "未分配" : "结果 " + choices[i]));
            }
            layerPicker.selection = index;
            var picker = win.add("dropdownlist", undefined, ["未分配 / 本层结果缺失"]); picker.selection = 0;
            for (i = 0; i < mapping.candidates.length; i++) {
                var candidate = mapping.candidates[i];
                if (!/^[0-9]+$/.test(candidate.id)) { fail("合并图片编号无效。"); }
                picker.add("item", "结果 " + candidate.id + "  ·  " + candidate.width + " × " + candidate.height);
                if (choices[index] === candidate.id) { picker.selection = i + 1; }
            }
            var images = win.add("group"), left = images.add("panel", undefined, "原图层（上传时）"), right = images.add("panel", undefined, "所选返回图");
            left.preferredSize = [300, 230]; right.preferredSize = [300, 230];
            var sourcePreview = child(new Folder(root.fsName + "/runtime/jobs/" + mapping.items[index].job_name), "source-preview.png");
            if (sourcePreview.exists) { left.add("image", undefined, sourcePreview); }
            if (choices[index] !== null && /^[0-9]+$/.test(choices[index])) {
                var resultPreview = child(batchFolder, "merged-results/" + choices[index] + "-preview.png");
                if (resultPreview.exists) { right.add("image", undefined, resultPreview); }
            } else { right.add("statictext", undefined, "选择返回图片后显示预览"); }
            var row = win.add("group"), previous = row.add("button", undefined, "上一层"), next = row.add("button", undefined, "下一层"), finish = row.add("button", undefined, "确认对应并导入"), back = row.add("button", undefined, "保存草稿并返回");
            previous.enabled = index > 0; next.enabled = index < mapping.items.length - 1;
            layerPicker.onChange = function () { action = "layer"; win.close(1); };
            picker.onChange = function () { action = "picture"; win.close(1); };
            previous.onClick = function () { action = "previous"; win.close(1); };
            next.onClick = function () { action = "next"; win.close(1); };
            finish.onClick = function () { action = "finish"; win.close(1); };
            back.onClick = function () { action = "back"; win.close(1); };
            win.show();
            choices[index] = picker.selection && picker.selection.index > 0 ? mapping.candidates[picker.selection.index - 1].id : null;
            writeText(draft, encodeJSON({choices: choices}));
            if (action === "back") { return; }
            if (action === "layer") { index = layerPicker.selection ? layerPicker.selection.index : index; }
            else if (action === "previous") { index--; }
            else if (action === "next") { index++; }
            else if (action === "finish") {
                selections = validateMergedSelections(mapping, choices);
                var task = new Folder(root.fsName + "/runtime/jobs/" + makeName()); ensureFolder(task);
                writeText(child(task, "request.json"), encodeJSON({kind: "merged_finalize", batch_name: batchFolder.name, selections: selections, auto_import: true}));
                launchWorker(pythonw, child(root, "merged_worker.py"), task);
                // Close this JSX invocation immediately so completion can attach
                // to the existing PS instance without a second open modal dialog.
                return true;
            }
        }
    }
    function importConfirmedMergedResults() {
        if (!batchFolder) { return false; }
        var confirmation = child(batchFolder, "mapping-confirmed.json");
        if (!confirmation.exists) { return false; }
        var data = parseJSON(readText(confirmation)), selected = [], seen = {}, i, j, row, found;
        if (data.auto_import !== true) { return false; }
        if (!data.selections || !(data.selections instanceof Array)) { fail("自动导入缺少已确认的对应关系。"); }
        if (child(batchFolder, "auto-import-started.flag").exists) { return true; }
        for (i = 0; i < data.selections.length; i++) {
            row = data.selections[i]; found = null;
            for (j = 0; j < entries.length; j++) {
                if (entries[j].job_name === row.job_name && entries[j].source_layer_id === row.source_layer_id) { found = entries[j]; break; }
            }
            if (!found || seen["job" + row.job_name]) { fail("确认结果与当前批次图层不一致，已停止自动导入。"); }
            seen["job" + row.job_name] = true;
            if (row.candidate_id !== null) { selected.push(found); }
        }
        if (!selected.length) { fail("没有已确认的合并结果可导入。"); }
        writeText(child(batchFolder, "auto-import-started.flag"), "once");
        var savedEntries = entries, savedIndex = currentIndex;
        try {
            entries = selected; bindEntry(0);
            importReadyResults();
            writeText(child(batchFolder, "auto-import-finished.flag"), "finished");
        } finally { entries = savedEntries; bindEntry(savedIndex); }
        return true;
    }
    function downloadSelectedResult() {
        if (!batchFolder || !job || batchIsRunning()) { fail("请先打开已结束批次，并选中一个失败图层。"); }
        if (requestedIndices.length > 1) { fail("每次找回一个失败图层，请只选择一行。"); }
        var state = statusNow();
        if (!state || (state.state !== "error" && state.state !== "cancelled")) { fail("仅支持找回失败或取消图层；成功结果直接导入即可。"); }
        var sourceRequest = parseJSON(readText(child(job, "request.json"))), taskID = "", hasCache = child(job, "remote-result.json").exists;
        if (sourceRequest.web_upload_mode === "merged") { fail("合并结果请通过核对窗口确认对应关系。"); }
        if (!hasCache || sourceRequest.backend === "api") {
            var win = new Window("dialog", "找回已生成图片（不会重新生成）"), action = "cancel";
            win.orientation = "column"; win.alignChildren = ["fill", "top"];
            win.add("statictext", undefined, "原图层：" + entries[currentIndex].source_layer_name + " [ID " + sourceRequest.source_layer_id + "]");
            win.add("statictext", undefined, hasCache ? "留空：使用本机保存的下载地址。地址失效时，可填原 Grsai 完整任务 ID 查询。" : "旧版未保存下载地址，请从原 Grsai 中转站任务详情复制完整任务 ID。");
            win.add("statictext", undefined, "截图内带省略号的 ID 无法查询；只会使用原任务的 API 配置，找回后请预览核对内容。");
            var input = win.add("edittext", undefined, ""); input.characters = 58;
            var row = win.add("group"), ok = row.add("button", undefined, "找回已有结果"), back = row.add("button", undefined, "返回");
            ok.onClick = function () { action = "recover"; win.close(1); };
            back.onClick = function () { action = "cancel"; win.close(1); };
            win.show();
            if (action !== "recover") { return false; }
            taskID = input.text.replace(/^\s+|\s+$/g, "");
        }
        if (!hasCache && !taskID) { fail("未保存下载地址，需要完整的原 Grsai 任务 ID；没有重新生成。"); }
        if (taskID && !/^[A-Za-z0-9_-]{6,150}$/.test(taskID)) { fail("请复制完整任务 ID，不能包含省略号或网址。"); }
        if (taskID && !confirm("请确认该完整任务 ID 对应所选原图层“" + entries[currentIndex].source_layer_name + "” [ID " + sourceRequest.source_layer_id + "]。\n\n将只查询已有结果，使用原 API 配置，不会重新生成。")) { return false; }
        var task = new Folder(root.fsName + "/runtime/jobs/" + makeName()); ensureFolder(task);
        writeText(child(task, "request.json"), encodeJSON({kind: "result_recovery", batch_name: batchFolder.name,
            source_job_name: job.name, task_id: taskID || null, binding_confirmed: !!taskID}));
        launchWorker(pythonw, child(root, "result_recovery.py"), task);
        alert("正在找回已有结果，完成或失败后会提示并返回本批次。\n不会重新提交生成；找回后请预览，再导入。");
        return true;
    }
    function importReadyResults() {
        var i, state, count = 0, errors = [], saved = currentIndex;
        for (i = 0; i < entries.length; i++) {
            bindEntry(i); state = statusNow();
            if (!state || state.state !== "done") { continue; }
            // A pending marker prevents another import if Photoshop succeeds but disk recording fails.
            if (child(job, "importing.flag").exists) { errors.push(entries[i].source_layer_name + "：存在未确认导入记录，请先核对 PSD。"); continue; }
            var placed = false;
            try {
                writeText(child(job, "importing.flag"), "pending");
                recordPS("import_start", null);
                importResult(state, box); placed = true;
                writeText(child(job, "imported.flag"), encodeJSON({result_layer_id: imported.id, source_layer_id: originalLayer.id}));
                if (child(job, "import-error.json").exists) { child(job, "import-error.json").remove(); }
                child(job, "importing.flag").remove(); count++;
                recordPS("import_done", {placed: true});
            } catch (error) {
                recordPS("import_error", {line: error.line, placed: placed});
                if (!placed) { try { child(job, "importing.flag").remove(); } catch (ignoredMarker) {} }
                try { writeText(child(job, "import-error.json"), encodeJSON({message: error.message || String(error), placed: placed})); } catch (ignoredLog) {}
                errors.push(entries[i].source_layer_name + " [ID " + entries[i].source_layer_id + "]：" + (error.message || String(error)));
            }
        }
        bindEntry(saved);
        alert("已导入 " + count + " 个结果，各自位于对应原图层上方，原图层保留。" + (errors.length ? "\n\n未导入或需核对：\n" + errors.join("\n") : ""));
    }
    try {
        if ($.os.toLowerCase().indexOf("windows") < 0) { fail("配套程序仅支持 Windows。"); }
        if (!app.documents.length) { fail("请先打开原 PSD；已完成的结果保存在本机，不会丢失。"); }
        originalDoc = app.activeDocument; originalLayer = originalDoc.activeLayer;
        if (resumeBatchName) {
            if (!/^[0-9]+-[0-9]+$/.test(resumeBatchName)) { fail("完成通知中的批次记录无效。"); }
            if (child(new Folder(root.fsName + "/runtime/batches/" + resumeBatchName), "dismissed.flag").exists) { return; }
            var notifiedManifest = parseJSON(readText(child(new Folder(root.fsName + "/runtime/batches/" + resumeBatchName), "request.json")));
            if (child(root, "runtime/ui-cleared-" + notifiedManifest.document_id + ".json").exists) { return; }
            var documentFound = false, documentIndex;
            for (documentIndex = 0; documentIndex < app.documents.length; documentIndex++) {
                if (app.documents[documentIndex].id === notifiedManifest.document_id) {
                    originalDoc = app.documents[documentIndex]; app.activeDocument = originalDoc; documentFound = true; break;
                }
            }
            if (!documentFound) { fail("批次已结束，但原 PSD 已关闭。结果已保存，可重新打开原文件并逐张找回，不会导入其他文档。"); }
        }
        selectedIDsAtOpen = selectedLayerIDs();
        if (originalDoc.mode !== DocumentMode.RGB || (originalDoc.bitsPerChannel !== BitsPerChannelType.EIGHT && originalDoc.bitsPerChannel !== BitsPerChannelType.SIXTEEN)) {
            fail("支持 RGB 8 位或 16 位文档，请转换文档副本后再试。");
        }
        var pythonw = child(root, ".venv/Scripts/pythonw.exe"), worker = child(root, "bridge_worker.py");
        if (!pythonw.exists || !worker.exists || !child(root, "account_worker.py").exists || (!child(root, "config.json").exists && !child(root, "config.previous.json").exists) ||
                !child(root, "ark_api.py").exists || !child(root, "image_api.py").exists || !child(root, "merged_worker.py").exists || !child(root, "generation_profiles.py").exists || !child(root, "api_diagnostics.py").exists ||
                !child(root, "batch_worker.py").exists || !child(root, "notify_completion.ps1").exists ||
                !child(root, "diagnostics.py").exists || !child(root, "support_logs.py").exists ||
                !child(root, "batch_records.py").exists || !child(root, "result_transfer.py").exists || !child(root, "result_recovery.py").exists) { fail("请保留 v6.5.1 配套文件夹，并先运行 install.cmd。"); }
        if (!child(root, "config.json").exists && child(root, "config.previous.json").exists) {
            if (!child(root, "config.previous.json").copy(child(root, "config.json").fsName)) { fail("配置恢复失败，请检查目录权限。"); }
        }
        var config = parseJSON(readText(child(root, "config.json")));
        var timeout = Number(config.timeout_seconds || 600);
        if (!isFinite(timeout) || timeout <= 0) { fail("处理超时必须为正数。"); }
        prompt = config.prompt || "移除图片中的所有文字，自然补全背景，保持人物、物体、构图、颜色和非文字细节，避免添加文字。";
        initProfiles();
        app.preferences.rulerUnits = Units.PIXELS;
        app.displayDialogs = DialogModes.NO;
        originBefore = originalDoc.rulerOrigin; originalDoc.rulerOrigin = [0, 0];
        ensureFolder(new Folder(root.fsName + "/runtime/jobs"));
        ensureFolder(new Folder(root.fsName + "/runtime/batches"));
        if (resumeBatchName) {
            readBatch(new Folder(root.fsName + "/runtime/batches/" + resumeBatchName));
            var completedState = batchStatus();
            if (!importConfirmedMergedResults()) { alert("豆包批次已结束\n\n" + completedState.message + "\n\n即将显示对应图层及可导入结果。"); }
        } else if (child(root, "runtime/ui-cleared-" + originalDoc.id + ".json").exists) { entries = []; bindEntry(0); }
        else if (!resumeActiveBatch()) {
            entries = collectSelected(selectedIDsAtOpen); bindEntry(0);
            if (entries.length === 1) { resumeActive(); if (job) { entries[0].job_name = job.name; } }
        }
        var running = true;
        while (running) {
            response = statusNow();
            var action = showUI(response);
            bindEntry(requestedIndex);
            notice = "";
            // All work happens AFTER the native modal event loop has returned.
            try {
                savePreferences();
                if (action === "saveprefs") { notice = "提示词和当前生成选择已保存到本机 config.json。"; }
                else if (action === "manageweb" || action === "manageapi") { manageProfiles(action === "manageapi" ? "api" : "web"); }
                else if (action === "close") { running = false; }
                else if (action === "view") { /* Read selected result and local queue progress. */ }
                else if (action === "logs") { showLogs(); }
                else if (action === "exportlogs") { exportLogs(); }
                else if (action === "mapmerged") { if (reviewMergedResults()) { running = false; } }
                else if (action === "downloadresult") { if (downloadSelectedResult()) { running = false; } }
                else if (action === "clear") { clearCurrentBatch(); }
                else if (action === "history") { openHistory(); }
                else if (action === "retryselected" || action === "retryall") {
                    var retryRows = requestedIndices, retryIndex;
                    if (action === "retryall") { retryRows = []; for (retryIndex = 0; retryIndex < entries.length; retryIndex++) { retryRows.push(retryIndex); } }
                    var retryCount = retryFailed(retryRows); running = false;
                    alert("已建立 " + retryCount + " 个失败图层的新任务。\n\n已重新导出这些原图层的当前内容和位置；其余成功结果、导入记录和旧日志保留。后台完成后会提示。");
                }
                else if (action === "cancel") {
                    if (batchFolder) {
                        var cancellingState = batchStatus();
                        if (cancellingState.recovery_task && /^[0-9]+-[0-9]+$/.test(cancellingState.recovery_task)) {
                            writeText(child(new Folder(root.fsName + "/runtime/jobs/" + cancellingState.recovery_task), "cancel.flag"), "cancelled");
                        } else { writeText(child(batchFolder, "cancel.flag"), "cancelled"); }
                    }
                    else { cancelJob(); }
                    notice = "已请求取消。队列后面的图层不会提交，已完成结果仍可导入。上游已开始的生成可能继续。";
                }
                else if (action === "newselection") {
                    selectedIDsAtOpen = selectedLayerIDs();
                    var newEntries = collectSelected(selectedIDsAtOpen);
                    entries = newEntries; batchFolder = null; bindEntry(0);
                    selectedRowIndices = []; requestedIndices = []; uiTab = 0;
                    var emptyMarker = child(root, "runtime/ui-cleared-" + originalDoc.id + ".json"); if (emptyMarker.exists) { emptyMarker.remove(); }
                    notice = "已读取当前所选的 " + entries.length + " 个图层。点击一次开始生成即可。";
                }
                else if (action === "recover") {
                    var requestFile = File.openDialog("选择 runtime/jobs/任务目录中的 request.json（只找回结果，不重新生成）", "JSON:*.json", false);
                    if (requestFile) {
                        var recovery = requestFile.parent;
                        if (recovery.parent.fsName !== new Folder(root.fsName + "/runtime/jobs").fsName) { fail("请选择本脚本 runtime/jobs 中的任务。"); }
                        readRequest(recovery);
                        if (!child(recovery, "result.png").exists || !child(recovery, "status.json").exists) { fail("此任务没有可找回的完整图片。"); }
                        var recoveredStatus = parseJSON(readText(child(recovery, "status.json")));
                        if (recoveredStatus.state !== "done") { fail("此任务尚未成功生成。"); }
                        if (child(recovery, "imported.flag").exists) { fail("此任务已有导入记录，不能再次导入。"); }
                        job = recovery;
                        entries[0].job_name = recovery.name; batchFolder = null; currentIndex = 0;
                        // Explicit local recovery is allowed even if Photoshop assigned new document IDs after a crash.
                        if (child(job, "cancel.flag").exists) { child(job, "cancel.flag").remove(); }
                        notice = "已找回结果。将导入到当前图层“" + originalLayer.name + "”上方，请确认预览后点击导入。";
                    }
                } else if (action === "generate") {
                    startBatch(); running = false;
                    alert("已建立 " + entries.length + " 个图层的批次。\n\n关闭此提示后可继续使用 PS；进度自动记录，批次结束会提示并尝试返回结果窗口，无需反复刷新。\n若 PS 正忙而无法自动返回，会显示完成提示；重新运行脚本即可查看结果，不要再次生成。");
                } else if (action === "importall") {
                    if (batchIsRunning()) { fail("批次仍在处理，请等待完成提示。"); }
                    importReadyResults();
                }
            } catch (actionError) {
                recordPS("ui_error", {line: actionError.line});
                if (scratch) { try { scratch.close(SaveOptions.DONOTSAVECHANGES); } catch (ignoredScratch) {} scratch = null; }
                try { app.activeDocument = originalDoc; } catch (ignoredDoc) {}
                notice = (actionError.message || String(actionError)) + (actionError.line ? "\n脚本行号：" + actionError.line : "");
                if (job) { notice += "\n任务目录：" + job.fsName; }
                if (action === "close") { alert("设置未能保存\n\n" + notice); running = false; }
            }
        }
    } catch (error) {
        alert("豆包去字未完成\n\n" + (error.message || String(error)) + (error.line ? "\n脚本行号：" + error.line : ""));
    } finally {
        if (scratch) { try { scratch.close(SaveOptions.DONOTSAVECHANGES); } catch (ignoredScratch) {} }
        if (originalDoc) {
            try {
                app.activeDocument = originalDoc;
                if (originBefore) { originalDoc.rulerOrigin = originBefore; }
                if (!succeeded && selectedIDsAtOpen.length) { selectIDs(selectedIDsAtOpen); }
            } catch (ignoredDocument) {}
        }
        app.preferences.rulerUnits = rulerBefore;
        app.displayDialogs = dialogsBefore;
    }
}());
