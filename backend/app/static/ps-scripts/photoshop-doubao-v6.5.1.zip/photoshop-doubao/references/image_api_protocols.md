# 图片编辑协议依据 · v6.5

核对日期：2026-11-05。通过 HTTP 获取公开文档；未登录、上传图片或调用生成。模型名均为可编辑示例，用户需自行开通权限。

## OpenAI

- 官方参考：https://developers.openai.com/api/reference/resources/images/methods/edit
- 官方指南：https://developers.openai.com/api/docs/guides/image-generation

采用 POST /v1/images/edits，Bearer 认证，multipart 内包含实际 PNG 文件、model、prompt、n=1、size 和 quality。由 httpx 产生 boundary；不发送 Seedream watermark 字段或默认假定所有模型支持 response_format。支持 data[0].b64_json 与 HTTPS url。HTTP 200 不代表内容满足去字要求。当前实现选择已有 gpt-image-2 作为示例，不自动追踪“最新”模型。

## Google / Nano Banana

- 图片能力：https://ai.google.dev/gemini-api/docs/image-generation
- HTTP 内容接口：https://ai.google.dev/api/generate-content

Nano Banana 作为 Gemini 图片能力接入。本版采用仍有官方参考的 generateContent 协议，以兼容该接口及对应中转，不混用 interactions 协议：POST /v1beta/models/{model}:generateContent，Google 官方使用 x-goog-api-key。

contents[0].parts 同时包含 text 和 inlineData（image/png 的 base64）。generationConfig.responseModalities 请求 TEXT、IMAGE；显式档位时发送 imageConfig.imageSize，auto 时省略。读取首个 candidate 的最终非 thought 图片 part，拒绝安全拦截/异常结束或纯文字回复。官方图片输出可能带 SynthID；本版不移除模型的来源标识。

## 火山 Seedream / Agent Plan

- https://ark.volcengine.com/region:cn-beijing/docs/image-generation-api.md
- https://ark.volcengine.com/region:cn-beijing/docs/seedream-5-0-pro.md
- https://docs.volcengine.com/docs/ark/agent-plan-personal-visual-models?lang=zh

保留已实现的单个 PNG data URI、单图非流式输出；不传 Pro/Flash 不支持的组图及流式参数。普通 /api/v3 与 Agent Plan /api/plan/v3 分开，密钥、已知模型别名按原规则处理，不回退计费入口。补充约束不修改用户保存的提示词。

## 用户指定中转：Grsai

- GPT：https://qmy27nhsd9.apifox.cn/452409160e0
- Nano Banana：https://qmy27nhsd9.apifox.cn/452392911e0
- 结果查询：https://qmy27nhsd9.apifox.cn/452409577e0
- OpenAI 风格：https://qmy27nhsd9.apifox.cn/512807352e0
- Gemini 风格：https://qmy27nhsd9.apifox.cn/511492924e0

专用接口 POST /v1/api/generate，Bearer Key。文档 images 明示支持 base64 与 URL，本版固定传一个 PNG data URI，绝不传空数组。replyType=json。GPT 使用 aspectRatio 像素尺寸、quality；Nano 使用 aspectRatio=auto 和可选 imageSize。成功要求 status=succeeded，读取 results[0] 图片。

若服务返回已知等待状态及合法 id，只 GET 同站点 /v1/api/result?id=该编号，并逐次校验响应 id。任意任务结果、未知状态或错误不补发生成。文档中其他协议必须显式选择对应协议，程序不会根据域名自动猜测请求格式或“试一个接口再换另一个”。

用户指定的网页由中转商维护，其接口名、模型名、限额、价格与可用性不能据此视为官方承诺。当前没有真实 Key 实测。

## 网页 Doubao

参考 https://github.com/SeiShonagon520/doubao2api 的纯 HTTP upload_image、get_file_url、generate_image 多附件结构，保留许可证。原项目的图片生成参数支持 ref_image_keys，但未提供可靠的来源图层 ID 到输出图 ID 映射。因此本版合并请求收集全部结果，以本地人工核对建立唯一对应，不按输出顺序猜测。
