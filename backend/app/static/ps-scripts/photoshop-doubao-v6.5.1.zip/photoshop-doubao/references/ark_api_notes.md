# 方舟图片 API 接入核实 · v6.4.2

核对日期：2026-11-03。读取官方公开文档，没有使用浏览器或调用生成。

- 普通 API：https://ark.volcengine.com/region:cn-beijing/docs/image-generation-api
- Seedream Pro：https://ark.volcengine.com/region:cn-beijing/docs/seedream-5-0-pro
- Agent Plan 视觉接入：https://docs.volcengine.com/docs/ark/agent-plan-personal-visual-models?lang=zh
- Agent Plan 模型表：https://docs.volcengine.com/docs/ark/agent-plan-personal-plan-overview?lang=zh

普通 API：POST https://ark.cn-beijing.volces.com/api/v3/images/generations，普通 API Key，模型 doubao-seedream-5-0-pro-260628。

Agent Plan：POST https://ark.cn-beijing.volces.com/api/plan/v3/images/generations，套餐专属 Key，模型表列 doubao-seedream-5-0-pro。部分说明文本写作 doubao-seedream-5.0-pro，实现按模型表规范化为连字符形式，不猜测其他模型别名，也不回退至后付费地址。

Pro/Flash 不支持配置 sequential_image_generation，且不支持流式输出；字段说明的 stream 支持列表不含 Pro/Flash。实现省略两个字段，采用默认单图非流式。output_format 的支持表含5.0系列，未知 Endpoint ID 与旧模型不传此可选字段，最终仍转为PNG。

image 支持 PNG data URI；response_format 可为 url/b64_json；watermark:false 请求不添加水印。Pro 输出档位1K/1.5K/2K。参考图按30MB、宽高>14、总像素<=3600万、比例1:16至16:1校验；结果经已有流程恢复原尺寸与alpha。

业务错误码及参数采用受控词表；追踪号校验格式并排除已知密钥，原始错误文本不落盘。旧错误未保留的具体字段不能恢复。真实 Key 权限、账户额度和生成仍由用户验证。

## v6.4.2 参考图接收校验

2026-11-03 再次通过纯 HTTP 获取官方 image-generation-api.md 和 seedream-5-0-pro.md：image 可为单个 PNG data URI，无需单独上传附件。usage.input_images 是模型实际输入图片数，文档标注 Pro/Flash 支持。实现保留单图字符串协议，增加原 PNG/编码回读校验；读取该计数，明确为非 1 时不使用结果，缺失时标记未回报，不宣称服务端确认。

API 请求附加局部文字清理约束，用户保存的提示词仍保留。该约束只能减少误解，不能保证模型不重绘。

对照 https://github.com/SeiShonagon520/doubao2api 的 client.py 上传实现：仍为 upload_image + get_file_url；上传头使用主 CSRF 或默认 CSRF。v6.4.2 补上纯 HTTP 初始化、动态凭据同步和旧域副本清理。未知 671020000 的确切服务端含义未在参考资料中确认，不猜测为固定的“首张错误”，也不通过改图、换账号或替代上传通道绕过明确拒绝。
