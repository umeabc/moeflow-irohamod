"""Read only credential snapshots. Never fall back to another account or backend."""
import re
from urllib.parse import urlsplit

DEFAULT_ENDPOINT = 'https://ark.cn-beijing.volces.com/api/v3/images/generations'
DEFAULT_MODEL = 'doubao-seedream-5-0-pro-260628'
PLAN_ENDPOINT = 'https://ark.cn-beijing.volces.com/api/plan/v3/images/generations'
PLAN_MODEL = 'doubao-seedream-5-0-pro'


def endpoint_mode(endpoint):
    parts = urlsplit(endpoint)
    if parts.hostname in ('api.openai.com', 'generativelanguage.googleapis.com'): return 'standard'
    if parts.hostname == 'ark.cn-beijing.volces.com':
        if parts.path == '/api/plan/v3/images/generations': return 'plan'
        if parts.path == '/api/v3/images/generations': return 'standard'
    return 'custom'


def model_family(model):
    if model.startswith('ep-'): return 'endpoint_id'
    value = model.lower().replace('.', '-')
    for part, family in (('5-0-pro', 'seedream5_pro'), ('5-0-flash', 'seedream5_flash'),
                         ('5-0-lite', 'seedream5_lite'), ('4-5', 'seedream4_5'), ('4-0', 'seedream4_0')):
        if value.startswith('doubao-seedream-' + part): return family
    if value.startswith('doubao-seedream-5-0-260128'): return 'seedream5_lite'
    return 'custom'


def protocol_options(profile, error):
    """Legacy profiles remain Seedream; a hostname never selects a wire protocol."""
    protocol = profile.get('protocol', 'seedream')
    provider = profile.get('provider', 'gemini' if protocol == 'gemini' else 'openai' if protocol == 'openai' else 'seedream')
    if protocol not in ('seedream', 'openai', 'gemini', 'grsai') or provider not in ('seedream', 'openai', 'gemini'):
        raise error('未知的 API 服务或图片编辑协议，请重新选择。')
    if protocol != 'grsai' and protocol != provider or protocol == 'grsai' and provider == 'seedream':
        raise error('服务与图片编辑协议不匹配。')
    return protocol, provider


def validate_api(profile, error):
    if not isinstance(profile, dict): raise error('API 配置格式无效。')
    protocol, provider = protocol_options(profile, error)
    endpoint = str(profile.get('endpoint') or '').strip()
    try:
        parts = urlsplit(endpoint)
        valid = (parts.scheme == 'https' and parts.hostname and not parts.username and
                 not parts.password and not parts.query and not parts.fragment and
                 not any(c.isspace() or ord(c) < 32 for c in endpoint) and
                 parts.port in (None, 443))
    except ValueError: valid = False
    if not valid: raise error('API 地址须为 HTTPS 完整接口地址，不含账号、查询参数或片段。')
    suffix = {'seedream': '/images/generations', 'openai': '/images/edits', 'grsai': '/v1/api/generate'}
    if protocol in suffix and not parts.path.endswith(suffix[protocol]):
        raise error('API 地址与所选图片编辑协议不匹配，应以 ' + suffix[protocol] + ' 结尾。')
    if protocol == 'gemini' and not re.search(r'/models/[^/]+:generateContent$', parts.path):
        raise error('Gemini 地址须以 /models/{model}:generateContent 结尾，支持 {model} 占位符。')
    official = {'ark.cn-beijing.volces.com': 'seedream', 'api.openai.com': 'openai', 'generativelanguage.googleapis.com': 'gemini'}
    if parts.hostname in official and protocol != official[parts.hostname]:
        raise error('官方地址与所选图片编辑协议不匹配；未提交。')
    key = str(profile.get('api_key') or '').strip()
    model = str(profile.get('model') or '').strip()
    size = profile.get('size', '2K' if provider == 'seedream' else 'auto')
    if not key or len(key) > 4096 or any(c.isspace() for c in key): raise error('请在 API 管理中填写有效的 API Key。')
    if not model or len(model) > 200 or any(ord(c) < 32 for c in model): raise error('请填写 Model ID 或 Endpoint ID。')
    sizes = {'seedream': ('1K', '1.5K', '2K'), 'openai': ('auto', '1024x1024', '1536x1024', '1024x1536'), 'gemini': ('auto', '1K', '2K', '4K')}
    if size not in sizes[provider]: raise error('API 输出档位与所选服务不匹配，请重新选择。')
    detected = endpoint_mode(endpoint)
    mode = profile.get('billing_mode', detected)
    if not isinstance(mode, str) or mode not in ('standard', 'plan', 'custom') or mode != detected:
        raise error('API 类型与接口地址不匹配。请在 API 管理中核对普通方舟 API、Agent Plan 或自定义接口；未发起生成，也未切换计费入口。')
    if mode == 'standard' and parts.hostname not in official:
        raise error('官方入口必须使用对应官方地址；中转站请选择中转 / 自定义。')
    auth = profile.get('auth_mode', 'google' if protocol == 'gemini' and mode == 'standard' else 'bearer')
    if auth not in ('bearer', 'google') or protocol != 'gemini' and auth != 'bearer':
        raise error('认证方式与所选协议不匹配。')
    if mode == 'standard' and auth != ('google' if provider == 'gemini' else 'bearer'):
        raise error('官方接口的认证方式不匹配。')
    if protocol == 'gemini':
        if not re.fullmatch(r'[A-Za-z0-9_.-]{1,200}', model): raise error('Gemini Model ID 格式无效。')
        model_path = parts.path.rsplit('/models/', 1)[-1][:-len(':generateContent')]
        if model_path not in ('{model}', model): raise error('Gemini 地址中的模型与 Model ID 不一致，请使用 {model} 占位符。')
    quality = profile.get('quality', 'auto')
    if quality not in ('auto', 'low', 'medium', 'high'): raise error('API 图片质量选项无效。')
    # These are documented aliases of the same Pro model, not a fallback model.
    original = model
    if provider == 'seedream' and mode == 'plan' and model in (DEFAULT_MODEL, 'doubao-seedream-5.0-pro'):
        model = PLAN_MODEL
    elif provider == 'seedream' and mode == 'standard' and model in (PLAN_MODEL, 'doubao-seedream-5.0-pro'):
        model = DEFAULT_MODEL
    # Other dated model IDs have no implied permission on a Plan endpoint.
    if mode == 'plan' and re.fullmatch(r'doubao-seedream-.+-\d{6}', model):
        raise error('Agent Plan 不应填写普通 API 的带日期模型 ID。请填写套餐支持的模型名，并使用套餐专属 Key；未发起生成。')
    family = model_family(model)
    if ((family in ('seedream4_5', 'seedream5_lite') and size != '2K') or
            family == 'seedream4_0' and size == '1.5K'):
        raise error('当前模型不支持所选输出档位，请在 API 管理中选择 2K；未发起生成。')
    return {'endpoint': endpoint, 'api_key': key, 'model': model, 'size': size, 'billing_mode': mode,
            'protocol': protocol, 'provider': provider, 'auth_mode': auth, 'quality': quality,
            'model_normalized': model != original or profile.get('model_normalized') is True}


def load_snapshot(host, request):
    ref = request.get('credential_ref')
    if not isinstance(ref, str) or not re.fullmatch(r'\d+-\d+', ref): raise host.UserError('生成凭据快照编号无效，请重新提交。')
    path = host.RUNTIME / 'batches' / ref / 'credentials.json'
    if path.resolve().parent.parent != (host.RUNTIME / 'batches').resolve(): raise host.UserError('生成凭据快照路径无效。')
    try: snapshot = host.read_json(path)
    except (OSError, ValueError): raise host.UserError('本次生成凭据快照不可用，请重新提交；不会换用其他账号。')
    backend = request.get('backend')
    if (not isinstance(snapshot, dict) or backend not in ('web', 'api') or snapshot.get('backend') != backend or
            snapshot.get('profile_id') != request.get('profile_id') or request.get('batch_name') != ref):
        raise host.UserError('任务与所选生成配置不一致；不会换用其他账号。')
    if backend == 'api': return validate_api(snapshot.get('profile'), host.UserError)
    return host.normalize_session(snapshot.get('profile'))
